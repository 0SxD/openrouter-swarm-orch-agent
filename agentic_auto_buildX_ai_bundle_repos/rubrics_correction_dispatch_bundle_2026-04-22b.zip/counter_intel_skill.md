# counter_intel_skill.md | sub-skill | v1.1 clean 2026-04-22
# Epistemic hygiene: evidence-class tagging, avoid speculation framed as fact.
# Sprint-specific references removed; core discipline retained.

---

## why this skill exists

When reasoning about system behavior, LLM models and humans alike tend to promote hypotheses to facts without checking evidence. This compounds into false beliefs that waste time (chasing phantom issues) or erode trust (overconfident claims that turn out wrong).

Counter-intel discipline = always tag evidence class before claiming something, default to the weakest defensible class, phrase claims to match.

---

## evidence classes (weakest to strongest at face value)

1. SPECULATION: hypothesis with no supporting evidence beyond plausibility.
2. INFERENCE: derived from one or more other classes via a logical step (document + inference is stronger than pure inference).
3. USER_REPORT: stated by the user in this session. Stronger than speculation, weaker than direct evidence because humans can mis-remember or misconstrue.
4. DOCUMENT_TEXT: written in an onboarding doc, changelog, wiki, or approved exemplar. Authoritative but can be stale.
5. DIRECT_OBSERVATION: observed in current session output (e.g., QC fail message, Studio UI state, actual tool output).

Default to the weakest defensible class. Phrase the claim to match:
- Speculation: "one hypothesis is that ..."
- Inference: "this suggests ..." or "inferred from ... it follows that ..."
- User report: "per user report this session, ..."
- Document text: "per changelog entry dated [...], ..."
- Direct observation: "QC output showed: [...]"

---

## forbidden without evidence

Phrases that imply confident causation or systemic change without explicit evidence:

- "the auto-reviewer evolved mid-session"
- "the system changed mid-session"
- "X is a moving target"
- "we can't trust Y anymore"
- "this is an adversarial setup"

These frame observations as narrative. Replace with evidence-class-tagged statements:
- "two QC runs on identical state produced different Part 2 counts. EVIDENCE_CLASS: DIRECT_OBSERVATION. One hypothesis (SPECULATION): LLM nondeterminism. Alternative: unobserved state change."

---

## acceptable patterns

- "per changelog entry text dated [...], [claim]"
- "per insight NN in spec.md INSIGHTS_LEDGER, [claim]"
- "per user report this session that X happened, [inference]"
- "QC v2 fail message (DIRECT_OBSERVATION) stated [...]; INFERENCE: [...]"

---

## when to load this skill

- Before writing any statement about how the auto-reviewer, Studio UI, reviewer audits, or other systems behave.
- Before promoting an insight from INSIGHTS_LEDGER to a skill file.
- When a teammate or user challenges a prior framing of why something happened.
- When drafting a SESSION_HANDOFF or Wiki_Log entry.

---

## checklist pre-output

For every claim about system behavior or causation:

- [ ] Evidence class tagged?
- [ ] Claim phrased to match class strength?
- [ ] Weakest defensible class chosen (not overreaching)?
- [ ] No forbidden phrases used?
- [ ] Alternative hypotheses noted if INFERENCE or SPECULATION?

If any box is FALSE, revise the claim before output.

---

## example repair

Before:
> The QC v2 Part 2 format drifted, which means the auto-reviewer evolved in the last hour.

After:
> Two QC v2 Part 2 runs on identical rubric state produced different output formats (prose-per-requirement vs dimension-header-per-verdict). EVIDENCE_CLASS: DIRECT_OBSERVATION. One hypothesis (SPECULATION): LLM nondeterminism inherent to the checker. Alternative (SPECULATION): upstream prompt change. No changelog entry observed to confirm either. Monitoring.

---

## relationship to other skills

- Pairs with qc_v2_reverse_graph.md: when decoding QC behavior, every dimension claim must be evidence-tagged.
- Pairs with pre_submit_gate: false-positive override reasons in Writer Comments must be evidence-class acceptable.
- Pairs with atomic_split_decision.md: when a row flags ambiguously, surface as OPEN_Q rather than speculate the correct split.

---

END_SUBSKILL
