# DELETE_LIST_2026-04-22.md | user action list for sprint/xlsx cleanup
# Purpose: restore project to clean pre-sprint working state.
# Context: sprint pivot canceled, user not in revisor pool. All sprint/xlsx refs pruned.

---

## step 1: drop batch 1 replacement files

Drop these 9 files into /mnt/project/ root (overwrite existing):

| file | action | reason |
|---|---|---|
| spec.md | overwrite | v2.4 clean canonical, HOT_CACHE current, insights 1-17 + 25-28 + 30 retained |
| project_instructions.md | overwrite | v2.4 canonical, matches v2.3 cutpaste already live (no re-paste) |
| skills.md | overwrite | v2.4 tree, sprint skills archived |
| tandem_session_orchestration.md | overwrite | v1.2, xlsx refs removed |
| task_spec_template.md | overwrite | v1.2, sprint refs removed |
| TASK_CHAT_BOOTSTRAP.md | add | paste-in-first-msg for new tandem chats |
| counter_intel_skill.md | overwrite | v1.1, sprint examples removed, core discipline retained |
| Rubric_Correction_Wiki_Log.md | overwrite | chronological record with cleanup provenance |
| Rubric_Correction_Wiki_Index.md | overwrite | refreshed with archive section |

---

## step 2: delete contaminated files

Delete these files from /mnt/project/ root:

### sprint/xlsx core (delete entirely)
| file | reason |
|---|---|
| final_sprint_workflow.md | sprint-only content, pivot canceled |
| autoqc_reverse_graph.md | tied to sprint xlsx, not applicable to standard intake |
| SESSION_HANDOFF_2026-04-22_FINAL_SPRINT_PIVOT.md | sprint pivot handoff, obsolete |

### obsolete hot-cache updates (merged into new spec.md)
| file | reason |
|---|---|
| spec_md_HOT_CACHE_update_2026-04-22.md | sprint-era, merged into new spec.md |
| spec_md_HOT_CACHE_update_2026-04-22_TANDEM.md | superseded by TANDEM_v2 (also now archived) |
| spec_md_HOT_CACHE_update_2026-04-22_TANDEM_v2.md | content merged into new spec.md |
| spec_md_HOT_CACHE_update_v881_v5.md | task 881 v5 era, superseded |

### obsolete handoffs (chained forward into new Wiki_Log)
| file | reason |
|---|---|
| SESSION_HANDOFF_2026-04-21_task_881_v5.md | task 881 closed, handoff obsolete |
| SESSION_HANDOFF_2026-04-21_task_883.md | task 883 submitted, handoff obsolete |

### obsolete cleanup recommendations (this file replaces)
| file | reason |
|---|---|
| file_cleanup_recommendations_2026-04-21.md | superseded |
| file_cleanup_recommendations_v2_2026-04-22.md | superseded (had sprint language) |

### obsolete wiki log appends (merged into new Rubric_Correction_Wiki_Log.md)
| file | reason |
|---|---|
| Wiki_Log_append_2026-04-22.md | merged into full log |
| Wiki_Log_append_2026-04-22_v2.md | merged into full log |

### superseded skills
| file | reason |
|---|---|
| counter_surveillance_anti_hack.md | superseded by counter_intel_skill.md |

### optional deletes (ask before removing, may still be useful as reference)
| file | question |
|---|---|
| bootstrap.md | auto-inject is live via project_instructions.md cutpaste; this file obsolete. DELETE recommended. |
| ARCHIVE_DISPATCH.md | one-time dispatch artifact. DELETE recommended. |
| atomic_split_decision.md | keep (live skill) |
| conditional_row_coverage_gap.md | keep (live skill) |
| coverage_map_method.md | keep (live skill) |
| cutpaste_row_format.md | keep (live skill) |
| justify_templates_9forms.md | delete (superseded by v3) |
| justify_templates_9forms_v3.md | keep (live current) |
| qc_v2_reverse_graph.md | keep (live skill) |
| studio_edit_verification.md | keep (live skill) |
| rubric_correction_simulated_diagnostic.md | keep (live skill) |
| INSIGHT_2026-04-21_qc_template_prefix_dedup.md | keep (insight record, insight 17 provenance) |
| initial_state_TASK_702_*.md + .pdf | one-time intake artifact. DELETE recommended if task closed. |
| PROJECT_INSTRUCTIONS_CUTPASTE_v2.1.md | older version, superseded by v2_3. DELETE recommended. |
| PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md | keep (matches live protocol in settings) |
| Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md | delete (superseded by v4/v5) |
| Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v3_HARD_FIX.md | delete (superseded by v4/v5) |
| Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v4_FINAL_FIX.md | keep (exemplar Type C second) |
| Rubric_Correction_Task_883_LinkedIn_Coach_2026-04-21_ANALYSIS.md | keep (exemplar analysis) |
| Rubric_Correction_Task_883_LinkedIn_Coach_2026-04-21_CUTPASTE.md | keep (exemplar original) |
| Rubric_Correction_Task_883_LinkedIn_Coach_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md | keep (exemplar Type D) |
| rubric_correction_simulated_diagnostic.md | keep (live skill) |

### keep (canon + exemplars, do NOT delete)
| file | reason |
|---|---|
| Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf | canon day onboarding |
| Rubrics_Correction___Project_Onboarding_copy_2026_04_21_night.pdf | canon night onboarding (authoritative) |
| Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md | canon wiki |
| Mastering_Rubric_Justification_and_Review_Score_Card | canon justify templates |
| protocol_mandate.png | canon visual blueprint |
| TASK_443_Most_Recent_Cut_and_Paste_Full_Task_Prompts_and_Rubric_ | Type A exemplar |
| Task_614_Original_with_Rubric_Suggestions | Type B original input |
| Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_CUTPASTE.md | Type B exemplar |
| Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_COVERAGE_MAP.md | Type B coverage map |
| Rubric_Correction_Task_720_Wrestling_Event_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md | Type C exemplar |
| metrics_ledger.md | silent telemetry |
| Writer_Dash_Mercor_studio_RL_4212026.png | Studio UI reference |
| time_shot.png | one-time reference (keep or archive per preference) |
| Screenshot_20260421_232416.png | one-time reference (keep or archive per preference) |
| Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf | canon |
| Rubric_Correction_Task_720_Wrestling_Event_2026-04-21_CUTPASTE.md (if present) | keep |
| initial_state_changes_TASK_702_*.pdf | one-time artifact (delete if task closed) |

---

## step 3: verify auto-inject still clean

1. Start a new chat in this project.
2. First message: "what's loaded?"
3. Expected: Claude lists v2.3 protocol blocks (no <sprint_workflow>), offers first-move steps, ready for standard intake.
4. If Claude mentions sprint/xlsx/Adi/AHT/bonus tier, re-paste PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md code block into Claude Project settings "Set project instructions" and save.

---

## step 4: start 2 tandem task chats

1. Open new chat A in this project.
2. Paste first message: code block from TASK_CHAT_BOOTSTRAP.md + initial Studio state for task A.
3. Open new chat B in this project.
4. Paste first message: code block from TASK_CHAT_BOOTSTRAP.md + initial Studio state for task B.
5. Each chat creates its own spec_TASK_NNN.md, runs coverage map, produces CUTPASTE.
6. This chat (orchestrator) remains open to validate cross-task conflict + batch-promote insights at task close.

---

## post-cleanup file count target

Before: ~60 files in /mnt/project/ (including sprint artifacts, obsolete handoffs, duplicate cleanup recs).
After: ~35 files in /mnt/project/ (canon + live skills + mutable state + exemplars).

Net reduction: ~25 files removed.

---

END_DELETE_LIST
