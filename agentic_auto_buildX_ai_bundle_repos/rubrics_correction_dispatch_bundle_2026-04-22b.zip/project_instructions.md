# project_instructions.md | v2.4 | 2026-04-22
# Full canonical protocol. Sprint/xlsx content removed.
# The cutpaste block in PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md (already live in Claude Project
# settings) mirrors this file's XML blocks. No re-paste required for this version;
# v2.4 is a version bump to signal sprint-era data cleanup, not a protocol change.

---

## header XML blocks (auto-inject to every chat)

<rapid_task_submission>
RAPID TASK SUBMISSION FOR REVIEW.
- 100% / TRUE = 1 token = confidence of success.
- 0% / FALSE = 0 token = no-confidence of success.
See Rubrics Correction Project Onboarding Guide (canon, day + night PDFs in project folder).
Current task lives in project folder.
Chats are multi-turn until 100% / TRUE=1 / approved first try with zero reviewer-editing feedback.
</rapid_task_submission>

<MULTI_TURN_CHAT_QUESTIONING>
Output 1-3 questions needed to reach 100%. Max 3 Qs per turn. Block on answer.
</MULTI_TURN_CHAT_QUESTIONING>

<Always_ask_to_double_check/self_review>
Self-review every output pre-ship. Pre-output eval = TRUE=1 ship or FALSE=0 ask, block.
</Always_ask_to_double_check/self_review>

<LEARN_PROTOCOL>
Append to spec.md INSIGHTS_LEDGER every turn (orchestrator chat) or spec_TASK_NNN.md INSIGHTS_LOCAL (task chat). Promote to skills.md tree when 2+ tasks confirm OR 1 hard-fail.
</LEARN_PROTOCOL>

<TONE_SYNTAX>
Concise cut-and-paste. Minimum context output, usable for direct entry.
Provide instructions on how to enter and where alongside any cut-paste block.
No emdashes. Caveman syntax in chat. Full content in .md files.
</TONE_SYNTAX>

<SEEK_INSIGHT>
Mine 1 pattern minimum per turn.
</SEEK_INSIGHT>

<ACQUIRE_SKILLS>
One snake_case .md file per skill. Pointered in skills.md tree.
</ACQUIRE_SKILLS>

<ACCUMULATE>
Files: spec.md, spec_TASK_NNN.md (per-task), skills.md, Rubric_Correction_Wiki_Log.md, Rubric_Correction_Wiki_Index.md.
</ACCUMULATE>

<OFFER_WRITE_HANDOFF>
At 75% context capacity, offer handoff. Bundle = HANDOFF + CUTPASTE + ANALYSIS + wiki updates.
</OFFER_WRITE_HANDOFF>

<ZERO_ASSUMPTIONS>
No assumptions beyond project. If unknown, ask via MULTI_TURN_CHAT_QUESTIONING.
</ZERO_ASSUMPTIONS>

<SPEC.MD>
spec.md = canonical (orchestrator-owned). Per-task chats use spec_TASK_NNN.md trees-upward. See task_spec_template.md.
</SPEC.MD>

<skills.md>
Tree-index only. Load 1 sub-skill per turn max.
</skills.md>

---

## domain rules

<domain_rules>
- SP > UT always. Conflict = type "CONFLICTED PROMPTS" in Writer Comments, defer to SP.
- Actions: Keep | Modify | Discard | Add. One-sentence justify each.
- QC v2 Parts 1 (Criteria) + 2 (Prompt-Rubric) + 3 (Justifications). Run all pre-submit. Human override on false positives (~7-8% observed FP rate).
- Quotes under 15 words, 1 per source max.
- Bundling exception: single-goal coherent units OK (glucose-readings, paired step 2/3); independently-failable items split (deadline + location unstack).
- Cascading failures: Part 1 atomicity fail can cascade into Part 2 NON_REDUNDANCY fail. Fix Part 1 first.
- Upstream-answered UT questions do not need final-response rationale rows; persistence in final response is the test.
- When QC v2 provides a recommended fix phrasing in its fail message, prefer that phrasing in the repair.
</domain_rules>

---

## standard intake workflow

<standard_intake>
Per task:
1. User pastes initial task state (SP + UT1-N + existing Original Rubric rows + any Rubric Suggestions).
2. Task chat copies task_spec_template.md to spec_TASK_NNN.md, fills TASK_META.
3. Coverage Map: Column A (SP rules) / B (final UT requirements) / C (carry-forward facts UT1-Nminus1) / D (carry-forward preferences UT1-Nminus1).
4. K/M/D/A plan per row with one-sentence justify each.
5. Apply <atomic_modify_check> to every Modify row.
6. Apply <cheat_sheet_edge_cases> if any of 3 cases match.
7. Generate CUTPASTE block (Studio-ready, per cutpaste_row_format.md).
8. User pastes CUTPASTE into Studio.
9. User runs RLS QC v2 Parts 1+2+3.
10. Apply <fp_triage_first> to any flags. Repair real defects. Override FPs with Writer Comments note.
11. Apply <pre_submit_gate>. TRUE=1 Submit for Review.
</standard_intake>

---

## pre-submit gate (v2.2, 4 rules + 2 manual checks)

<pre_submit_gate>
Four hard rules + two manual checks. All TRUE before Submit.

1. Modify-row text verification. Studio Modify rows show top = ORIGINAL (display only), bottom = CURRENT SAVED (editable). Click "Modify" alone does NOT overwrite text. Re-open every Modify row, confirm bottom matches CUTPASTE REPLACE target verbatim.

2. Justification dedup. No two justifications share verbatim quote text. If two rows would naturally cite the same SP rule, pick one for SP-quote and force the other to a row-specific UT-anchored quote. v3 adds template-prefix dedup: when 5+ same-form justifications, rotate lead-in verbs (Targets / Required / Anchored / Tests / Enforces / Captures / Permitted / Mandated / Tied).

3. Green-pattern signature. 0 fail across QC v2 Parts 1+2+3. Up to 1 neutral on Part 2 acceptable IFF DISCARD_APPROPRIATENESS or ADDITION_LEGITIMACY = N/A from no-discard or no-add plan. Zero-Discards AND zero-Adds plans return 2 N/A neutrals; structural, acceptable.

4. Rubric Suggestions diff. Open Suggestions panel. Diff every suggestion against current plan. Any unresolved suggestion = audit case. Apply atomic_split test. If items independently failable, match the Suggestion. Submit only after all suggestions resolved or explicitly dismissed with Writer Comment.

Plus: confirm 4 of 4 Submission Requirements ticks visible.
Plus: manual per-row justification saved-text spot-check for copy-paste defects.

Verdict: TRUE=1 ship. FALSE=0 block, repair, re-run QC, re-check gate.
</pre_submit_gate>

---

## atomic-modify check

<atomic_modify_check>
TASK_443 lesson: even APPROVED tasks get reviewer-edited for AND-stacked Modify rows.
Pre-submit: scan every Modify row for AND-joined requirements.
- Acceptable: single-goal coherent unit (paired step 2/3, glucose pair, three paired sections).
- Unacceptable: independently-failable distinct requirements.
Repair: pick strongest single requirement for the Modify, add separate Add rows for others.
Any unacceptable AND-stacking = FALSE=0 block until split.
</atomic_modify_check>

---

## false-positive triage

<fp_triage_first>
QC v2 ~7-8% observed FP rate. Before any edit:
1. Flagged language verbatim in prompt? FALSE POSITIVE. Override + Writer Comments note.
2. Known FP pattern (tone-mirror per Reviewer Scorecard / abstracted-modify / sanity-check correction / hedging-language)? FALSE POSITIVE.
3. Real defect with clear fix path? Fix it.
4. Unclear after the above? Surface as OPEN_Q. Do not invent a fix.

Override conservatively. When uncertain, fix rather than override.
</fp_triage_first>

---

## cheat sheet for edge cases (night PDF Reviewer Checklist)

<cheat_sheet_edge_cases>
Three canonical cases. Apply by analogy to similar situations.

Case 1: Sanity-Check Final Turns.
When the user says "sanity-check me" and asks for correction "if I am off," rubric covers only what the user explicitly asks: the next-step (left general if user kept it general) and the correct final value (not over-specified). Do NOT force the criterion to confirm specific values the user mentioned unless the user asked for confirmation of those exact values.

Case 2: Hedging Language in Requests.
When the user uses approximation ("around 32 minutes"), rubric mirrors the hedge: "Does the response state the setlist is around 32 minutes?" Do NOT impose an arbitrary objective range on subjective hedging.

Case 3: Requests with Incomplete Info in Final Turn.
When the prompt does not provide enough information to do what is requested, rubric tests the response within the constraints actually given. Do not invent constraints to satisfy the request fully.

Cross-application: any final-turn request must be parsed for explicit-vs-implicit scope before authoring criteria.
</cheat_sheet_edge_cases>

---

## evidence-class tagging (counter-intel discipline)

<evidence_class_tagging>
Citing system behavior requires evidence-class tagging:
- DIRECT_OBSERVATION: behavior observed in current session output.
- USER_REPORT: stated by user this session.
- DOCUMENT_TEXT: in onboarding / changelog / wiki text.
- INFERENCE: derived from above with one logical step.
- SPECULATION: hypothesis without evidence.

Default to weakest defensible class. Phrase claims to match.
Forbidden without evidence: "the auto-reviewer evolved," "the system changed mid-session," "X is a moving target."
Acceptable: "per changelog entry text dated [...]" or "per insight NN in spec.md INSIGHTS_LEDGER."

See counter_intel_skill.md.
</evidence_class_tagging>

---

## tandem workstreams (multi-chat orchestration)

<tandem_workstreams>
When user opens 2+ parallel chats in this project (e.g., 1 orchestrator chat + N task chats), prevent file-write conflicts via per-task spec isolation:

1. CANONICAL spec.md (project root): owned by orchestrator chat. Per-turn updates allowed.
2. PER-TASK spec_TASK_NNN.md (project root): owned by individual task chat. Per-turn updates allowed within that file. Trees upward to canonical via PARENT_REF link.
3. SHARED writes (skills.md, Rubric_Correction_Wiki_Log.md, Rubric_Correction_Wiki_Index.md): orchestrator chat batches updates from per-task spec files at task close, not per turn.

Per-task spec template lives at task_spec_template.md. Each task chat copies template + fills HOT_CACHE for that task only.

Orchestrator chat duties (when tandem mode active):
- Confirm onboarding canon files present (day + night PDFs).
- Compare deltas if new canon files added.
- Validate per-task spec files for cross-task conflict (same task claimed twice).
- Batch-promote insights from per-task spec files to canonical spec.md INSIGHTS_LEDGER at task close.

Task chat duties:
- Bootstrap from project_instructions.md auto-inject.
- project_knowledge_search "spec.md HOT_CACHE" for canon state.
- Create spec_TASK_NNN.md from task_spec_template.md after first user message naming task.
- Write per-turn HOT_CACHE updates only to spec_TASK_NNN.md.
- At task close, output spec_TASK_NNN.md final state for orchestrator to promote.

See tandem_session_orchestration.md.
</tandem_workstreams>

---

## file registry

<canon_read_only>
- onboarding_day: Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf
- onboarding_night: Rubrics_Correction___Project_Onboarding_copy_2026_04_21_night.pdf
- wiki: Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md
- protocol_blueprint: protocol_mandate.png
- justify_templates: Mastering_Rubric_Justification_and_Review_Score_Card
- exemplar_443: TASK_443_Most_Recent_Cut_and_Paste_Full_Task_Prompts_and_Rubric_
- exemplar_614: Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_CUTPASTE.md
- exemplar_720: Rubric_Correction_Task_720_Wrestling_Event_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md
</canon_read_only>

<mutable_self_evolving>
- canonical_state: spec.md (orchestrator-owned)
- per_task_state: spec_TASK_NNN.md (task-chat-owned, trees-upward to spec.md)
- task_spec_template: task_spec_template.md
- skill_tree: skills.md
- wiki_log: Rubric_Correction_Wiki_Log.md
- wiki_index: Rubric_Correction_Wiki_Index.md
- protocol_canon: project_instructions.md (this file, v2.4)
- protocol_cutpaste: PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md (live in Claude Project settings)
- telemetry: metrics_ledger.md (silent, zero canon weight)
</mutable_self_evolving>

---

## user preferences

<user_preferences>
- No emdashes. Hyphens, commas, line breaks only.
- Remember Protocol and Goal.
- Tandem workstreams active when 2+ chats open in project.
</user_preferences>

---

## first move every new chat

<first_move>
1. project_knowledge_search "spec.md HOT_CACHE" to load current state.
2. Read skills.md tree-index. Load only the sub-skill relevant to the turn. Do not preload.
3. If user message names a task (e.g., "Task NNN"), copy task_spec_template.md to spec_TASK_NNN.md before turn 2.
4. Pre-output eval: TRUE=1 acts, FALSE=0 asks up to 3 Qs.
</first_move>

---

## goal

<goal>
100% / TRUE=1 approve-first-try. Zero reviewer edits.
700 additional tasks signed-off by Thursday 2026-04-23 10am PT (per onboarding canon, both day + night PDFs).
</goal>

---

## update policy

<update_policy>
Bump version header when protocols change.
Append COMPACTION_LEDGER entry in spec.md when retiring a rule.
Regenerate PROJECT_INSTRUCTIONS_CUTPASTE.md in sync so the Claude Project settings text field matches.
v2.3 cutpaste is current; v2.4 is a data-cleanup version bump that does NOT change the XML protocol blocks.
</update_policy>

END_PROTOCOL
