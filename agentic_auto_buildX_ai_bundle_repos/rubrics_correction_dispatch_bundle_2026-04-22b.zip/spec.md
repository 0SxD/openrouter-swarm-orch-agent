# spec.md | CANONICAL HANDOFF & COM. STREAM
# v2.4 clean | 2026-04-22 | sprint/xlsx references pruned per user directive
# Canon: Rubrics Correction Project Onboarding (day + night PDFs).

<zero_bloat_protocol>
Assume each turn is terminal. Do not retain chat history.
Execute all state-saves directly to spec.md using strict structured fields to minimize token cost.
Maintain 3-tier memory architecture:
  1. HOT_CACHE: max 500 words. Immediate next actions + active vars only.
  2. GRAPH_LINKS: minimalist pointers to external files/skills. No inline content.
  3. COMPACTION_LEDGER: record of hard-pruned context. Zero token leakage.
Main chat output: cave-man syntax only.
Block skill bloat. Compress all semantic reasoning before writing to disk.
</zero_bloat_protocol>

---

## HOT_CACHE
<!-- max 500 words | next actions + active vars | overwrite each turn -->

STATUS: CLEAN STATE RESTORED 2026-04-22. Sprint/xlsx contamination purged from canonical state + supporting files per user directive. Project back to standard-intake working state. Ready for tandem task chats (2 parallel workstreams).

SESSION_TYPE: orchestrator, cleanup batch 1. 10 replacement files produced.

ACTIVE_TASK: none (cleanup mode). 2 tandem task chats pending user start.

NEXT_ACTION: user (a) drops batch 1 files into /mnt/project/ root, (b) deletes listed contaminated files per DELETE_LIST_2026-04-22.md, (c) opens 2 new chats in this project for tandem task work, (d) pastes initial Studio task state in each.

ACTIVE_VARS:
- protocol_version: v2.3 cutpaste already live in Claude Project settings (sprint-free). No re-paste required.
- canon_onboarding: day PDF + night PDF both active. Night PDF adds Cheat Sheet for Edge Cases + onboarding-closed changelog entry.
- tandem_mode: active. Orchestrator owns spec.md; task chats own spec_TASK_NNN.md per tandem_session_orchestration.md.
- exemplars_live: TASK_443 (Type A, approved then reviewer AND-stacked edits), task_614 (Type B, approved), task_720 (Type C, hard-fail -> surgical recovery), task_881 v5 (Type D, P3 dedup fix, submitted).
- pending_reviewer_verdict: task_720, task_883, task_881 v5 (per prior handoffs, not overwritten here).
- pre_submit_gate: v2.2 with 4 rules (modify-text verify, justify dedup, green signature, rubric suggestions diff). Retain.
- insights_retained: 1-17 (pre-sprint, canonical), 25-28 (non-sprint, tandem + night PDF cheat sheet + TASK_443 stacking + goal correction). See INSIGHTS_LEDGER.
- insights_pruned: 18-24 (sprint/xlsx-specific), 29 (xlsx revisor pool). See COMPACTION_LEDGER.

CONFIDENCE: TRUE=1 for cleanup batch 1 as produced. FALSE=0 on batch 2 readiness until user drops batch 1 + deletes contaminated files.

---

## GRAPH_LINKS
<!-- pointers only, no inline content -->

### canon (read-only)
- onboarding_day: project://Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf
- onboarding_night: project://Rubrics_Correction___Project_Onboarding_copy_2026_04_21_night.pdf
- wiki: project://Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md
- protocol_blueprint: project://protocol_mandate.png
- justify_templates: project://Mastering_Rubric_Justification_and_Review_Score_Card
- exemplar_443: project://TASK_443_Most_Recent_Cut_and_Paste_Full_Task_Prompts_and_Rubric_
- exemplar_614: project://Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_CUTPASTE.md
- exemplar_720: project://Rubric_Correction_Task_720_Wrestling_Event_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md
- exemplar_881_v5: project://Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v4_FINAL_FIX.md

### mutable self-evolving
- canonical_state: project://spec.md (this file)
- per_task_state: project://spec_TASK_NNN.md (task-chat-owned, trees-upward via PARENT_REF)
- task_spec_template: project://task_spec_template.md
- skill_tree: project://skills.md
- wiki_log: project://Rubric_Correction_Wiki_Log.md
- wiki_index: project://Rubric_Correction_Wiki_Index.md
- protocol_canon: project://project_instructions.md (v2.3, sprint-free)
- protocol_cutpaste: project://PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md
- telemetry: project://metrics_ledger.md (silent, zero canon weight)

### skills (live)
- coverage_map: project://coverage_map_method.md
- atomic_split: project://atomic_split_decision.md
- conditional_gap: project://conditional_row_coverage_gap.md
- cutpaste_format: project://cutpaste_row_format.md
- justify_templates: project://justify_templates_9forms_v3.md
- studio_verify: project://studio_edit_verification.md
- qc_reverse: project://qc_v2_reverse_graph.md
- rubric_suggestions_priority: project://qc_rubric_suggestions_priority.md (pending_draft; rule in pre_submit_gate active)
- tandem_orchestration: project://tandem_session_orchestration.md
- simulated_diagnostic: project://rubric_correction_simulated_diagnostic.md
- counter_intel: project://counter_intel_skill.md

### cleanup bundle (this session)
- spec_clean: outputs://spec.md (this file, v2.4)
- delete_list: outputs://DELETE_LIST_2026-04-22.md
- wiki_log_append_final: outputs://Rubric_Correction_Wiki_Log.md
- wiki_index_refresh: outputs://Rubric_Correction_Wiki_Index.md
- task_chat_bootstrap: outputs://TASK_CHAT_BOOTSTRAP.md

---

## COMPACTION_LEDGER
<!-- record of pruned content with replacement pointer -->

- [2026-04-21] PRUNED: older v2.0 XML protocol without <pre_submit_gate>. REPLACEMENT: v2.1 with 3 gate rules from task_720 hard-fail.
- [2026-04-21] PRUNED: v2.1 pre_submit_gate (3 rules). REPLACEMENT: v2.2 with rule 4 (Rubric Suggestions diff) from task_883 pre-submit audit.
- [2026-04-22 W1] PRUNED: goal "1,000 tasks by EOD Wednesday 4/22." REPLACEMENT: "700 additional tasks signed-off by Thursday 4/23 10am PT" per onboarding canon both PDFs.
- [2026-04-22 W1] PRUNED: <sessions_parallel_split> A/B file refs (obsolete v2.0 pattern). REPLACEMENT: <tandem_workstreams> per-task spec isolation (v2.2+).
- [2026-04-22 W1] PROMOTED: TASK_443 stacking lesson from user-report to canonical rule (<atomic_modify_check> + atomic_split_decision.md update).
- [2026-04-22 W2] PRUNED: <sprint_workflow> block + all references to Final Sprint xlsx revisor workflow. REPLACEMENT: standard intake only (original project workflow). Reason: user not in revisor pool; sprint not applicable to current task chats.
- [2026-04-22 W2] PRUNED: insights 18-24 (sprint/xlsx-specific) + 29 (revisor pool note). REASON: not applicable to standard intake workflow. Skill files final_sprint_workflow.md + autoqc_reverse_graph.md flagged for delete. Historical preserved in Wiki_Log for audit.
- [2026-04-22 W2] PRUNED: SESSION_HANDOFF_2026-04-22_FINAL_SPRINT_PIVOT.md + spec_md_HOT_CACHE_update_2026-04-22.md + spec_md_HOT_CACHE_update_2026-04-22_TANDEM.md. REPLACEMENT: this spec.md + DELETE_LIST_2026-04-22.md.

---

## TASK_QUEUE

- tandem task A: pending user paste of initial Studio task state in new chat.
- tandem task B: pending user paste of initial Studio task state in new chat.
- task_720: AT STUDIO, submitted v2, awaiting reviewer verdict.
- task_883: AT STUDIO, submitted v2, awaiting reviewer verdict.
- task_881 v5: AT STUDIO, submitted (or override-comment if P2 infra persisted), awaiting reviewer verdict.

---

## INSIGHTS_LEDGER
<!-- 1 pattern minimum per turn. Promote to skills.md when 2+ tasks confirm OR 1 hard-fail. -->

### [2026-04-20] insight 1: column_d_preferences_scan
Coverage map needs Col D for earlier-turn preferences (taste, comfort, cost). Each classified EXPLICIT / IMPLICIT / GAP. PROMOTED: folded into coverage_map_method.md step 1.

### [2026-04-20] insight 2: implicit_chain_coverage_doctrine
A pref is acceptably IMPLICIT only when violation necessarily fails an absorbing row. PROMOTED: coverage_map_method.md.

### [2026-04-20] insight 3: upstream_question_doctrine
UT questions answered upstream do NOT need final-response rationale rows; persistence in final response is the test. PROMOTED: spec.md RULES.

### [2026-04-21 T3] insight 4: studio_modify_text_must_verify
Studio Modify shows top=ORIGINAL bottom=SAVED. Click-Modify alone does NOT overwrite. Re-open and verify bottom matches CUTPASTE. HARD-FAIL from task_720. PROMOTED: studio_edit_verification.md.

### [2026-04-21 T3] insight 5: justification_dedup_mandatory
QC Part 3 ENGAGEMENT_QUALITY flags verbatim-identical justifications. HARD-FAIL from task_720. PROMOTED: justify_templates_9forms.md v2 DEDUP_RULE.

### [2026-04-21 T3] insight 6: cascading_part1_to_part2_failures
One Part 1 atomicity fail can cascade into Part 2 NON_REDUNDANCY fail. Fix Part 1 first. PROMOTED: spec.md RULES.

### [2026-04-21 T3] insight 7: qc_v2_dimension_counts_decoded
Part 1 = 4 dims, Part 2 = 5 dims, Part 3 = 2 dims + per-criterion. PROMOTED: qc_v2_reverse_graph.md.

### [2026-04-21 T2] insight 8: bundled_instruction_exception
Single-goal bundles ok in one row; independently-failable items must split. PROMOTED: atomic_split_decision.md.

### [2026-04-21 T2] insight 9: conditional_row_coverage_gap
"When X, does..." rows pass vacuously if X never occurs. Add inclusion partner row. PROMOTED: conditional_row_coverage_gap.md.

### [2026-04-21 T2] insight 10: qc_part2_format_drift
Auto-reviewer Part 2 output format non-deterministic between runs. Conclusions stable. Track format mode. PROMOTED: qc_v2_reverse_graph.md note.

### [2026-04-21 T2] insight 11: two_neutrals_no-d-no-a_acceptable
Plan with 0-Discards AND 0-Adds returns 2 N/A neutrals; structural, not concerning. Refines GREEN-PATTERN. PROMOTED: qc_v2_reverse_graph.md update.

### [2026-04-21 T2] insight 12: keep_justification_fill_default_pattern
When all rows are Keep with placeholder justifications, Form 4 (UT-grounded) is default. Pick distinct UT clause per row. PROMOTED: justify_templates_9forms.md note.

### [2026-04-21 T3] insight 13: qc_v2_atomicity_blind_spot
QC Part 1 false-positive bundled-exception when items independently failable. Rubric Suggestions panel authoritative. HARD-FAIL from task_883. PROMOTED: qc_rubric_suggestions_priority.md (rule active in pre_submit_gate).

### [2026-04-21 T3] insight 14: justification_copy_paste_defect
Studio copy-paste of justifications across rows produces wrong-quote defects QC Part 3 misses (regenerates own rationales). HARD-FAIL from task_883. PROMOTED: pre_submit_gate spot-check rule.

### [2026-04-21 T4] insight 15: paired_step_bundling_exception
Paired step 2/3 assignments in sequential correction are single-goal bundles, not stack. Hard-fail from task_881 v2 split attempt. PROMOTED: atomic_split_decision.md update.

### [2026-04-21 T4] insight 16: qc_own_recommended_phrasing_rule
When QC v2 provides a recommended fix in its fail message, prefer that phrasing in the repair. Reduces iteration. PROMOTED: spec.md RULES.

### [2026-04-21 T4] insight 17: template_prefix_dedup_rule
Justification template prefix diversity needed when 5+ same-form justifications. Lead-in verb rotation (Targets / Required / Anchored / Tests / Enforces / Captures / Permitted / Mandated / Tied). PROMOTED: justify_templates_9forms_v3.md.

### [2026-04-22 W1] insight 25: task_443_post_approval_reviewer_atomic_modify_correction
TASK_443 was APPROVED by auto-QC then reviewer post-approval simplified R2 + R4 because they had AND-stacked requirements. Auto-QC v2 does NOT reliably catch all AND-stacking on Modify rows. Manual atomic-modify scan required pre-submit. EVIDENCE_CLASS: USER_REPORT. PROMOTED: <atomic_modify_check> in project_instructions.md v2.3 + atomic_split_decision.md update.

### [2026-04-22 W1] insight 26: night_pdf_cheat_sheet_three_cases
Night onboarding PDF adds Cheat Sheet for Edge Cases in Reviewer Checklist with 3 cases: sanity-check final turns, hedging language, incomplete-info requests. EVIDENCE_CLASS: DOCUMENT_TEXT. PROMOTED: <cheat_sheet_edge_cases> in project_instructions.md v2.3.

### [2026-04-22 W1] insight 27: tandem_chat_file_isolation_via_per_task_spec
Multi-chat parallel work conflicts on shared file writes. Solution = per-task spec_TASK_NNN.md files trees-upward to canonical. Orchestrator owns canonical, task chats own per-task files. Shared writes batched at task close. EVIDENCE_CLASS: INFERENCE. PROMOTED: <tandem_workstreams> in project_instructions.md v2.3 + tandem_session_orchestration.md.

### [2026-04-22 W1] insight 28: goal_update_to_700_by_thursday
Both day + night PDFs show "Final Delivery: 700 additional tasks complete by Thursday 4/23 10am PT." Prior versions carried older number. EVIDENCE_CLASS: DOCUMENT_TEXT. PROMOTED: goal block.

### [2026-04-22 W2] insight 30: canonical_state_cleanup_beats_protocol_bump
When a pivot (sprint) gets canceled, the cheapest restore is pruning DATA files (spec.md, handoffs) while keeping the protocol block unchanged if it was already correct. Avoids re-paste ceremony. Bump version only when protocol itself changed. EVIDENCE_CLASS: DIRECT_OBSERVATION (v2.3 protocol already clean; only data needed purge).

---

## OPEN_Q

- none active. All sprint-era open questions resolved by pruning.

---

## RULES

### protocol (from project_instructions.md v2.3, sprint-free)
- SP > UT always. Conflict = "CONFLICTED PROMPTS" in Writer Comments, defer to SP.
- Actions: Keep | Modify | Discard | Add. One-sentence justify each.
- QC v2 Parts 1+2+3 pre-submit. Human override on FPs (~7-8% FP rate observed).
- Quotes under 15 words, 1 per source max.
- Bundling exception: single-goal coherent units OK; independently-failable items split.
- Cascading fails: Part 1 first, then Part 2, then Part 3.
- Upstream-answered UT questions do not need final-response rationale rows.
- When QC provides recommended fix phrasing in its fail message, prefer that phrasing.

### pre-submit gate rules (v2.2, four rules + two manual checks)
1. Modify-row text verification (top vs bottom line; verify saved bottom matches CUTPASTE REPLACE target).
2. Justification dedup (no verbatim-identical quote strings across rows; v3 template-prefix rule).
3. Green signature: 0 fail across P1+P2+P3. Up to 1 P2 neutral acceptable IFF DISCARD or ADDITION N/A from no-discard or no-add plan.
4. Rubric Suggestions diff: open Suggestions panel, diff every suggestion, match Suggestions on atomicity disagreements.
Plus: confirm 4 of 4 Submission Requirements ticks. Plus: manual per-row justification saved-text spot-check for copy-paste defects.
TRUE=1 ship. FALSE=0 block.

### atomic-modify check
Pre-submit scan: every Modify row for AND-joined requirements.
- Acceptable: single-goal coherent unit (paired step 2/3, glucose pair).
- Unacceptable: independently-failable distinct requirements.
Repair: pick strongest single requirement for the Modify, add separate Add rows for others.

### cheat sheet for edge cases (night PDF Reviewer Checklist)
- Case 1 Sanity-Check Final Turns: cover only what user explicitly asks; do not over-specify.
- Case 2 Hedging Language: mirror the hedge; do not impose objective range.
- Case 3 Incomplete-Info Requests: test response within constraints actually given; do not invent constraints.

### evidence-class tagging (counter-intel discipline)
DIRECT_OBSERVATION / USER_REPORT / DOCUMENT_TEXT / INFERENCE / SPECULATION.
Default to weakest defensible class. Phrase claims to match.

### tandem workstreams
- spec.md = canonical, orchestrator-owned, per-turn updates allowed.
- spec_TASK_NNN.md = per-task, task-chat-owned, trees-upward via PARENT_REF.
- Shared writes (skills.md, Wiki_Log, Wiki_Index): orchestrator batches at task close.
- Task chat: copy task_spec_template.md to spec_TASK_NNN.md after first user message names task.

---

## user preferences

<user_preferences>
- No emdashes. Hyphens, commas, line breaks only.
- Remember Protocol and Goal.
- Tandem workstreams active when 2+ chats open in project.
</user_preferences>

---

## first move every new chat

<first_move>
1. project_knowledge_search "spec.md HOT_CACHE" to load current state.
2. Read skills.md tree-index. Load only the sub-skill relevant to the turn. Do not preload.
3. If user message names a task (e.g., "Task NNN"), copy task_spec_template.md to spec_TASK_NNN.md before turn 2.
4. Pre-output eval: TRUE=1 acts, FALSE=0 asks up to 3 Qs.
</first_move>

---

## goal

<goal>
100% / TRUE=1 approve-first-try. Zero reviewer edits.
700 additional tasks signed-off by Thursday 2026-04-23 10am PT (per onboarding canon both PDFs).
</goal>

END_SPEC
