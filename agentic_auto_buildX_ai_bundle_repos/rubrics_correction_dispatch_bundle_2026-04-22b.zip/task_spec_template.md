# task_spec_template.md | per-task spec file template | v1.2 clean 2026-04-22
# Copy this file to spec_TASK_NNN.md at task chat turn 1 (after first user message names the task).
# Fill in TASK_META. Update HOT_CACHE_LOCAL per turn. Trees upward to canonical spec.md.

---

## TASK_META

- task_id: NNN
- task_slug: <short-slug>
- task_type: A | B | C | D (see exemplars below)
- claimed_at: YYYY-MM-DD HH:MM PT
- task_chat_id: <chat identifier or human label>
- parent_ref: spec.md canonical
- orchestrator_chat_id: <orchestrator chat identifier>
- status: intake | coverage_map | plan | cutpaste | studio_paste | qc_run | pre_submit_gate | submitted | reviewer_pending | approved | sent_back

### task type reference (from exemplars)
- Type A: fresh intake, typically 5-10 existing rows + 2-4 Adds. Exemplar: TASK_443.
- Type B: revision-heavy, most rows Keep with justification-fill. Exemplar: task_614.
- Type C: hard-fail then surgical recovery cycle. Exemplar: task_720.
- Type D: pre-submit audit catches QC blind spot. Exemplar: task_883.

---

## HOT_CACHE_LOCAL
<!-- max 500 words | next actions + active vars for THIS task | overwrite each turn -->

STATUS: <current state of the task>
NEXT_ACTION: <immediate next action for user or chat>

ACTIVE_VARS:
- task_NNN_coverage_map_state: <col A/B/C/D summary>
- task_NNN_plan_state: <K/M/D/A counts and per-row decisions>
- task_NNN_cutpaste_state: <drafted / pasted / re-pasted>
- task_NNN_qc_state: <P1 X/Y/Z, P2 X/Y/Z, P3 X/Y/Z>
- task_NNN_pre_submit_gate: <per-rule TRUE/FALSE>

CONFIDENCE: TRUE=1 | FALSE=0

---

## INSIGHTS_LOCAL
<!-- append per turn; NOT promoted to canonical spec.md until task close -->

### [DATE TN] insight_local_<N>: <slug>
<One-paragraph summary.>
Evidence class: DIRECT_OBSERVATION | USER_REPORT | DOCUMENT_TEXT | INFERENCE | SPECULATION.
Promote intent: yes (2+ tasks confirm) | yes (hard-fail) | no (local only).
Promote_to_skill: <slug> | none.

---

## TASK_CLOSE_PROMOTION
<!-- fill at task close, hand to orchestrator -->

### wiki_log_draft
One line for Rubric_Correction_Wiki_Log.md.

### insights_to_promote
List insight_local_<N> entries with promote intent = yes. Orchestrator lifts to canonical spec.md INSIGHTS_LEDGER at task close.

### skill_suggestions
Any promote_to_skill: <slug> tags surfaced during task. Orchestrator creates the skill .md file.

### metrics_row
One pipe-delimited row for metrics_ledger.md (per telemetry schema).

---

## GRAPH_LINKS (per-task)

- canonical_state: project://spec.md
- task_exemplar: project://<relevant exemplar per task type>
- subskills_loaded: <list of skills used in this task>
- outputs_produced: <list of files written to /mnt/user-data/outputs/ during task>

---

## per-turn update pattern

Each turn:
1. Read HOT_CACHE_LOCAL STATUS + NEXT_ACTION for prior turn state.
2. Execute next action (coverage map / plan / cutpaste / QC audit / pre-submit gate / submit).
3. Overwrite HOT_CACHE_LOCAL with new STATUS + NEXT_ACTION + updated ACTIVE_VARS.
4. Append to INSIGHTS_LOCAL any pattern mined this turn.
5. Self-review: pre-output eval TRUE=1 ship or FALSE=0 ask.

---

## at task close

1. Fill TASK_CLOSE_PROMOTION fully.
2. Output final spec_TASK_NNN.md to /mnt/user-data/outputs/ via present_files.
3. Prompt user to drop into /mnt/project/ root.
4. Alert orchestrator chat to read and promote.
5. Set TASK_META.status = submitted | approved (after reviewer verdict).

END_TEMPLATE
