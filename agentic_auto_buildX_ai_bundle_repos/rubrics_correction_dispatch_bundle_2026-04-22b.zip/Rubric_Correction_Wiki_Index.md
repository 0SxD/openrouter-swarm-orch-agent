# Rubric_Correction_Wiki_Index.md

Updated: 2026-04-22 (post-cleanup)

---

## Protocol (canon, read-only)
- [[Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf]] day onboarding
- [[Rubrics_Correction___Project_Onboarding_copy_2026_04_21_night.pdf]] night onboarding (adds Cheat Sheet for Edge Cases + onboarding-closed entry)
- [[Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md]] wiki synthesis
- [[protocol_mandate.png]] visual protocol blueprint
- [[Mastering_Rubric_Justification_and_Review_Score_Card]] justify templates + reviewer scorecard

## Protocol (mutable, self-evolving)
- [[project_instructions.md]] v2.4 full canonical XML protocol
- [[PROJECT_INSTRUCTIONS_CUTPASTE_v2_3.md]] paste-ready cutpaste for Claude Project settings (already live)

## State (mutable)
- [[spec.md]] v2.4 canonical state, orchestrator-owned
- [[skills.md]] v2.4 tree-index
- [[Rubric_Correction_Wiki_Log.md]] chronological record
- [[metrics_ledger.md]] silent telemetry

## Per-task state
- [[task_spec_template.md]] v1.2 template for spec_TASK_NNN.md
- [[TASK_CHAT_BOOTSTRAP.md]] paste-in-first-msg for new tandem chats

## Skills (live)

### core
- [[rubric_correction_simulated_diagnostic.md]] offline QC checklist

### formatting
- [[cutpaste_row_format.md]] Studio-ready row format
- [[justify_templates_9forms_v3.md]] 9 forms + dedup + template-prefix rule

### analysis
- [[coverage_map_method.md]] 4-col audit
- [[atomic_split_decision.md]] bundle vs split decision tree
- [[conditional_row_coverage_gap.md]] vacuous-pass gap detection

### studio_ops
- [[studio_edit_verification.md]] Modify-row top-vs-bottom verification

### reverse_engineering
- [[qc_v2_reverse_graph.md]] v2 with GREEN-PATTERN + passing-leaf templates

### session_ops
- [[tandem_session_orchestration.md]] v1.2 multi-chat orchestration

### epistemic
- [[counter_intel_skill.md]] v1.1 evidence-class tagging discipline

## Exemplars (task type references)
- [[TASK_443_Most_Recent_Cut_and_Paste_Full_Task_Prompts_and_Rubric_]] Type A (approved, reviewer stacking fix post-approval)
- [[Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_CUTPASTE.md]] Type B (approved first-try, revision-heavy)
- [[Rubric_Correction_Task_614_Northbridge_Memo_2026-04-20_COVERAGE_MAP.md]] Type B coverage map
- [[Task_614_Original_with_Rubric_Suggestions]] Type B original input
- [[Rubric_Correction_Task_720_Wrestling_Event_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md]] Type C (hard-fail -> surgical recovery)
- [[Rubric_Correction_Task_883_LinkedIn_Coach_2026-04-21_CUTPASTE_v2_SURGICAL_FIX.md]] Type D (pre-submit audit catches QC blind spot)
- [[Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v4_FINAL_FIX.md]] Type C second exemplar (paired-step bundling + P3 dedup)

## Archive (do NOT load)
- [[final_sprint_workflow.md]] archived 2026-04-22 (sprint canceled, user not in revisor pool)
- [[autoqc_reverse_graph.md]] archived 2026-04-22 (tied to sprint xlsx, not applicable)
- [[counter_surveillance_anti_hack.md]] archived (superseded by counter_intel_skill.md)

## Log
- [[Rubric_Correction_Wiki_Log.md]]

END_WIKI_INDEX
