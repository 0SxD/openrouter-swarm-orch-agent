# TASK_CHAT_BOOTSTRAP.md | paste-in-first-msg for new tandem task chats
# 2026-04-22 | matches project_instructions.md v2.4 + spec.md v2.4

---

## where to use

When opening a new chat in this project for a task, paste the code block below as the FIRST message, then append your task intake state (SP + user turns + existing rubric rows + any Rubric Suggestions).

The Claude Project instructions (v2.3 cutpaste in settings) auto-inject. This bootstrap confirms tandem mode, loads spec.md HOT_CACHE, and sets the first-turn expectations.

---

## bootstrap block

```
<tandem_task_chat_bootstrap>
TANDEM TASK CHAT. Orchestrator chat is active in parallel. This chat owns spec_TASK_NNN.md for the task about to be named.

First-turn actions:
1. project_knowledge_search "spec.md HOT_CACHE" to load canonical state.
2. Read skills.md tree-index. Load only sub-skill relevant to first action.
3. After I name the task (e.g., "Task 207") and paste initial state, copy task_spec_template.md to spec_TASK_NNN.md and fill TASK_META.
4. Check /mnt/project/ for existing spec_TASK_NNN.md. If present with another chat's claimed_at timestamp, YIELD and tell me to pick a different task.
5. Otherwise proceed with standard_intake steps 1-11.

Rules:
- Do NOT write to canonical spec.md. Only spec_TASK_NNN.md.
- Insights stay in spec_TASK_NNN.md INSIGHTS_LOCAL until task close.
- At task close, output spec_TASK_NNN.md final state + WIKI_LOG_DRAFT + INSIGHT_PROMOTION block for orchestrator to promote.

Canon files:
- onboarding day + night PDFs.
- exemplars: TASK_443 (Type A), 614 (Type B), 720 (Type C), 883 (Type D).
- protocol: project_instructions.md v2.4 / PROJECT_INSTRUCTIONS_CUTPASTE_v2_3 (auto-injects).

Goal: 100% / TRUE=1 approve-first-try. Zero reviewer edits.

Initial task state follows this block.
</tandem_task_chat_bootstrap>
```

---

## paste pattern

Turn 1 message:
```
<paste the bootstrap block above>

Task NNN
<paste Studio SP + user turns 1-N + existing rubric rows + any Rubric Suggestions text>
```

Claude's first reply should:
- Confirm tandem mode active.
- Report spec.md HOT_CACHE status loaded.
- Create spec_TASK_NNN.md from task_spec_template.md (via create_file).
- Begin Coverage Map (Col A/B/C/D).
- End with TRUE=1 (ready for plan draft) or FALSE=0 (up to 3 clarifying Qs).

---

## sync rule

If project_instructions.md bumps version (v2.4 -> v2.5 etc.), re-check this bootstrap block for drift. Update canon file references and goal text as needed.

END_BOOTSTRAP
