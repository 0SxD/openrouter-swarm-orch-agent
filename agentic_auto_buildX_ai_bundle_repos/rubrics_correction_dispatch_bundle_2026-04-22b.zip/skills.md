# skills.md | rubrics-correction skill tree
# POINTERS ONLY. NO INLINE CONTENT. Prevents context overload.
# v2.4 clean | 2026-04-22 | sprint-era skills removed from live status, flagged archived.

## read_protocol (mandatory)
1. Read THIS file first to discover available sub-skills.
2. Load only the sub-skill relevant to the current move. Do NOT preload.
3. Max 1 sub-skill per turn unless user explicitly requests more.
4. If sub-skill is STATUS: pending, note in spec.md OPEN_Q, do not invent content.
5. After task closes, promote new patterns via insight_promotion rules.

## status legend
- live: file exists in /mnt/project/, content ready.
- pending_draft: registered but not yet written. Do not hallucinate.
- pending_extraction: content lives in a canon source, needs distillation.
- analysis_ready: inputs staged, awaiting processing.
- archived: obsolete or superseded. Do NOT load.

## tree

### core
| slug | summary | path | status |
|---|---|---|---|
| rubrics_correction_core | 8-step playbook: coverage map -> K/M/D/A -> justify -> QC v2 -> CUTPASTE | project://rubrics_correction_core.md | pending_draft |
| rubric_correction_simulated_diagnostic | offline mental-run QC checklist, Parts 1-3 | project://rubric_correction_simulated_diagnostic.md | live (v1.1) |

### formatting
| slug | summary | path | status |
|---|---|---|---|
| cutpaste_row_format | Studio-ready 3-col row (Row N / Action / Criterion / Justify) + Studio entry order footer | project://cutpaste_row_format.md | live |
| justify_templates_9forms | 9 canonical justification forms + DEDUP_RULE + template-prefix diversity rule | project://justify_templates_9forms_v3.md | live v3 |

### analysis
| slug | summary | path | status |
|---|---|---|---|
| coverage_map_method | 4-col SP x final-UT x carry-forward-facts x carry-forward-prefs audit before K/M/D/A | project://coverage_map_method.md | live |
| atomic_split_decision | when to split vs bundle; glucose (bundle) vs deadline+location (split); paired-step exception | project://atomic_split_decision.md | live |
| conditional_row_coverage_gap | "When X, does..." vacuous-pass gap + inclusion-row partner pattern | project://conditional_row_coverage_gap.md | live |
| conflict_protocol | "CONFLICTED PROMPTS" flag + SP-over-UT defer workflow | project://conflict_protocol.md | pending_extraction (source: onboarding Step 3) |

### studio_ops (UI-level procedures)
| slug | summary | path | status |
|---|---|---|---|
| studio_edit_verification | FIND/REPLACE for Modify rows + post-edit text-field verification (top vs bottom line) | project://studio_edit_verification.md | live |

### reverse_engineering
| slug | summary | path | status |
|---|---|---|---|
| qc_v2_reverse_graph | decoded 4 Part-1 dims + 5 Part-2 dims + 2 Part-3 dims + GREEN-PATTERN signature + passing-leaf templates | project://qc_v2_reverse_graph.md | live v2 |
| qc_rubric_suggestions_priority | Rubric Suggestions authoritative over QC Part 1 on atomicity; pre-submit diff | project://qc_rubric_suggestions_priority.md | pending_draft (rule active in pre_submit_gate) |

### session_ops
| slug | summary | path | status |
|---|---|---|---|
| tandem_session_orchestration | multi-chat per-task spec isolation, orchestrator vs task chat duties, conflict rules | project://tandem_session_orchestration.md | live v1.2 |
| handoff_bundle | triple-file handoff (HANDOFF + CUTPASTE + ANALYSIS) + wiki log/index update at 75% | project://handoff_bundle.md | pending_draft |
| insight_promotion | 2-tasks-or-hardfail rule to move insight from spec.md INSIGHTS_LEDGER to a new sub-skill | project://insight_promotion.md | pending_draft |

### epistemic
| slug | summary | path | status |
|---|---|---|---|
| counter_intel | evidence-class tagging discipline, default to weakest defensible class, forbidden speculation phrases | project://counter_intel_skill.md | live v1.1 |

## registry rules
- New sub-skill = new row here + new snake_case .md file at project root.
- Row fields: slug, summary (<=12 words), path, status.
- Slug = snake_case, matches filename without .md.
- No inline content in this file. Reader MUST follow path.
- Status transitions: pending_draft -> live (on file write). pending_extraction -> live (on distillation). analysis_ready -> live (on analysis complete). live -> archived (on obsolescence).
- Deprecate: move obsolete row to archive section at bottom.

## archive
<!-- obsolete sub-skills, kept for audit reference only; do NOT load -->

- final_sprint_workflow | sprint-era Google Sheet revisor workflow | project://final_sprint_workflow.md | archived 2026-04-22 (sprint canceled / user not in revisor pool)
- autoqc_reverse_graph | backend AutoQC script reverse-graph for sprint xlsx flags | project://autoqc_reverse_graph.md | archived 2026-04-22 (tied to sprint xlsx, not applicable to standard intake)
- counter_surveillance_anti_hack | early counter-intel draft, superseded by counter_intel_skill.md | project://counter_surveillance_anti_hack.md | archived (superseded)

END_SKILLS
