# session_plan_v1.md
# Created: 2026-04-23 in S1 turn 3
# Owner: Sage
# Purpose: multi-session roadmap for Anthropic Prompt Engineer Claude Code application.
# Rationale: 143_Protocol_a Section 2 zero-context-persistence rule. Per-topic sessions prevent context rot.

## session ordering

Each session opens with a clean boot per 143_Protocol_a Section 2 three-step sequence:
1. Read governance (1_INSTALL.md, spec.md HOT_CACHE, skills.md).
2. Read assigned brain regions (the session's topic canon list below).
3. Scan working directory for any deltas since last session.

Then session proceeds. Closes with file writes that patch canon and spec.md.

---

## S1: CONTEXT DUMP + BOOTSTRAP (IN PROGRESS, TURN 3)

Status: closing in turn 3 with 4 file writes.
Topic: full life-context absorption, canon defect correction (Educational Enterprises), tech-stack acknowledgment.
Output this turn: spec_delta_2026-04-23_round01_turn03.md, canon_corrections_2026-04-23.md, handoff_to_dispatch/OPEN_Q_BATCH_01.md, session_plan_v1.md (this file).
Verdict: TRUE=1 on closure. Sage re-uploads these 4 files to Project folder.

---

## S2: COLLEGE + EARLY FINANCE ARC (QUEUED)

Topic span: 1995 through 2007. Collegiate HS, Costa Rica gap year, UVM transfer year, Columbia BA International Political Economy, MIT Sloan StartingBloc 3-year fellowship, Citicorp intern, Merrill Lynch intern, Trillium Trading proprietary equity trader.

Boot read list:
- canon/austin_resume_corpus_index.md (post-corrections)
- canon/MASTER_RESEARCH_HANDOFF_v2.md Parts C + D
- canon_corrections_2026-04-23.md CORRECTION 02, 03, 04, 05

Expected OPEN_Q in S2:
- Exact Costa Rica gap year dates
- UVM exact course / major if relevant
- Columbia GPA (3.5 per v2014_docx vs 3.3 per vFeb2020 skills block, though likely refers to different contexts)
- Trillium Trading: Series 7 + 55 context for resume, plus any trading-strategy IP that is NOT excluded under IP Tier 1
- StartingBloc TerraCycle + GreenSoles: public-mentionable in resume Activities section, or defer to LinkedIn
- Whether any Collegiate School achievements beyond "full scholarship, wrestling state champ" belong on the application package

Deliverable: S2 canon delta + updated resume timeline spine 1995-2007.

---

## S3: FINANCE SPINE (QUEUED)

Topic span: May 2007 through January 2015. Interaudi Bank (Credit Portfolio Officer, 4 years), NYU Graduate Diploma in Credit Analysis (2009-13), RBS Citizens (VP Credit Portfolio Manager + Treasury Technical Sales, 3 years, plus Toastmasters district leader 2 years), Morgan Stanley Private Bank (VP Tailored Lending UHNW Portfolio Manager + Underwriter, 8 months).

Boot read list:
- canon/austin_resume_corpus_index.md
- canon/MASTER_RESEARCH_HANDOFF_v2.md Part D
- canon_corrections_2026-04-23.md CORRECTION 07 (Toastmasters)
- resume v2011 + v2014_docx + v2014_pdf (finance-era primary sources)

Expected OPEN_Q in S3:
- Interaudi specific deal examples permissible on resume (non-NDA, non-client-specific)
- RBS policy-rewrite project: specific named project name or "credit policy rewrite in the commercial card portfolio"
- Morgan Stanley exit reason (optional, only if needed for Ohr Sameach narrative bridge)
- Any Basel / Dodd-Frank specific certifications vs general familiarity

Deliverable: S3 canon delta + resume timeline spine 2007-2015.

---

## S4: TEACHING + TRANSITION (QUEUED)

Topic span: 2015 through 2023. Ohr Sameach Jerusalem (2016-17), Relay Graduate School M.Ed. (2017-19), NYC DOE Bronx 7-year tenure (Sept 2017 to June 2023, MS328 / Bronx Academy of the Arts), CS4ALL program creation + leadership, Private Homeschool lead educator (2023-24), Amergis Staffing (Aug 2024-Aug 2025), Fullmind / LingoAce / Bilin Academy (2024-present).

Boot read list:
- canon/austin_resume_corpus_index.md
- canon/MASTER_RESEARCH_HANDOFF_v2.md Parts C + D
- resume vFall2019 + vFeb2020 + vDec2025 both (teaching-era primary sources)
- OPEN_Q_BATCH_01 OQ-03 answer (Ohr Sameach inclusion decision)

Expected OPEN_Q in S4:
- Ohr Sameach framing if included (see OQ-03)
- Sigma 2 (DARPA research idea): public-mentionable in resume, or sensitive?
- Specific NYC DOE impact metrics (40% test-score lift in year 1 is on early resumes; validate for inclusion)
- CS4ALL cohort details permissible
- Private homeschool student: protect privacy, generic framing only

Deliverable: S4 canon delta + resume timeline spine 2015-2023.

---

## S5: FATExDAO (QUEUED)

Topic span: 2021 through end-TBD. Co-founded with Corey Caplan and Adam Knuckey of Dolomite. Harmony blockchain DEX, Uniswap / SushiSwap fork patterns, gold-linked pool utility, Polygon / Ethereum migration attempt. Green Paper authored. Concluded with transition of direction into SAGEx Research LLC.

Boot read list:
- canon/austin_resume_corpus_index.md FATExDAO row (post-OQ-01 resolution)
- canon/MASTER_RESEARCH_HANDOFF_v2.md Part D + Part H (IP exclusions specific to trading / FATExDAO)
- resume v032026 FATExDAO bullet (most-recent public framing)
- OPEN_Q_BATCH_01 OQ-01 + OQ-08 answers

Expected OPEN_Q in S5:
- Green Paper public release status (is it published? where?)
- Specific fundraising figure confirmation (MASTER_RESEARCH_HANDOFF says ~$80M)
- What can be said publicly vs what is IP-locked per Section 4 (trading strategies, FxD_build_notes all locked)
- Adam / Corey attribution finalized per OQ-08

Deliverable: S5 canon delta + resume FATExDAO bullet (1-2 lines) + Why Anthropic essay raw material.

---

## S6: 0sXAi + TECHNICAL SPINE (QUEUED)

Topic span: 2024 through present. SAGEx Research LLC founding, 0sXai architecture (8-module symbolic cognitive arch, Trinity Dialectic, ACCE Memory, MI9 Economic Layer, Event-Sourced Identity split-plane), Nautilus Trader strategies with locked DTMC 3x3, Shadow B pipeline design, Strategy Module Population (9 module groups, ~150 atomic indicators), MakerDAO fork, claude-obsidian Claude Code plugin, this very project (dispatch / protocol OS).

Boot read list:
- canon/austin_resume_corpus_index.md SAGEx Research + Mercor rows
- canon/MASTER_RESEARCH_HANDOFF_v2.md Parts E + F + H
- /mnt/user-data/uploads/Symbolic_Symbolic_Arch_Dialectic_Overview_2026_04_15.md (pending full read)
- /mnt/user-data/uploads/symbolic-language-spec-v0_1.md (pending full read)
- /mnt/user-data/uploads/0sXai_architecture_diagram.html (pending full read)
- /mnt/user-data/uploads/3_10_26_The_Shadow_B_Framework__Probabilistic_Modeling_and_GPU_Acceleration.pdf (read in S1)
- /mnt/user-data/uploads/3_10_2026_Strategy_Module_Population_Draft_comments_docx.pdf (read in S1)
- OPEN_Q_BATCH_01 OQ-02 + OQ-06 answers

Expected OPEN_Q in S6:
- TypeScript code: claude-obsidian, Nautilus UI plugins, other?
- Which GitHub repos under 0SxD are public-ready now vs require IP scrub first
- Whether the 0sXai architecture diagram + Event-Sourced Identity + neuro-symbolic infographics are public-publishable (they appear to be NotebookLM-generated) or internal
- Whether Nautilus Trader strategy proof is publishable (backtests) vs locked per IP Tier 1
- Which MakerDAO fork repo + visibility status

Deliverable: S6 canon delta + coding-evidence section for resume + portfolio-repo plan for S9.

---

## S7: WHY ANTHROPIC ESSAY CO-WRITE (QUEUED)

Topic: 200-400 word essay per Greenhouse form. Sage drafts first, Claude refines, Sage issues PEL.

Boot read list:
- All canon files current as of S6 close
- Anthropic candidate-AI guidance at https://www.anthropic.com/candidate-ai-guidance
- JD responsibility lanes + fit signals (cached from Greenhouse fetch in S1 turn 1)
- spec.md INSIGHTS 06 + 07 (chain-of-thought directive engineering, nested PEL 3x3x3)
- Sage's fictional book title + gap-year + StartingBloc + 20-year convergence arc for color

Expected OPEN_Q in S7:
- Thread choice confirmed from turn 2 Q2: (i) connectome-grounded alignment, (ii) 20-year convergence, (iii) why-Claude-specifically, (iv) all-three 3-paragraph
- Word-count target inside 200-400 range
- Whether Ohr Sameach belongs in the essay narrative

Deliverable: final essay + PEL packet for Sage approval.

---

## S8: RESUME VARIANT WRITING (QUEUED)

Topic: invoke skills/resume_variant_writer.md twice. Produce resume_anthropic_prompt_engineer_v1 + resume_anthropic_applied_research_v1. Both clear pre_submit_gate v1.0 rules 1-3 silently before Sage sees Architecture + Evidence + Intent triplet for PEL verdict.

Boot read list:
- canon/austin_resume_corpus_index.md (fully patched through S6)
- All canon_corrections files
- All OPEN_Q answered
- skills/resume_variant_writer.md
- skills/pre_submit_gate.md
- skills/ip_scrub_pre_publish.md

Deliverable: 2 resume variants in .md + .docx + .pdf + the 2 Architecture + Evidence + Intent packets.

---

## S9: PORTFOLIO REPO + GITHUB PUSH AUDIT (QUEUED)

Topic: lay out sage-prompt-engineering-portfolio repo. Contents: root README, 143_protocol_a/, trinity_dialectic/, why_anthropic_essay_archive/, selected biomimicry paper(s) cleaned, ACCE memory arch note, chain-of-thought-directive-engineering technique exposition. Run gitleaks and ip_scrub on diff before push.

Boot read list:
- All canon current
- skills/ip_scrub_pre_publish.md
- skills/pre_submit_gate.md
- skills/github_pre_push_audit.md (pending_draft, likely promoted to live by this session)
- MASTER_RESEARCH_HANDOFF_v2.md Part H (IP exclusions full)

Expected OPEN_Q in S9:
- Which biomimicry papers to include (6-file series plus 3 uncatalogued drafts per MASTER_RESEARCH_HANDOFF)
- Repo visibility: public from commit 1 or private-to-public on clean-sweep confirmation
- commit email final per OQ-04 (sagexresearch@gmail.com per MASTER_RESEARCH_HANDOFF vs other)

Deliverable: repo contents final, gitleaks PASS, IP scrub PASS, Sage issues PEL, push executes.

---

## S10: GREENHOUSE SUBMISSION PACKAGE (QUEUED)

Topic: assemble Greenhouse 5159669008 form. Upload resume PE variant. Fill Why Anthropic. Fill AI usage policy YES. Fill logistics Qs. Sage hits submit.

Boot read list:
- Final resume PE variant (from S8)
- Why Anthropic essay (from S7)
- Greenhouse form schema (fetched S1 turn 1)
- skills/greenhouse_submission_packager.md (pending_draft, likely promoted by this session)

Expected OPEN_Q in S10:
- Relocation answer (SF / NYC / Seattle)
- Start date earliest
- Visa sponsorship Y / N
- "Have you interviewed at Anthropic before" Y / N
- Self-ID disclosures at Sage's discretion

Deliverable: form filled, Sage hits submit, confirmation screenshot saved to project.

---

## governance rule

S-order can be shuffled at Sage's discretion. Recommended dependency chain:
- S2-S6 can happen in any order EXCEPT S6 (technical spine) is BEST after the context sessions so the technical framing lands against the broader story.
- S7 (essay) blocks on S5 + S6 for material.
- S8 (resume) blocks on S2-S6 + OPEN_Q_BATCH_01 answers.
- S9 (portfolio) blocks on S6 + S8.
- S10 (submit) blocks on S7 + S8.

Minimum critical path to submit: S2 + S3 + S4 + S5 + S6 + S7 + S8 + S10. (S9 optional pre-submit; Sage can push portfolio post-submit if time-pressed.)

END_SESSION_PLAN
