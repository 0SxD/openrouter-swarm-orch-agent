# handoff_to_dispatch/OPEN_Q_BATCH_01.md
# Status: updated to S1 turn 3 (2026-04-23)
# Owner: Sage
# Purpose: load-bearing questions that gate P0 work. Sage answers, files update.

## the 4 still-open questions gating P0

### OQ-01: FATExDAO end date (START is CONFIRMED 2021, END is open)

GATES: T01 resume PE variant, T02 resume AR variant, T04 LinkedIn rewrite, T05 portfolio README if FATExDAO gets a repo entry.

CONFLICT: 2023 (resume v032026) vs March 2025 (LinkedIn per MASTER_RESEARCH_HANDOFF).

CANONICAL_ENTRY_PRODUCED: FATExDAO end-date field in austin_resume_corpus_index.md career table.

PROVISIONAL_DEFAULT: none; hard-block. Cannot pick silently between a 2-year gap.

SAGE_ANSWER (fill this in):
- End date: ________
- Reason for conflict: ________


### OQ-02: sageXresearch LLC start date

GATES: T01 resume PE variant, T02 resume AR variant, T04 LinkedIn rewrite.

CONFLICT: 2024 (resume v032026) vs August 2023 (LinkedIn per MASTER_RESEARCH_HANDOFF).

CANONICAL_ENTRY_PRODUCED: SAGEx Research LLC start-date field in austin_resume_corpus_index.md.

PROVISIONAL_DEFAULT: none; hard-block.

SAGE_ANSWER (fill this in):
- Start date: ________
- Reason for conflict: ________


### OQ-03: Ohr Sameach on public resume

GATES: T01 resume PE variant, T02 resume AR variant, T04 LinkedIn rewrite (optional), portfolio About.

CONTEXT: April 2016 to early 2017, Jerusalem, Talmud + Torah intensive. Bridges career-gap between Morgan Stanley exit (Jan 2015) and NYC DOE entry (Sept 2017). Sage indicated verbal yes to override the STRICT EXCLUSION flag in MASTER_RESEARCH_HANDOFF. Awaiting written confirmation plus preferred phrasing.

CANONICAL_ENTRY_PRODUCED: Ohr Sameach row in Education table of austin_resume_corpus_index.md gets status=canonical vs status=suppressed.

PROVISIONAL_DEFAULT: suppress (current canon status = pending). If no answer, Ohr Sameach does NOT appear on PE resume; gap remains unaddressed; Sage risks Greenhouse reviewer question about "what were you doing Jan 2015 to Sept 2017".

SAGE_ANSWER (fill this in):
- Include on resume: YES / NO
- If YES, preferred phrasing (choose one or write own):
  (a) "Ohr Sameach Institutions, Jerusalem. Talmud and Torah intensive. 2016-2017."
  (b) "Ohr Sameach Institutions, Jerusalem. Intermediate and advanced Talmud and Gemara. 2016 to 2017."
  (c) own phrasing: ________
- Include on LinkedIn: YES / NO
- Separate narrative treatment in Why Anthropic essay: YES / NO


### OQ-08 (NEW this turn): Corey Caplan + Adam Knuckey attribution

GATES: T01 resume PE variant (FATExDAO bullet), T02 resume AR variant, T04 LinkedIn rewrite, T03 Why Anthropic essay if co-founder story is part of the arc, T05 portfolio README if FATExDAO gets a repo entry.

CONTEXT: Sage confirmed this turn that FATExDAO was co-founded with Corey Caplan and Adam Knuckey of Dolomite (dolomite.io). This is now in canon. Question is: how explicit in public artifacts?

OPTIONS:
(a) Name both co-founders in resume bullet. e.g., "Co-founded FATExDAO with Corey Caplan and Adam Knuckey of Dolomite."
(b) Name Dolomite only. e.g., "Co-founded FATExDAO with the Dolomite team."
(c) Generic "co-founded with partners at a neighboring DEX protocol".
(d) Drop attribution entirely; just "Co-founded FATExDAO".

CANONICAL_ENTRY_PRODUCED: attribution_style field in FATExDAO canonical row.

PROVISIONAL_DEFAULT: option (b), name Dolomite only, as conservative professional-standard.

SAGE_ANSWER (fill this in):
- Attribution choice: (a) / (b) / (c) / (d)
- If (c), specify wording: ________


## the LIKELY-OK set (Sage just confirms or flags)

Already resolved to most-recent canon per date_conflict_reconciler rung 4. Sage simply confirms or flags one line.

- OQ-04 Morgan Stanley exit: Jan 2015? (Y / N / correction: ________)
- OQ-05 NYC DOE end: June 2023? (Y / N / correction: ________)
- OQ-06 Mercor / Micro1 start: October 2025? (Y / N / correction: ________)
- OQ-07 [SUPERSEDED] Educational Enterprises span: RESOLVED this turn. Sage confirmed it is his father's company. See canon_corrections_2026-04-23.md.

## resolved this turn (no Sage action required)

- OQ-05 (from turn 2: chain-of-thought system identity): RESOLVED. System IS nested Pathos / Ethos / Logos 3x3x3 DTMC / SJM, operationalization of 143_Protocol_a Section 5. See spec.md INSIGHT 07.
- OQ-07 (from turn 2: Educational Enterprises canon): RESOLVED. Father's company, not Sage's. See canon_corrections_2026-04-23.md.
- Q3 from turn 2 (coding evidence F + E + G): RESOLVED. Sage's Shadow B + Strategy Module Pop + Nautilus + 0sXai + MakerDAO fork constitute the evidence trace. See spec.md INSIGHT 08.

## minimum viable answer format

Sage can paste this back filled in. One turn unblocks T01 + T02 + T04:

```
OQ-01: [end date]
OQ-02: [start date]
OQ-03: [Y/N, phrasing if Y]
OQ-08: [a/b/c/d]
OQ-04: [Y/correction]
OQ-05: [Y/correction]
OQ-06: [Y/correction]
```

END_OPEN_Q_BATCH_01
