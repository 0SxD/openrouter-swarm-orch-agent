# canon_corrections_2026-04-23.md
# Source: Sage's context dump in S1 turn 3
# Target: canon/austin_resume_corpus_index.md
# Status: apply on next canon refresh. These are Sage-chat-confirmations (precedence rung 1).

## CORRECTION 01: Educational Enterprises LLC reassignment

**Defect:** Corpus index and 4 resume versions (v2014_pdf, vFall2019, vFeb2020, vDec2025 both, v032026) present Educational Enterprises LLC as Sage's founded-and-led venture. This is wrong.

**Sage-confirmed truth:** Educational Enterprises LLC is Sage's father's company. Sage's father bought 2 Sylvan Learning Centers in 2001-02 and has operated the company since. Sage's father is now essentially retired except for occasional students. Sage tutored there off and on during his Columbia undergrad (2001-06) and occasionally after. Sage did NOT found it, did NOT manage it, is NOT an owner.

**Canon edit:**

Replace existing Educational Enterprises / Ivy Tutors row in "career (conflicts surfaced)" table with:

| role | employer | dates | source consensus | notes |
|---|---|---|---|---|
| Tutor (intermittent, family business) | Educational Enterprises LLC (Sage's father's company, Sylvan Learning affiliation) | 2001 to present, intermittent | Sage chat 2026-04-23 | NOT Sage's venture. Father founded in 2001-02. Sage helped during Columbia undergrad and occasionally since. Use conservative resume framing only if space permits. |

**Resume handling guidance:**
- REMOVE any "Founder" or "Managing Director" framing for Educational Enterprises.
- Either drop the line entirely from the Anthropic PE resume (space is the premium) OR render as: "Tutor, Educational Enterprises LLC (family business), intermittent 2001 to present" with no elaboration.
- Ivy Tutors / Ivy League Tutors: canon this as a separate item with span TBD. Sage's resume v2011 says "founder" with 2001-03 span. Sage's chat this turn says he was "tutoring other kids how to get into the science high schools in NYC since then on the side". Retain provisionally as early independent tutoring, exact formal founding date TBD (not gating P0, queue for S4).

## CORRECTION 02: Collegiate School canonization

**Add to "education" table:**

| institution | dates | credential | source | status |
|---|---|---|---|---|
| The Collegiate School | 1995-99 | HS diploma, full scholarship, wrestling (state champ), opera, academics | Sage chat 2026-04-23, MASTER_RESEARCH_HANDOFF | canonical; founded 1628, oldest school in USA; NYC; chose over Horace Mann and Trinity |

## CORRECTION 03: Columbia degree name

**Existing canon says:** "BA International Political Economy"
**Sage confirmation:** "International Political Economics"
**Both occur in corpus.** Resume v2014_pdf and v032026 use "International Political Economy". Sage's chat this turn uses "International Political Economics". These are effectively synonymous at Columbia (the program has been styled both ways). CANON: use "International Political Economy" on resume (matches most-recent v032026). Note the synonym for LinkedIn About if Sage prefers.

## CORRECTION 04: UVM confirmation

UVM 2000-01, 1-year transfer, canonized. Public-artifact policy: mention on LinkedIn Education section is optional. Not needed on resume given space. Queue for S2.

## CORRECTION 05: MIT Sloan / StartingBloc expansion

**Existing canon says:** "Fellowship in Corporate Social Responsibility (2005)" or "2005-2007" or one-year fellowship.

**Sage confirmation this turn:** StartingBloc CSR leadership, 3 years (approximately 2005 to 2008), mentor, admissions committee, TerraCycle business case competition winner, contributed to GreenSoles India pipeline, weekend seminars at rotating business schools with CEOs and MBA professors.

**Canon edit:** Replace existing MIT Sloan row with:

| institution | dates | credential | source | status |
|---|---|---|---|---|
| MIT Sloan StartingBloc Institute Fellowship | 2005-08 | CSR Fellowship, 3 years, mentor, admissions committee, business case winner (TerraCycle), GreenSoles India contributor | Sage chat 2026-04-23, resume corpus | canonical; StartingBloc has likely been sunset since but the fellowship is real and verifiable via archive.org / StartingBloc alumni records |

## CORRECTION 06: FATExDAO dates (partial resolution)

**Start date:** CONFIRMED 2021. Specifically: during COVID, while Sage was teaching in the Bronx (7 years tenure at NYC DOE, started Sept 2017 per canon).

**End date:** still unresolved. 2023 (resume v032026) vs Mar 2025 (LinkedIn per MASTER_RESEARCH_HANDOFF). Sage to answer.

**Co-founder attribution:** Corey Caplan and Adam Knuckey, both from Dolomite (dolomite.io). Sage has been clear this is public attribution but OQ-08 asks for explicit resume / LinkedIn clearance.

**Canon edit:** update FATExDAO row in career table:

| role | employer | dates | source consensus | notes |
|---|---|---|---|---|
| Co-Founder | FATExDAO (with Corey Caplan + Adam Knuckey of Dolomite) | 2021 to END_TBD | Sage chat 2026-04-23 start confirmed; end pending OQ-01 | Harmony blockchain DEX, Green Paper, gold-linked pool, co-founder attribution pending OQ-08 |

## CORRECTION 07: Toastmasters canonization

**Add to skills / activities canon:**

Toastmasters International, district leader for 2 years during RBS Citizens tenure (2011-14). Public speaking, cross-org collaboration evidence. Maps to JD fit-signal I (excel at working across organizational boundaries). Queue for LinkedIn About arc + resume Activities section if space permits.

## CORRECTION 08: Additional ancillary details (canonize, not publish)

- Gap year Costa Rica (post-Collegiate, pre-UVM or pre-Columbia, TBD exact year): queue for S2. Not resume material. Why Anthropic essay material.
- Memoir in progress "Reminiscences of a Prep School Gangster": queue for personal portfolio site, NOT resume, NOT LinkedIn professional sections.
- NYC DOE tenure reframe: "public service: paid my student loans off". Honest framing, queue for potential Why Anthropic essay use.

## CORRECTION 09: Coding evidence canon (new, for JD fit-signal F + E + G)

Sage has a production-quality Python / JAX quant-research corpus and Solidity deployment. Canonize as the coding-evidence trace for JD:

- **Nautilus Trader strategies:** proprietary, DTMC 3x3 locked after 20-year iteration, Fib + BB + Ichimoku integrated, genetic-algorithm validated, not yet deployed live. Sage can demo / display on request. 2025 to present.
- **Shadow B Pipeline (design):** 24-page doc dated 2026-03-10. Python / JAX stack, uses dynamax, google-deepmind/mctx, PyMC, jumpmodels, DEAP, hand-ported fuzzyJM with Gower distance + projected gradient descent. GPU-accelerated via JAX vmap. Reward-dense MDP for MCTS alpha mining. 2026.
- **Strategy Module Population v3 / v5:** 30-page doc dated 2026-03, spec for ~150 atomic boolean indicators across 9 module groups (Spatial Pricing / Fibonacci, Kinematics, Ichimoku Ordering, Relational Distances, Basis-to-Fib Proximity, Volume / Liquidity, Heuristic Pre-Filters, BB / Rainbow / Trailing Stops, Multi-Timeframe + Candlestick) with sweep ranges, FDR correction, research citations.
- **0sXai cognitive architecture:** Trinity Dialectic + ACCE Memory + MI9 Economic Layer + Event-Sourced Identity split-plane. Claude Code plugin (claude-obsidian v1.4.3, 10 skills).
- **MakerDAO fork:** DONE. Status: coding evidence, Solidity.
- **This project (dispatch / protocol OS):** self-evolving Claude Project with domain-adapted compounding-learning OS, forked from dispatch_v2.

Map to JD:
- F (Python + TS): Python confirmed by Shadow B + Strategy Module Pop. TypeScript coverage: needs confirmation from Sage in S6 (claude-obsidian uses TS? Nautilus plugins?).
- E (model-training process + agent scaffolds): confirmed by 0sXai architecture, Shadow B MDP + RL Demonstration Buffer design, and Sage's Imitative Learning / Behavior Cloning approach.
- G (production-incident delivery): FATExDAO mainnet launch on Harmony, DEX migration attempt to Polygon / Ethereum, MakerDAO fork. Counts.

## file precedence note

This canon_corrections file is rung-1 (Sage chat confirmation). Applies immediately. Next Claude turn opening S2 should read this file and update canon/austin_resume_corpus_index.md accordingly before proceeding.

END_CANON_CORRECTIONS
