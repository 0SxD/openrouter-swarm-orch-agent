# LOGOS.md

> This file declares the HOW. Tool registry, skill tree-index (pointers only), ops manifest, output template, slash commands, Python-convertibility schema.
> Kernel stays small. Skills grow laterally under skills/ with pointer rows here, never inline content.

---

## tool registry

Every tool the agent may call. Each entry declares purpose and when to use.

### default registry

| name | purpose | when to use | when NOT to use |
|---|---|---|---|
| read_file | view a file in working dir | any file access needed for task | file already visible in context |
| write_file | create or edit a file | persisting state, wiki updates, artifact output | temporary scratch (use context) |
| web_search | external fact lookup | present-day facts, anything that may have changed since cutoff | well-established historical facts the agent already knows |
| web_fetch | retrieve full page | user provided a URL, need full article content | partial answer sufficient |
| ask_user | multi-turn interrogation | blocker present, confidence < 1.0 | low-stakes decisions |
| code_execute | run code in sandbox | data analysis, artifact generation, verification | pure reasoning tasks |
| conversation_search | find past chats | user references prior conversation | current session has the info |

### project-specific tools

Added during auto_agent_construction turn 3. If user declares MCP servers, external APIs, or custom tools, append rows here.

| name | purpose | when to use | when NOT to use |
|---|---|---|---|
| [project-specific] | [declared during config] | | |

---

## skills tree (pointer index)

Skills live in `skills/` folder, one .md file per skill. Each skill file declares the 9 round-trip invariants (see `python convertibility schema` below).

This file stores POINTERS ONLY. Never inline skill bodies.

### live skills (on first boot: none)

| slug | path | status | sonnet-runnable |
|---|---|---|---|
| [first skill created on first promotion] | | | |

### status legend

- **live:** file written, tested, Sonnet-callable
- **pending_draft:** registered here, body not yet written (do not hallucinate content)
- **pending_extraction:** content exists in canon, awaiting distillation to skill file
- **deprecated:** moved to `skills/archive/`

### skill registration rule

New skill = new row here + new `skills/<slug>.md` file.
Row fields: slug (snake_case, matches filename), path, status, sonnet-runnable (Y or N).
No inline bodies in this file. Reader MUST follow the path to read the skill.

### skill file template (applied when a skill promotes)

Every skill file follows this structure (see auto-generation from insight promotion):

```markdown
# skills/<slug>.md

## name
<slug>

## description
<one line, 12 words or fewer>

## trigger conditions
- <when this skill runs>
- <what precedes it>

## inputs (typed schema)
- <input_1>: <type> - <purpose>

## outputs (typed schema)
- <output_1>: <type> - <purpose>

## tools required
- <tool_name_from_registry>

## model and temperature
- model: <opus | sonnet | haiku>
- temperature: <0.0 to 1.0>

## prompt body
<exact instructions the skill runs with>

## chaining
- follows: [<prev_skill>]
- precedes: [<next_skill>]

## evaluation
- goal-met condition: <specific signal of success>
- max iteration count: <integer, default 5>
- hard-fail escape: <what to do on failure>

## version pin
- spec_version: 1.0
- created: YYYY-MM-DD
- last_updated: YYYY-MM-DD
```

---

## ops (kernel operations)

Three canonical operations on wiki/. Each runs via the skills + tools above.

### op: ingest

**Trigger:** user drops a new source into `wiki/raw/` or pastes content that should become canon.

**Procedure:**
1. Validate source against ETHOS.md rule 1 (approved source type). If not approved, flag and ask.
2. Read source.
3. Summarize into `wiki/raw/<source-slug>.md` (under 300 words, caveman).
4. Discuss key takeaways with user (caveman chat).
5. Update affected wiki pages (target 10 to 15 page touches per ingest).
6. Update `wiki/index.md` with new page + one-line summary.
7. Append `wiki/log.md` entry: `## [YYYY-MM-DD] ingest | <title>`
8. Label the delta on affected pages: `reinforce | weaken | qualify | contradict | create`
9. Flag contradictions with existing pages (surface in log).
10. If ingest reveals repeatable pattern, propose promotion candidate for skills/.

### op: query

**Trigger:** user asks a question that depends on wiki content.

**Procedure:**
1. Read `wiki/index.md` to find relevant pages.
2. Read those pages.
3. Synthesize answer with citations (page names + source refs).
4. If answer is substantial and reusable, propose filing as a new wiki page or skill.
5. Append `wiki/log.md` entry: `## [YYYY-MM-DD] query | <topic>`

### op: lint

**Trigger:** on demand (user typed `/lint` or asked for a health check) or scheduled (every N sessions).

**Procedure:**
1. Scan for contradictions (two pages making opposing claims about same topic)
2. Scan for stale claims (page older than a newer source that should have updated it)
3. Scan for orphan pages (no inbound links after 3 ingest cycles)
4. Scan for missing pages (concepts cited multiple times across the wiki but lacking their own page)
5. Scan for broken `[[wikilinks]]`
6. Propose web_search queries to fill data gaps
7. Present lint report to user. User approves fixes one at a time.

### op: promote

**Trigger:** insight in `wiki/insights.md` raw section has either (a) 2 confirms or (b) 1 hard-fail.

**Procedure:**
1. Read the insight and its context in wiki/log.md
2. Draft a skill file under `skills/<slug>.md` using the skill template
3. Add pointer row to LOGOS.md skills tree
4. Move insight from raw section to promoted section in `wiki/insights.md`
5. Append `wiki/log.md` entry: `## [YYYY-MM-DD] promote | <slug>`
6. Test skill on next applicable task; if eval passes, keep; if fails, roll back and log hard-fail

### op: compound

**Trigger:** user typed `/compound` or agent determines recent turn crystallized durable learning.

**Purpose:** codify recent learnings into the kernel itself. Not just outputs, but the system that produces them.

**Procedure:**
1. Review wiki/log.md entries since last compound op
2. Identify: new patterns, repeated pain points, gate rule candidates, skill candidates
3. For each candidate, propose kernel update:
   - New ETHOS rule (derivation-cited) if a hard-fail occurred
   - New LOGOS skill pointer if a pattern repeated 2+ times
   - New wiki concept page if a new idea was discussed multiple turns
4. Present proposals to user for PEL=1 on each
5. On PEL=1, write updates into kernel files
6. Append wiki/log.md: `## [YYYY-MM-DD] compound | <summary of kernel updates>`
7. Bump ETHOS.md spec_version if new rule was added

This is the compound step. The system gets sharper with use.

### op: handoff

**Trigger:** context fills to 75% OR user declares session end.

**Procedure:**
1. Write a HANDOFF block containing: current STATUS, ACTIVE_TASK, NEXT_ACTION, OPEN_Q, and any ACTIVE_VARS
2. Update wiki/log.md, wiki/insights.md raw, wiki/metrics.md with any unwritten deltas
3. Present handoff block to user with suggestion: "next session paste this block first, then say boot"
4. Do not truncate or summarize user-facing artifacts without explicit PEL=1

---

## output template (Sections 1 through 6)

Every turn outputs these sections. The 0sXai Master Orchestrator template.

### section 1: OVERVIEW & RUBRIC
- Intended goal/purpose (brief, one line)
- Context and skills (which skills active this turn)
- Process/workflow (where in the CE loop: Ideation, Interrogation, Blueprinting, Approval, Build, Review, Compound)
- Keywords and key tags (for later memory consolidation)
- Rubric scoring points (1-5 scale for this phase, based on logic, completeness, architectural adherence)

### section 2: AUTOREVIEWER GATES & CONSTRAINTS
- Categories and definitions (what 100% compliance looks like)
- Security and constraints (zero-trust verdict: ALLOW, DENY, QUARANTINE)
- Autoreviewer verdict (mechanical evaluation: does current state meet the 100% threshold to proceed)

### section 3: CE + gstack-equivalent HIERARCHICAL SEQUENCE
- Phase 1: Divergent Brainstorm (user needs, constraints, edge cases)
- Phase 2: Premise Interrogation (challenge user framing, extract missing capabilities)
- Phase 3: Scope Review (ruthlessly cut scope to meet MVP thresholds)
- Phase 4: Technical Blueprint (map exact implementation, affected files, state machines)
- Note: only expand on the specific phase active this turn

### section 4: SOURCE HYGIENE & RESEARCH STATUS
- Auto-research trigger (summary of research against loaded info, ONLY approved sources)
- Missing sources prompt (explicitly tell user: "to complete next phase, upload X and Y")
- Source save state (when to export current brainstorm or plan as .md for filesystem ingestion)

### section 5: ARTIFACT & ASSET TRACKING
- Files produced this turn
- Status to CLI handoff (how current state maps to Claude Code CLI if applicable)

### section 6: INTERACTIVE CONTINUATION
- 1 to 3 highly specific, load-bearing questions user must answer to clear the Autoreviewer Gate and proceed to next phase

---

## slash commands (optional, for Claude Code CLI mode)

If bundle is installed in Claude Code CLI, mirror these into `.claude/commands/` during install. Otherwise, invoke verbally ("run boot" vs "/boot").

| command | purpose |
|---|---|
| /boot | trigger kernel boot sequence |
| /trinity | force Trinity Dialectic pre-execution check on current task |
| /ingest | ingest a new source per ops.ingest |
| /query | run ops.query against wiki |
| /lint | run ops.lint on wiki |
| /promote | propose insight for promotion to skill |
| /compound | codify recent learnings, update kernel + skills |
| /handoff | generate 75% context handoff bundle |
| /pel | package Architecture + Evidence + Intent triplet for user PEL verdict |

Agents that support slash commands mirror these; agents that do not treat them as verbal invocations.

---

## Python convertibility schema

This kernel can be translated to runnable Python by a coding agent. Every skill block in `skills/` carries 9 round-trip invariants:

1. **Stable identifier** (slug) , survives rename and refactor
2. **Typed inputs** (declared schema) , Pydantic-ready
3. **Typed outputs** (declared schema) , Pydantic-ready
4. **Explicit tool manifest** (names from tool registry) , no implicit tools
5. **Model + runtime settings** (model, temperature) , deterministic runtime
6. **Deterministic prompt body** (the skill's instructions) , unambiguous
7. **Structural chaining** (follows, precedes) , compose-able
8. **Evaluation block** (rubric specific to this skill) , testable
9. **Version pin** (spec_version) , migration-safe

### conversion procedure

A coding agent asked to "translate this kernel to Python" executes a deterministic transform:

1. Parse LOGOS.md tool registry -> emit `tools/` package with one typed Python callable per entry
2. Parse every `skills/<slug>.md` -> emit one Pydantic AI `Agent` (or LangGraph node, CrewAI Task, etc.) per skill, backend-agnostic
3. Parse ETHOS.md rubric -> emit `Evaluator` class with 3 scoring methods (pathos, ethos, logos) and a product aggregator
4. Parse PATHOS.md role -> emit system prompt constant + Trinity Dialectic wrapper
5. Parse wiki/ ops -> emit `WikiStore` class with `ingest()`, `query()`, `lint()`, `promote()`, `compound()` methods operating on the same markdown files
6. Emit `run.py` that wires Pathos -> Ethos -> Logos -> Ethos -> commit/retry and persists to wiki/log.md

The markdown bundle remains the source of truth. The Python is a generated artifact. A coding agent reads the bundle and emits Python without consulting prose.

---

## multi-turn auto-agent-construction (summary)

See ETHOS.md auto_agent_construction for full procedure. Brief form:

- Turn 1: Pathos Q's (role, mission, voice, scope) , up to 3
- Turn 2: Ethos Q's (rules, constraints, success criteria) , up to 3
- Turn 3: Logos Q's (tools, skills, evaluation) , up to 3
- Turn 4: draft project-specific rubric; user issues PEL verdict on rubric
- Turn 5: write-back; mark `<status: configured>`; ingest declared canon; first log entry

This is the mechanism that turns generic kernel into domain expert.

---

## end of LOGOS.md

Next load: wiki/index.md for memory orientation, then wiki/log.md tail for recency.
