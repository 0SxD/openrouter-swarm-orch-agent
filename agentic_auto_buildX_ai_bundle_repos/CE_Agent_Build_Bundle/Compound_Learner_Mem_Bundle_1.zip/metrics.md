# wiki/metrics.md

> Silent telemetry. Zero canon weight. Append-only per-turn rows.
> Purpose: trend output tokens per task, track model-tier ratio, verify anti-bloat holds.

---

## legend

- **turn_ts:** ISO timestamp (UTC)
- **task_id:** identifier for the task this turn belongs to
- **turn_num:** 1-indexed within task (0 reserved for boot/archive-check scans)
- **model:** opus | sonnet | haiku
- **in_tokens:** `chars(input) / 4`
- **out_tokens:** `chars(output) / 4`
- **ratio:** `out / in`
- **outcome:** TRUE1 (ship) | FALSE0 (blocked) | PENDING | PEL_1 | PEL_0 | PEL_ASK | ITER-N | scan_clean | scan_flagged_N
- **tier_rec:** opus_gate | sonnet_exec
- **notes:** key signals, hard-fails, promotions

---

## targets

- **ratio trend:** rolling avg last 3 completed tasks' out/in ratio should trend down while approval stable-or-rising. Trend down = compound engineering working. Flat or rising = audit non-reducing skill or wiki bloat.
- **sonnet:opus:** target above 3:1 by task 25. May be 1:1 in early phase of new project. Opus for structural/novel/hard-fail-recovery, sonnet for pattern-match/routine/surgical.

---

## audit rules

### every 5 turns
Audit prior 5 rows:
- Were opus_gate turns truly structural? (novel pattern, hard-fail recovery, dispatch bundle, vision architecture)
- Were sonnet_exec turns truly routine? (pattern-match, established skill, surgical fix)
- Mismatch = correction insight appended to wiki/insights.md raw

### every compound op
Check if ratio trend over last 10 turns is trending down. If not, investigate which skill or wiki page is non-reducing.

---

## rows

| turn_ts | task_id | turn_num | model | in_tokens | out_tokens | ratio | outcome | tier_rec | notes |
|---|---|---|---|---|---|---|---|---|---|
| seed | bootstrap | 0 | N/A | 0 | 0 | 0 | N/A | N/A | kernel installed, no turns yet |

<!-- append one row per turn below -->

---

## end of wiki/metrics.md
