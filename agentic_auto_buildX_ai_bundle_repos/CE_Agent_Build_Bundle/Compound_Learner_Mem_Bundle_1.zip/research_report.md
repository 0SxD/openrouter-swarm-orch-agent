# research_report.md

> **Note:** This document is the research report that drove the design of the PEL Kernel.
> It was commissioned for a specific instance named "HumanX OS v2." The generic kernel you are holding is derived from this research.
> Read this as historical reference, not as operating instruction. The kernel lives in PATHOS.md, ETHOS.md, LOGOS.md. This file explains why those files are shaped the way they are.
>
> **Rename guidance:** When adopting the kernel for your own project, replace "HumanX" mentions in this file with your project name if you want, but it is not required. The design rationale generalizes.

---

# HumanX OS v2: A PEL-native compound engineering kernel

A unified redesign of HumanX_OS_v1 that collapses ten files into a **five-file kernel plus two living directories**, preserves the Trinity Dialectic and caveman voice as sacred, adds a formal anti-bloat mechanism missing from every public peer, and is simultaneously paste-into-Claude-Project ready, clone-into-Claude-Code-CLI ready, and convertible-to-Python ready. This report delivers the landscape scan, the file-count rationale, the complete file-level design spec, the Pathos-Ethos-Logos mapping, the anti-bloat machinery, the GitHub packaging plan, the Python convertibility schema, a honest uniqueness assessment, and a step-by-step migration path from v1.

The short version: **the three currently-separate HumanX subsystems (wiki + compound learning + PEL gate) are not actually separate, they are the content layer, the feedback layer, and the evaluation layer of a single Pathos-Ethos-Logos loop.** Recognizing that collapses the bundle and makes it self-functioning.

---

## Landscape: what already exists and what to borrow

The Claude-native framework landscape in April 2026 clusters into four tribes. HumanX sits at their intersection, and no public peer occupies its exact niche.

**The wiki/memory tribe.** Andrej Karpathy's April 2026 WikiLLM gist is the primary source: a three-layer markdown knowledge base (`raw/` + `wiki/` + schema) with `index.md` as the content catalog and `log.md` as an append-only chronological ledger using greppable date prefixes. Community implementations, nashsu/llm_wiki (2,600+ stars, Tauri desktop), wac81/LLM_wiki (Python reference), NiharShrotri/llm-wiki (adds contradiction-detection lint), and rohitg00/agentmemory (extends with confidence scoring, lifecycle, Ebbinghaus decay, MCP server), all share the three-layer structure but none ship an integrated skill system or ethics gate. MemGPT/Letta contributes the tiered virtual-memory pattern (core/recall/archival) but is database-backed, not markdown-native. Anthropic's own client-side Memory Tool makes the wiki-as-memory substrate trivial; the app executes file ops the agent emits.

**The skill/subagent tribe.** Anthropic's official Skills format (123k stars on anthropics/skills) defines the canonical primitive: a folder containing `SKILL.md` with YAML frontmatter (name, description) and progressive disclosure across three levels (frontmatter always loaded, body loaded when relevant, bundled files loaded on demand). Claude Code subagents (`.claude/agents/*.md`) add per-agent tool scoping and fresh-context spawning. obra/superpowers is the most mature community instance; SessionStart hooks auto-load skills, `/brainstorm`, `/write-plan`, `/execute-plan` commands enforce TDD discipline. VoltAgent/awesome-claude-code-subagents curates 100+ agents.

**The compound-engineering tribe.** EveryInc/compound-engineering-plugin (14.9k stars, MIT, published to Anthropic's plugin marketplace) is the direct progenitor of the user's pipeline. Its loop, brainstorm to plan to work to review to compound to repeat, and its "compound" step (codify learnings into project instructions, new agents, hooks, slash commands, tests) is the philosophical parent of the compound-learning tier. Garry Tan's gstack (80k stars, MIT) is where the `/office-hours`, `/plan-ceo-review`, `/plan-eng-review` commands live; 23 opinionated Claude Code skills for a full product org, installed via a single-branch shallow clone plus setup script. BMAD-METHOD demonstrates dual-mode compilation: agent and workflow YAML source files compile to fifteen different IDE-specific artifacts (Claude Code, Cursor, Codex, Gemini, Cline, Windsurf). SuperClaude and claude-flow/ruflo (33k stars) are the cautionary tales; roughly 50MB of files and 60+ agents respectively, often cited as "instruction bleed" anti-patterns.

**The ethics-gate tribe.** Constitutional AI (Anthropic, arXiv:2212.08073) is the canonical generate-critique-revise loop; it is the closest prior art to the Trinity Dialectic. shaunbuswell/cognitive-type-system is the only direct GitHub precedent for using ETHOS/PATHOS/LOGOS as a behavioral type system for LLMs (though it inverts some mappings). Runtime gate primitives exist everywhere, LangGraph `interrupt()`, Cloudflare Agents `waitForApproval()`, OpenAI Agents SDK `needsApproval`, BMAD's Implementation Readiness gate, but **none fuse a rhetorical-triangle philosophy with a compound-learning ledger.**

**What to borrow, concretely.** From Karpathy: the three-layer `raw/` + `wiki/` + schema with `log.md` prefix convention. From Anthropic Skills: progressive disclosure with YAML frontmatter as the routing layer. From superpowers: the SessionStart hook that auto-loads relevant context. From EveryInc: the **Compound step** as an explicit ritual that updates the system itself, not just outputs. From BMAD: a single source-of-truth that compiles to multiple targets. From the DEV.to `learnings.md` pattern: a **hard line cap** on the curated file and weekly promotion from raw observations. From FadeMem: **hysteresis thresholds** (θ_promote ≠ θ_demote) to prevent tier-flapping. From Claude Code's session-memory markdown: a **forked-subagent zero-model-cost compaction** at threshold. From promptfoo: **regression eval** as a first-class bundle artifact. License and distribution conventions: MIT, flat repo, Claude plugin marketplace.

---

## Why five files is the right number

Three files (pure PEL) is mentally elegant but fails in practice; the agent needs a single entry point to read first, and GitHub needs a README to be discoverable. Seven-plus files enters SuperClaude or BMAD territory, where the MAST empirical study (arXiv:2503.13657, 1,600+ traces across seven frameworks) attributes **41.8% of multi-agent failures to Specification and System Design issues**; ambiguous roles, duplicate agents, poor decomposition. Every file past the minimum is a tax against that 41.8%.

**The recommended kernel is five files:**

1. **README.md**; GitHub-facing; hero, 60-second quickstart, skill table, uninstall, license.
2. **CLAUDE.md**; the boot sector. This is also the text you paste into Claude Project custom instructions (kept under 1,500 chars of load-bearing content, per the observed Project-instructions soft ceiling). It tells the agent how to load the three PEL files and which mode it's in.
3. **PATHOS.md**; role, mission, caveman voice, Trinity Dialectic framing. The "why and for whom."
4. **ETHOS.md**; rules, gates, evaluation rubric, promotion thresholds, archival policy, version pins. The "rules."
5. **LOGOS.md**; tool registry, skill registry, slash commands, wiki ops, Python convertibility schema. The "how."

And **two living directories** (content, not kernel):

- **wiki/**; Karpathy's three-layer memory: `raw/`, wiki pages, `index.md`, `log.md`, `insights.md` (promotion ledger), `metrics.md` (sonnet:opus ratio and other telemetry).
- **.claude/commands/**; optional slash-command files for Claude Code CLI mode. Absent in Project-paste mode; present and active in CLI mode.

This gives ten filesystem entries total in a clean install, the same number as v1 but organized by **role, not by concern.** Every file in the kernel answers one question (what's the role, what are the rules, what are the tools); every file in the content layer is auto-managed by the kernel.

The 41.8%-specification-failure tax is paid once, on the five kernel files, and never grows. New skills, new insights, new logs all land in the content directories, which have explicit size governors (see anti-bloat section).

---

## The Pathos-Ethos-Logos architecture, mapped

The rhetorical triangle collapses onto the **Planner-Executor-Reviewer** triad and Constitutional AI's **generate-critique-revise** loop more cleanly than onto any four-part alternative.

| PEL | Definition | Operational analog | Constitutional AI step | Kernel file |
|---|---|---|---|---|
| **Pathos** | Role, mission, voice, for-whom | Planner (goal interpretation) | Generate (principles-informed) | PATHOS.md |
| **Ethos** | Rules, gates, evaluation, thresholds | Reviewer | Critique (against constitution) | ETHOS.md |
| **Logos** | Tools, skills, execution, wiki ops | Executor | Revise (apply tools to produce) | LOGOS.md |

The **Trinity Dialectic** is then formally: Pathos proposes intent, Ethos evaluates intent against rules, Logos executes the approved intent, Ethos evaluates output against rubric, on pass commit, on fail feed the failure into the promotion ledger and either retry or hand-off to human. This is Constitutional AI's critique-revise with a pre-action intent stage and a durable learning tail; genuinely novel as a synthesis, even if every component has prior art.

**100% success evaluation** is defined as: Pathos compliance (role fidelity) + Ethos compliance (all gate criteria pass or human-override logged) + Logos compliance (output matches declared schema and all tools returned success). Each dimension is a 0-to-1 score; success is the product, not the sum, **any one dimension at zero fails the whole**. This is the only way a three-way evaluation preserves the dialectic.

---

## File-level design specification

### README.md
Target: 200-400 lines. Sections in order: one-line hook, who this is for (three personas), 60-second quickstart (paste-into-Claude block OR git clone and install), mode selector (Claude Project paste-and-go vs Claude Code CLI), the skill table (one row per slash command with one-line purpose), philosophy (five bullets max, no name-drops), uninstall (exact commands, builds trust per gstack's exemplary pattern), troubleshooting (top five issues), license (MIT, one line). Badges capped at four: build, license, version, community.

### CLAUDE.md (boot sector / dispatcher)
The same text that pastes into Claude Project custom instructions. Under 1,500 chars of load-bearing content. Contents: version pin, mode declaration logic (if `.claude/` exists then CLI mode, else Project mode), load order (read PATHOS first, ETHOS, LOGOS, wiki/index.md), invocation of the Trinity Dialectic ritual on every significant turn, pointer to wiki/log.md as the durable record. Explicit compact-instructions section telling the agent which content to preserve across compactions. Declared model fallback (tested on Sonnet 4.x; fallback to Sonnet 3.7).

### PATHOS.md; the Why
Role declaration. The caveman voice as the stylistic constraint. Mission: advance the project's work by accumulating durable insight across sessions. Who it's for: the user (primary) and anyone who forks (generic). The Trinity Dialectic as ritual: every non-trivial turn declares its Pathos (intent), submits to Ethos (gate), and only then engages Logos (execution). Domain slot: a single `## Scope` heading where the generic bundle declares example scope and forkers override. This is the **only file a forker needs to customize**; Ethos and Logos are generic.

### ETHOS.md; the Rules
The pre_submit_gate with derivation-cited rules. Evaluation rubric: the three PEL dimensions each scored 0-to-1, success = product. Promotion thresholds for the insight ledger: **2 confirms OR 1 hard-fail to promote to sub-skill** (genuinely novel threshold, with precedent for the family but not the specific rule). Archival policy: hard caps, hysteresis, decay rates, log-rotation triggers. Version pins: which Claude model, which bundle version, what to do on mismatch. Hard-fail evolution rule: any hard-fail appends a new derivation-cited rule to this file, so the gate evolves deterministically. Termination conditions for every skill (pre-registered, MAST's top failure category).

### LOGOS.md; the How
**Tool registry:** each tool is a named entry resolvable by the Python loader. **Skill registry:** each skill is a pointered entry. **Slash commands:** the compound-engineering pipeline formalized, each as a skill block in LOGOS.md and, in CLI mode, mirrored to `.claude/commands/*.md`. **Wiki ops:** the canonical operations (ingest, query, lint, promote, compound, handoff) with prose specs that map to Python functions. **Compaction policy:** when session context exceeds threshold, a forked subagent writes structured markdown notes to a session-memory file (the zero-model-cost pattern).

### wiki/; the Memory
Raw sources in `wiki/raw/` (immutable; agent reads, never edits). Agent-owned pages in `wiki/` root (entity pages, concept pages, summaries, comparisons). `wiki/index.md` as the content catalog (one line per page with summary + metadata, organized by category). `wiki/log.md` as the append-only chronological ledger using greppable date prefixes. `wiki/insights.md` as the promotion ledger; raw observations on top, promoted insights below, with a hard 100-line cap on promoted insights. `wiki/metrics.md` tracking sonnet:opus ratio, turn counts, and gate-pass-rates.

### .claude/commands/; the CLI Surface
Only materialized in CLI mode. Each file is a lightweight stub pointing at the corresponding skill block in LOGOS.md, with the YAML frontmatter duplicated for Claude Code's native loader. Generated by `install.sh` from LOGOS.md so the two never drift.

---

## Anti-bloat mechanism: the Archival Kernel

Every public peer's acknowledged failure mode is file bloat. This kernel bakes archival into ETHOS.md as a first-class concern with concrete, parameterized rules:

**Hard line caps.** `wiki/insights.md` promoted section: 100 lines. `wiki/log.md`: unlimited append, but rotated at 1,000 entries into `wiki/log.archive/YYYY-QQ.md`. Every skill block in `LOGOS.md`: under 80 lines (SKILL.md best-practice limit halved, given LOGOS aggregates many skills). Overflow triggers splitting into a `references/` file; the Anthropic Skills progressive-disclosure pattern.

**Hysteresis thresholds.** Promotion threshold (observation to insight): 2 confirms or 1 hard-fail. Demotion threshold (insight to archive): no referenced use in 30 session-active days AND confidence below 0.3. Separate thresholds prevent the tier-flapping that plagues single-threshold systems.

**Session-aware decay.** Clock ticks only during active use, not wall-clock; a bundle that sits idle doesn't lose knowledge; one that's actively used naturally ages stale claims.

**Contradiction at write, not read.** On every wiki write, a brief labeler pass marks the delta `reinforce | weaken | qualify | contradict | create` and appends the verdict to `wiki/log.md`. Contradictions surface immediately, not at query time.

**Sparse wiki pointers.** A curated wiki page is created only when the Compound step explicitly justifies it. Most raw sources live in `raw/` and are referenced; only earned knowledge gets a page. Sparsity is signal.

**Background lint.** A `lint` slash command runs on demand or via hook and reports orphans, stale claims, broken wikilinks, and contradictions. User decides whether to act, but the system surfaces automatically.

**Version-driven migration.** ETHOS.md declares the spec version; install.sh and the Python loader refuse to operate on a mismatch and direct the user to a migration note.

---

## Self-functioning mechanism: how it boots and doesn't break

**Boot sequence** (identical across both modes). The agent reads CLAUDE.md first, declares mode, loads PATHOS, ETHOS, LOGOS in order, reads wiki/index.md for memory orientation, reads last 5 entries of wiki/log.md for recency, reads wiki/insights.md promoted section for durable learnings. Total boot cost: well under 10k tokens, matching the rule that MCP and context overhead above 20k tokens cripples the agent.

**Robustness to model version changes.** ETHOS.md pins a tested model and declares a fallback. The kernel ships with a minimal regression suite that can be run when upgrading models. Any regression appends a hard-fail entry to wiki/log.md and, per the promotion rule, updates ETHOS.md's gate rules; **the system learns from its own version-bump failures.**

**Sycophancy prevention.** Ethos is a structurally separate evaluation step that runs on Logos's outputs. Single-agent sycophancy is structurally blocked because the Reviewer role reads the same Ethos rules as the Generator. In CLI mode, the Reviewer is optionally a separately-spawned subagent with fresh context.

**Termination conditions.** Every skill in LOGOS.md declares explicit termination (goal met, max iterations, hard-fail). Unterminated agent runs are a top failure cluster; the kernel refuses to ship a skill without them.

**Compaction-safe.** The Compact Instructions section in CLAUDE.md declares what to preserve across context compactions. The forked-subagent session-memory pattern means compactions are zero-model-cost when `wiki/session-memory.md` is current.

---

## Generic vs domain layering

**Only PATHOS.md is domain-specific.** ETHOS.md and LOGOS.md are fully generic in the released bundle and become domain-aware only through references to PATHOS.md's declared scope. A forker clones the repo, edits PATHOS.md's `## Scope` and `## Voice` sections, and has a working OS for their own domain without touching evaluation or execution logic.

The compound-engineering-specific slash commands live in LOGOS.md as **optional skill blocks under a `## Compound Engineering Pipeline` heading**. Forkers can delete the heading and replace it with their own workflow; the kernel still boots. This matches gstack's pattern where skills are independently removable.

The caveman voice is declared in PATHOS.md as the "kernel default voice" but is structurally a voice slot, not a kernel requirement. A forker overriding it still gets the Trinity Dialectic and the compound loop.

---

## GitHub packaging plan

**Repository:** flat, not monorepo. Top-level layout as shown in README.md file tree.

**License:** MIT. Every successful Claude-native framework is MIT. The U.S. Copyright Office (Part 2 report) ruled prompts themselves are not copyrightable; the selection and arrangement in markdown is a literary work that MIT covers cleanly. CC-BY-4.0 is an enterprise-adoption trap (not OSI-approved); Apache-2.0 adds patent-header overhead with no benefit here; BSL is poison for grassroots agent tooling.

**Distribution:** primary channel is Anthropic plugin marketplace. Secondary is `git clone --single-branch --depth 1 && ./install.sh` (more auditable than `curl | bash`). No npm or pip initially; ship one channel well before two poorly.

**Community:** GitHub Discussions over Discord. Discussions is searchable and Google-indexed; Discord creates invisible institutional knowledge. Opt-in telemetry only.

**Quickstart sequence** (user experience):
1. Visit repo, read README hero, decide this is for them (5 seconds)
2. If Claude Project user: copy CLAUDE.md block, paste into Project instructions, upload the rest to Project knowledge, done (60 seconds)
3. If Claude Code CLI user: git clone, cd, ./install.sh. install.sh writes .claude/commands/ from LOGOS.md, initializes wiki/ with seed files, validates required tools exist (90 seconds)
4. First run: user types `/office-hours` or asks the agent a question; the agent boots the kernel; Trinity Dialectic runs; first entry appended to wiki/log.md; user sees the system working.

---

## Python-script convertibility

The nine round-trip invariants, stable identifier, typed inputs and outputs, explicit tool manifest, model and runtime settings, deterministic prompt body, structural chaining, evaluation block, typed dependencies, version pin, are all present in the recommended skill-block format inside LOGOS.md.

**Conversion contract:** a coding agent asked to "translate this kernel to Python" executes a deterministic roughly-200-line transform:

1. Parse LOGOS.md skill blocks, emit one Pydantic AI Agent per skill (alternative backends: LangGraph node, CrewAI Task; backend-agnostic pattern)
2. Parse ETHOS.md evaluation rubric, emit Evaluator class with three 0-to-1 score methods and a product aggregator
3. Parse PATHOS.md role declaration, emit system prompt constant and Trinity Dialectic wrapper
4. Parse LOGOS.md tool registry, emit `tools/` package with one typed Python callable per entry
5. Parse wiki/ operations, emit WikiStore class with ingest, query, lint methods operating on the same markdown files
6. Emit `run.py` that wires Pathos to Ethos to Logos to Ethos to commit/retry and persists to wiki/log.md

The markdown bundle remains the source of truth; the Python is a generated artifact.

---

## Uniqueness assessment

**What's genuinely novel.**

The **three-way unification** of a persistent markdown wiki, a promotion-ledger-driven skill system, and a rhetorical-triangle evaluation gate, in a single five-file kernel, has no public peer. rohitg00/agentmemory is closest on the wiki-plus-confidence side. obra/superpowers is closest on the skill-plus-auto-load side. EveryInc/compound-engineering is closest on the learning-loop side. shaunbuswell/cognitive-type-system is closest on the PEL-as-types side. None combine all four.

The **"2 confirms or 1 hard-fail" promotion heuristic** is novel as a discrete rule, though it falls within the known family of threshold-plus-contradiction promotion patterns.

The **Trinity Dialectic as an explicit pre-action intent gate** on top of Constitutional AI's critique-revise is a novel synthesis. CAI evaluates post-generation; this kernel evaluates intent first (Pathos declared), then execution (Logos applied), then output (Ethos scored).

The **hard-fail evolution of the gate itself** (every hard-fail appends a derivation-cited rule to ETHOS.md) is novel as a structural feature. Self-evolving prompts exist (DSPy, TextGrad); self-evolving ethics gates don't, in any public Claude-native bundle.

**What's not novel.** The three-layer wiki (Karpathy). Progressive disclosure (Anthropic Skills). Slash-command workflows (gstack, CE). Tiered memory (MemGPT). Constitutional critique (Anthropic CAI). HITL gates (everywhere). MIT-plus-plugin-marketplace distribution (every peer).

Honest verdict: **the component tech is well-precedented; the synthesis is distinctive; the hard-fail gate evolution is the most defensible uniqueness claim.**

---

## Recommended add-ons (only genuinely additive)

Three items are genuinely additive and can be optionally enabled:

- **A regression eval runner** (e.g., promptfoo) shipped as a config file; invoked manually on model upgrades. Zero runtime cost.
- **The Anthropic Memory Tool primitive** used as the mechanism for the agent to write to wiki/ in certain modes. Not a separate install; already available.
- **An optional skills-registry MCP pointer** for forkers publishing domain-specific skills to the broader ecosystem. Opt-in.

Skip: vector-DB MCP servers (breaks markdown-native purity), infrastructure-heavy memory layers (overhead), tool-overlap MCPs (directly triggers the 20k-token rule).

---

## Migration path from v1 to v2

A one-pass migration any user can run:

1. **Snapshot v1.** Make a backup of the existing bundle folder.
2. **Translate content into the new kernel.** Copy v1's install/bootstrap content into CLAUDE.md (trimmed to under 1,500 chars of load-bearing content; verbose detail moved into README). Copy v1's protocol blueprint content, the pre_submit_gate rules, and the Trinity Dialectic declaration into ETHOS.md. Copy the role, mission, and caveman tone into PATHOS.md. Copy v1's spec (HOT_CACHE, GRAPH_LINKS, COMPACTION_LEDGER), skills tree-index, and any slash-command definitions into LOGOS.md as skill blocks with the nine invariants. Leave README as the bundle map and GitHub hero.
3. **Migrate the wiki.** If v1 already has a wiki or equivalent, keep it. Normalize log.md entries to the date-prefix format. Move the insights ledger to wiki/insights.md and cap the promoted section at 100 lines (archive overflow with date stamps). Move the metrics ledger to wiki/metrics.md.
4. **Archive legacy files.** Any v1 file not absorbed above moves to `_archive/v1/` with a MIGRATION.md noting what each file became.
5. **Version-pin.** Declare spec version in ETHOS.md; CLAUDE.md references the pin; install.sh refuses on mismatch.
6. **Run the regression suite** against the pinned model. Any failure appends a derivation-cited rule to ETHOS.md, the system's first legitimate self-evolution event.
7. **Generate `.claude/commands/`** via install.sh.
8. **Commit, tag, publish.** Tag v2.0.0, submit to plugin marketplace, update README install block.

---

## Conclusion: what actually changed

The v1 to v2 move is not a file-count reduction; it is a **reframing from file-as-concern to file-as-role**. The wiki, the compound-learning ledger, and the PEL gate were never three systems; they are the content, feedback, and evaluation of a single Trinity Dialectic loop. Naming them as such collapses the kernel, makes the PEL mapping structural rather than decorative, and lets the archival machinery live in one place (ETHOS.md) rather than scattered across three subsystems.

The design borrows aggressively from Karpathy's WikiLLM, Anthropic Skills, EveryInc Compound Engineering, gstack, BMAD, and Constitutional AI, but unifies them in a way none of those peers do. Its defensible uniqueness is the **hard-fail gate evolution**: a bundle that rewrites its own ethics rules in response to real failures, logs the derivation, and ships the evolved rule to every future session. That is the compound in compound engineering, applied to the system itself.

One sacred preservation worth naming: **the caveman voice stays.** It is a declared PATHOS slot, not a kernel assumption; but in the released bundle, it is the voice. Short sentences. No hedging. Say the true thing.

---

## end of research_report.md
