# PEL Kernel

Drop-in compound engineering operating system for AI agents.
One kernel, three pillars (Pathos + Ethos + Logos), persistent wiki memory, self-evolving gate.

---

## What this is

A generic skeleton that turns any Claude chat or Claude Code session into a domain-expert agent. The agent runs multi-turn Trinity Dialectic interrogation BEFORE executing any task, so every output either hits 100% success on a pre-declared rubric OR flags specific blockers the user must resolve first.

Works for any project where "figure out the right thing to build" matters more than "type fast." Examples: research synthesis, grant writing, product planning, technical specs, policy drafting, complex multi-step reasoning.

---

## Who this is for

- Solo builders who want agent continuity across sessions
- Teams piloting compound engineering with Claude
- Researchers building domain-expert agents without training one from scratch
- Anyone tired of starting every chat from zero

---

## 60-second quickstart

### Option A: Claude Project (web or mobile)

1. Create a new Project in claude.ai
2. Open Project settings, "Custom instructions" field
3. Copy the contents of `CLAUDE.md` into it, save
4. Upload `PATHOS.md`, `ETHOS.md`, `LOGOS.md`, and the `wiki/` folder to Project files
5. Start a new chat, say `boot`
6. Agent loads kernel and runs auto-agent-construction (multi-turn Trinity Dialectic Q's)

### Option B: Claude Code CLI

1. `git clone [your-fork]` or copy the bundle into your project folder
2. `CLAUDE.md` auto-loads when Claude Code opens the folder
3. First invocation: type `boot`
4. Agent reads kernel, runs auto-agent-construction

---

## What happens on first run

The kernel ships unconfigured. The agent runs auto-agent-construction by asking you multi-turn questions bucketed into the Trinity Dialectic:

- **Pathos questions:** role, mission, voice, domain scope
- **Ethos questions:** rules, constraints, success rubric, approved sources
- **Logos questions:** tools, skills, evaluation steps, termination conditions

Your answers get written into `PATHOS.md`, `ETHOS.md`, `LOGOS.md`. The generic kernel becomes a domain expert for YOUR project. See `ETHOS.md` section `auto_agent_construction` for the exact procedure.

---

## The five kernel files

| File | Role | One-liner |
|---|---|---|
| README.md | Human entry | The front door |
| CLAUDE.md | Agent boot sector | The switch, also the Claude Project paste-text |
| PATHOS.md | Role, mission, voice | The why |
| ETHOS.md | Rules, gates, rubric | The rules |
| LOGOS.md | Tools, skills tree | The how |

Plus `wiki/` for persistent memory (catalog, log, insights ledger, metrics, references).

---

## File tree

```
pel-kernel/
├── README.md                    # You are here
├── CLAUDE.md                    # Boot sector + Claude Project paste-text
├── PATHOS.md                    # Role + mission + voice (WHY)
├── ETHOS.md                     # Rules + gates + rubric (RULES)
├── LOGOS.md                     # Tools + skills tree (HOW)
└── wiki/
    ├── index.md                 # Content catalog
    ├── log.md                   # Append-only chronological log
    ├── insights.md              # Promotion ledger (raw + promoted)
    ├── metrics.md               # Telemetry (sonnet:opus ratio, turn counts)
    └── reference/
        └── research_report.md   # Landscape scan + design rationale (reference)
```

### Directories created on demand

- `skills/` gets created when the first insight promotes (see `ETHOS.md` promotion thresholds)
- `specs/` gets created when the first task-specific spec emerges
- `.claude/commands/` gets created by install script in Claude Code CLI mode only
- `wiki/raw/` gets created on first source ingest
- `wiki/log.archive/` gets created on first log rotation (1000 entries)
- `wiki/insights.archive/` gets created on first demotion (30+ inactive days)

---

## How the tree grows

Kernel files stay small. As agent learns:

- New observations append to `wiki/insights.md` raw section
- On 2 confirms OR 1 hard-fail, observation promotes to a skill file under `skills/`
- `LOGOS.md` gets a pointer row, never the inline content
- Same pattern for task-specific specs in `specs/`
- Same pattern for domain-specific source summaries in `wiki/`

Result: kernel never bloats. Depth grows laterally, not vertically.

---

## Anti-bloat mechanism

Six explicit rules in `ETHOS.md`:

1. **Hard line caps:** `insights.md` promoted section 100 lines, `log.md` 1000 entries, `LOGOS.md` 500 lines, individual skills 80 lines
2. **Hysteresis thresholds:** θ_promote (2 confirms) ≠ θ_demote (30 inactive days + low confidence)
3. **Session-aware decay:** clock ticks on active use, not wall-clock
4. **Contradiction-at-write:** every wiki update scored reinforce/weaken/qualify/contradict/create
5. **Sparse wiki pages:** pages created only when compound step justifies one
6. **Version-pinned migration:** `ETHOS.md` declares spec version; install refuses on mismatch

Log rotation, insight archival, skill demotion all happen automatically. See `ETHOS.md` archival policy table.

---

## 100% success gate

Every consequential output scored on three dimensions, each 0.0 to 1.0:

- **Pathos compliance:** output matches declared role and intent
- **Ethos compliance:** all pre_submit_gate rules return TRUE
- **Logos compliance:** tools returned success, schema matches declared output

Final score = Pathos × Ethos × Logos (product, not sum).
Ship threshold = 1.0.
Any dimension at 0 = whole turn fails.

This is the core contract: the agent ships at 100% or tells you exactly why it cannot.

---

## Self-evolving ethics gate

Every hard-fail (artifact that shipped defective OR was caught at gate) produces a new rule in `ETHOS.md`. Version bumps automatically. No speculative rules; only rules derived from real failures enter the gate.

The kernel rewrites its own rulebook in response to reality. Compound engineering applied to the system itself.

---

## Renaming and forking

"PEL Kernel" is the default name. You can rename on your end without touching the architecture. Only `PATHOS.md` is domain-specific (the `<REPLACE_THIS_BLOCK>` section). `ETHOS.md` and `LOGOS.md` are fully generic in the shipped bundle and become domain-aware through references to `PATHOS.md`.

A forker clones the bundle, runs auto-agent-construction, and has a working project expert for their domain without touching evaluation or execution logic.

---

## Drop-in compatibility with existing projects

Adding this bundle to a project that already has files does NOT degrade existing work. The kernel is a superset of typical ad-hoc scaffolds. Existing canon files (research docs, specs, prior outputs) become pre-existing sources in `wiki/raw/` on first ingest. Auto-agent-construction configures the kernel to respect what's already there.

If you drop this into a project mid-flight, the first run asks "what already exists? what should I read as canon?" before touching anything.

---

## Uninstall

`rm -rf` the folder. Nothing else. No daemons, no registries, no residual files.

---

## License

MIT. See LICENSE file (add one if forking).

---

## Acknowledgments and lineage

Built on patterns from:
- Persistent-wiki memory (Karpathy LLM-wiki gist pattern)
- Progressive-disclosure skills (Anthropic Skills format)
- Constitutional AI critique-revise loop
- Compound engineering learning loops (EveryInc pattern)
- Trinity Dialectic rhetorical triangle (Pathos-Ethos-Logos)

See `wiki/reference/research_report.md` for the full landscape scan, design rationale, and uniqueness assessment. That report references a specific instance ("HumanX OS v2") the research was commissioned for; the kernel you hold is the generic version derived from that research.

---

## Where to start

1. Read this README (done)
2. Read `PATHOS.md` to see the role stub
3. Read `CLAUDE.md` to see the boot sequence
4. Read `ETHOS.md` `auto_agent_construction` section to see what happens on first run
5. Paste CLAUDE.md into Claude Project, upload the rest, say `boot`

End of README.
