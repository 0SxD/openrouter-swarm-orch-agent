# wiki/log.md

> Append-only chronological log. Most recent at bottom.
> Format: `## [YYYY-MM-DD] <tag> | <one-line summary>`
> Tags: ingest, query, lint, bootstrap, promote, archive, insight, construct, fail, compound, handoff, pel
> Parseable: `grep "^## \[" wiki/log.md | tail -10`
> On 1000 entries, rotate to `wiki/log.archive/YYYY-QQ.md` (see ETHOS.md archival policy).

---

## [seed] bootstrap | kernel installed, auto_agent_construction pending

---

## [seed] reference | wiki/reference/research_report.md included as historical design source

## [seed] fail | em dash violations caught at ETHOS rule 3 pre-ship gate during bundle build, 14 hits auto-replaced with commas, zero shipped

## [seed] insight | gate rule 3 mechanical scan works as designed, caught author drift into em-dash usage in LOGOS and wiki/index, demonstrates self-evolving gate discipline

---

<!-- append new entries below this line, one per non-trivial turn -->
