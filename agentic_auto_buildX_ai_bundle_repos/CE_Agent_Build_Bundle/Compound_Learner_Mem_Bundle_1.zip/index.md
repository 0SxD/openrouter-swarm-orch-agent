# wiki/index.md

> Content catalog. Updated on every ingest. Read first on every query.
> Stubs listed here are index entries only. Full page bodies written on demand via ops.ingest.

## last_updated
seed

---

## entities
<!-- people, orgs, places the project tracks -->

| page | type | one-line | last_updated |
|---|---|---|---|
| [populate during first ingest] | entity | | |

---

## concepts
<!-- ideas, frameworks, methodologies -->

| page | type | one-line | last_updated |
|---|---|---|---|
| [populate during first ingest] | concept | | |

---

## sources
<!-- one page per ingested source document -->

| page | type | one-line | last_updated |
|---|---|---|---|
| [[reference/research_report]] | source | landscape scan and design rationale driving this bundle | seed |

---

## comparisons
<!-- structured contrasts -->

| page | type | one-line | last_updated |
|---|---|---|---|
| [populate during first ingest] | comparison | | |

---

## overview
<!-- top-level synthesis pages -->

| page | type | one-line | last_updated |
|---|---|---|---|
| [project_overview] | overview | populate during auto_agent_construction | seed |

---

## rules

- Page bodies written on demand via ops.ingest. Do not fabricate content without approved source.
- Every claim on a wiki page must cite a source page. No model-assumption content.
- Every page must have at least one outbound link and one inbound link after 3 ingest cycles (avoid orphans).
- User-provided content (braindumps, chat confirms) count as primary-source-from-user. Tag `source:user_oral` with date.
- Contradictions between user statement and external research create a flagged comparison page, not a silent overwrite.

---

## next pages to create (when first task begins)

1. `project_overview` , top-level synthesis page, populated during auto_agent_construction turn 5
2. [domain-specific pages] , populated by first few ingest cycles
3. [first skill concept page] , populated on first promotion

---

## end of wiki/index.md
