# wiki/insights.md

> Promotion ledger. Two sections: promoted (above the line), raw (below).
> Raw entries move to promoted when 2 confirms OR 1 hard-fail (see ETHOS.md promotion thresholds).
> Promoted section hard cap: 100 lines. Oldest below threshold archives to `wiki/insights.archive/YYYY-MM.md`.

---

## promoted (max 100 lines)

<!-- promoted insights live here. Each promoted insight links to its skill file. -->

| insight | confirm_count | first_seen | promoted_on | skill_file |
|---|---|---|---|---|
| [none yet] | | | | |

---

## raw (append as encountered)

<!-- raw observations from live sessions. Promote on 2 confirms or 1 hard-fail. -->

| insight | confirm_count | first_seen | status |
|---|---|---|---|
| [none yet] | | | |

---

## rules

- Every turn that surfaces a pattern appends one row to raw
- Confirmation comes from: (a) later turn that depends on the same pattern, OR (b) user explicit confirm
- Hard-fail = artifact that shipped defective OR was caught at gate and required rework that this insight would have prevented
- On promotion, run ops.promote (see LOGOS.md): draft skill file, add LOGOS pointer, move row to promoted, log
- On demotion, move from promoted to `wiki/insights.archive/YYYY-MM.md` (see ETHOS.md archival)

---

## end of wiki/insights.md
