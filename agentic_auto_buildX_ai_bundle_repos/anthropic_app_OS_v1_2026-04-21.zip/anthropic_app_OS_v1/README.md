# README.md
# Project: Anthropic Application -- Austin B. Green Resume
# OS: Compounding Learning OS, fork v1.0 for personal-representation workstream
# Generated: 2026-04-21
# Source dispatch: dispatch_v2 (Mercor Rubrics origin), MASTER_RESEARCH_HANDOFF.md (overnight session)
# Governance: 143_Protocol_a Blueprint (project_instructions canon)

## what this bundle is

A self-evolving operating system for Sage's (Austin B. Green) public and professional representation workstream. Forked from the dispatch_v2 compounding-learning OS, with the domain layer rewritten for personal-representation work and the Trinity Dialectic (Pathos/Ethos/Logos) approval gate from the 143_Protocol_a Blueprint preserved as the consequential-action checkpoint.

The bundle is designed to be re-uploaded to the Claude Project so that every future chat in this project boots from these files and self-evolves them.

## file map

```
README.md                              you are here
1_INSTALL.md                           paste-into-Project-settings protocol cutpaste, domain-adapted
spec.md                                running state, HOT_CACHE seeded with current STATUS
skills.md                              tree-index pointers to sub-skills
Wiki_Log.md                            chronological append-only history
metrics_ledger.md                      silent telemetry, opus:sonnet ratio + token trend

canon/                                 read-only reference material
  143_protocol_a_blueprint.md          textualized version of protocol_mandate.png
  MASTER_RESEARCH_HANDOFF_v2.md        ingested as the canonical general role + project ground truth
  austin_resume_corpus_index.md        date timeline + canonical truths from 8-resume corpus

skills/                                live sub-skill files, pointered from skills.md
  pre_submit_gate.md                   the highest-leverage artifact (seeded with 4 rules from canon)
  pathos_ethos_logos_approval_gate.md  Sage's mandatory Trinity Dialectic gate before public release
  trinity_dialectic_evaluator.md       Logos / Pathos / Ethos 3x3 matrix, 9 sub-evaluators
  resume_variant_writer.md             Sonnet-callable: produce 1-page ATS-safe resume variant
  date_conflict_reconciler.md          Sonnet-callable: reconcile cross-document date conflicts
  ip_scrub_pre_publish.md              Sonnet-callable: enforce Section 4 IP exclusions before any push
  socratic_question_generator.md       Sonnet-callable: generate 1-3 load-bearing questions

handoff_to_dispatch/                   files for the Dispatch agent
  DISPATCH_HANDOFF_2026-04-21.md       clean handoff describing what was built and what unblocks next
  OPEN_Q_BATCH_01.md                   load-bearing questions Sage must answer to unblock P0 work
```

## first move when re-uploaded to Claude Project

1. Open Project settings, paste 1_INSTALL.md code block into "Set project instructions", save.
2. Upload all files in this bundle into Project files so they land at `/mnt/project/`.
3. Start a new chat. First user move: `project_knowledge_search "spec.md HOT_CACHE"`.
4. State auto-loads. Pre-output eval runs. TRUE=1 acts, FALSE=0 asks up to 3 Qs.

## how this evolves

- Every turn must end TRUE=1 or FALSE=0. No ambiguous verdicts.
- Every consequential public-facing artifact must clear the Pathos-Ethos-Logos approval gate.
- Insights mined every turn, appended to spec.md INSIGHTS_LEDGER, promoted to skills/ on 2 confirms or 1 hard-fail.
- Pre-submit gate grows on every hard-fail: each version is the immune response to the prior version's blind spots.
- IP scrub is mandatory before any GitHub push, LinkedIn update, or Greenhouse submission.

## philosophy invariants (do not modify)

1. Environment, not memory, is ground truth (Section 2 of 143_Protocol_a).
2. Zero assumption: any doubt triggers STOP and Socratic Method (Axiom 1).
3. Stigmergic interaction: write artifacts, do not debate (Section 1).
4. Trinity Dialectic gates all consequential action (Section 5).
5. Caveman tone in chat, full content in .md files (TONE_SYNTAX from dispatch_v2).
6. No em dashes anywhere (user_preferences).

END_README
