# spec.md | CANONICAL HANDOFF & COM. STREAM
# Project: Anthropic Application -- Austin B. Green Resume
# Bootstrapped: 2026-04-21
# Protocol version: v1.0

<zero_bloat_protocol>
Assume each turn is terminal. Do not retain chat history.
Execute all state-saves directly to spec.md using strict structured fields.
Maintain 3-tier memory architecture:
  1. HOT_CACHE: max 500 words. Immediate next actions + active vars only.
  2. GRAPH_LINKS: minimalist pointers to external files / skills. No inline content.
  3. COMPACTION_LEDGER: record of hard-pruned context. Zero token leakage.
Main chat output: cave-man syntax only.
</zero_bloat_protocol>

---

## HOT_CACHE
<!-- max 500 words | next actions + active vars | overwrite each turn -->

STATUS: structural bootstrap complete (TRUE=1). Application content production blocked (FALSE=0) on three load-bearing OPEN_Q answers from Sage.

SESSION_TYPE: project bootstrap, OS adoption, MASTER_RESEARCH_HANDOFF ingestion as canon.

ACTIVE_TASK: handoff to Sage for OPEN_Q resolution and PEL approval to proceed to P0 application artifacts.

NEXT_ACTION (Sage): answer OPEN_Q batch 01 (3 load-bearing Qs in handoff_to_dispatch/OPEN_Q_BATCH_01.md). Then issue PEL=1 to unblock resume / essay / LinkedIn production.

NEXT_ACTION (next Claude turn after OPEN_Q answered): invoke resume_variant_writer.md with answered facts, produce two resume variants (Anthropic Prompt Engineer + Anthropic Applied Research), run pre_submit_gate v1.0, package Architecture + Evidence + Intent triplet for Sage's PEL verdict.

ACTIVE_VARS:
- target_role: Prompt Engineer, Claude Code at Anthropic (Greenhouse 5159669008)
- public_name: Sage
- canonical_email_for_application: austing143@gmail.com
- github_handle: 0SxD (commit email pending OPEN_Q-09 from MASTER_RESEARCH_HANDOFF)
- locations_acceptable: SF, NYC, Seattle (25% in-office, remote preferred)
- salary_range: 300k to 405k (SWE-G 5-6)
- timezone: US Pacific
- canon_loaded: 143_Protocol_a, MASTER_RESEARCH_HANDOFF_v2, austin_resume_corpus_index
- skills_seeded: 7 (pre_submit_gate, pathos_ethos_logos_approval_gate, trinity_dialectic_evaluator, resume_variant_writer, date_conflict_reconciler, ip_scrub_pre_publish, socratic_question_generator)

CONFIDENCE: TRUE=1 on bootstrap structure. FALSE=0 on application artifact production (gated by OPEN_Q + PEL).

---

## GRAPH_LINKS
<!-- pointers only, no inline content -->

- protocol_canon: project://1_INSTALL.md
- skill_tree: project://skills.md
- wiki_log: project://Wiki_Log.md
- metrics_ledger: project://metrics_ledger.md
- governance_canon: project://canon/143_protocol_a_blueprint.md
- general_role_canon: project://canon/MASTER_RESEARCH_HANDOFF_v2.md
- biographical_truth_canon: project://canon/austin_resume_corpus_index.md
- pre_submit_gate: project://skills/pre_submit_gate.md
- pel_gate: project://skills/pathos_ethos_logos_approval_gate.md
- trinity_evaluator: project://skills/trinity_dialectic_evaluator.md
- resume_writer: project://skills/resume_variant_writer.md
- date_reconciler: project://skills/date_conflict_reconciler.md
- ip_scrub: project://skills/ip_scrub_pre_publish.md
- question_gen: project://skills/socratic_question_generator.md

---

## COMPACTION_LEDGER
<!-- record of pruned content with replacement pointer -->

- 2026-04-21 INGESTED: dispatch_v2 README + 1_INSTALL + 2_PLAYBOOK + 3_SKILLS + 4_EXEMPLARS + 5_ADAPT + 6_TEMPLATES (7 files, 50 KB raw). REPLACEMENT_POINTER: 1_INSTALL.md (domain-adapted) + skills/ tree. Original archive remains read-only at /mnt/user-data/uploads/compounding_learning_OS_dispatch_2026-04-21.zip for reference; not loaded into runtime.
- 2026-04-21 INGESTED: MASTER_RESEARCH_HANDOFF.md (10.6 KB raw, ground-truth profile data). REPLACEMENT_POINTER: canon/MASTER_RESEARCH_HANDOFF_v2.md (canonized as general role + biographical canon, IP exclusions promoted to pre_submit_gate rule 1).
- 2026-04-21 INGESTED: 8 Austin/Sage resume versions (2011, 2014 docx, 2014 PDF, Fall 2019, Feb 2020, Dec 2025 v1, Dec 2025 v2, March 2026). REPLACEMENT_POINTER: canon/austin_resume_corpus_index.md (date timeline, conflict surface, canonical truth column).

---

## TASK_QUEUE

P0 (blocked on OPEN_Q + PEL):
- T01 produce Anthropic Prompt Engineer resume variant (1 page, ATS-safe, no em dashes)
- T02 produce Anthropic Applied Research resume variant (1 page, ATS-safe, no em dashes)
- T03 draft Why Anthropic essay (Sage writes first draft, Claude refines per Option C from Dispatch cutpaste)
- T04 LinkedIn About + Experience rewrite with date conflicts resolved
- T05 sage-prompt-engineering-portfolio README
- T06 Greenhouse 5159669008 submission package assembly

P1 (queued, post-application):
- T07 claude-obsidian README polish
- T08 archive-openbrain hostile audit (per HANDOFF_2026-04-18_SS14)
- T09 GitHub portfolio repo content layout (143_protocol_a/ + trinity_dialectic/)
- T10 first paper publication: Neuro-Symbolic Synthesis (nearest to academic publication, per MASTER_RESEARCH_HANDOFF Section 3)

P2 (research backlog):
- T11 NotebookLM 70-notebook population (4-wave priority)
- T12 BitBuddy persona portfolio entry
- T13 Green Paper public-facing version with FATExDAO context

---

## INSIGHTS_LEDGER
<!-- 1 pattern minimum per turn. Promote to skills.md when 2+ tasks confirm OR 1 hard-fail. -->

- INSIGHT 01 (2026-04-21, bootstrap turn): The dispatch_v2 OS pre_submit_gate is empty by design when forking. Seeding it with rules derived from canon (not from real failures) violates the OS's "no speculative rules" principle. RESOLUTION: Seed gate with rules whose evidence trace is explicit (IP scrub from MASTER_RESEARCH_HANDOFF Section 4, em-dash from user_preferences repeated, date consistency from cross-resume conflict surface, PEL from 143_Protocol_a Section 5). Each rule cites its derivation source. STATUS: applied to pre_submit_gate v1.0.

- INSIGHT 02 (2026-04-21, corpus analysis): Date conflicts are the single highest-frequency defect class across the resume corpus. Morgan Stanley end date (Nov 2014 vs Dec 2014 vs Jan 2015), NYC DOE end date (Jul 2021 vs Jun 2023), FATExDAO range (2020-2023 vs Oct 2021-Mar 2025), sageXresearch start (Aug 2023 vs 2024), Mercor start (Aug 2025 vs Oct 2025). PROMOTION: date_conflict_reconciler.md sub-skill created (immediate promotion grade, derived from corpus evidence, not hard-fail).

- INSIGHT 03 (2026-04-21, identity policy): Public name (Sage) and legal name (Austin Bennett Green) require strict separation in artifacts. Greenhouse and employer-required forms get legal name. Public artifacts (GitHub, LinkedIn, portfolio) get Sage. RESOLUTION: encoded into domain_rules block. PROMOTION: rolled into ip_scrub_pre_publish.md and pre_submit_gate v1.0 implicitly.

- INSIGHT 04 (2026-04-21, skill seeding): The MASTER_RESEARCH_HANDOFF "research and writing agent for Sage's 0sXai project" role is broader than just the Anthropic application. Ingesting it as canon (general role) enables sub-skills to inherit the role across all Sage workstreams (publication, portfolio, public statements). RESOLUTION: canonized at canon/MASTER_RESEARCH_HANDOFF_v2.md, sub-skills written as Sonnet-callable wrappers around it.

- INSIGHT 05 (2026-04-21, governance composition): The 143_Protocol_a Blueprint (Pathos-Ethos-Logos, Trinity Dialectic, Confidence Execution Loop) and the dispatch_v2 OS (TRUE=1/FALSE=0, pre_submit_gate, INSIGHTS_LEDGER) are NOT in conflict; they compose. dispatch_v2 supplies the file architecture and turn-ending invariant. 143_Protocol_a supplies the consequential-action ethics gate. RESOLUTION: pre_submit_gate v1.0 rule 4 invokes the PEL gate from 143_Protocol_a; trinity_dialectic_evaluator.md documents the 9-sub-evaluator matrix.

---

## OPEN_Q
<!-- load-bearing questions; each blocks at least one P0 task -->

OQ-01 (blocks T01 + T02 + T04): What is the canonical date range for FATExDAO that should appear on every artifact? MASTER_RESEARCH_HANDOFF surfaces two candidates: 2020-2023 (resume) vs Oct 2021 to Mar 2025 (LinkedIn). Need single canonical answer.

OQ-02 (blocks T01 + T02 + T04): What is the canonical start date for sageXresearch? MASTER_RESEARCH_HANDOFF surfaces Aug 2023 (LinkedIn) vs 2024 (resume). Single canonical answer needed.

OQ-03 (blocks T01 + T02): Israel and Ohr Sameach (April 2016 to early 2017, Talmud and Torah intensive, Jerusalem). Sage indicated verbal yes to override the STRICT EXCLUSION flag. Need explicit written confirmation: include in resume EDUCATION section as "Ohr Sameach Institutions, Jerusalem, Talmud and Torah intensive, 2016-2017" (or specific phrasing Sage prefers)? This bridges the gap years between Morgan Stanley exit and NYC DOE entry.

OQ-04 (queued, blocks T05 + GitHub push): GitHub commit email canonical: sagexresearch@gmail.com or other? (From MASTER_RESEARCH_HANDOFF OQ-09.)

OQ-05 (queued, blocks T08): Attribution path for archive-openbrain: Path A (derivative, keep upstream notices) or Path B (clean-room Sage-only)? (From MASTER_RESEARCH_HANDOFF OQ-08.)

---

## RULES

### protocol (from 1_INSTALL.md v1.0)
- All rules in 1_INSTALL.md are canonical. Rewrites require version bump and re-paste into Project settings.

### pre-submit gate rules (v1.0)
- See skills/pre_submit_gate.md.

### coverage rules
- Every artifact must have an explicit Trust Source Trace: each fact cites its source in canon or Sage-confirmation in chat.
- Every artifact intended for public release passes through ip_scrub_pre_publish.md before Sage sees the PEL package.
- Every Sonnet sub-agent invocation explicitly names the sub-skill loaded and the input contract.

---

## file registry

<canon_read_only>
- canon/143_protocol_a_blueprint.md
- canon/MASTER_RESEARCH_HANDOFF_v2.md
- canon/austin_resume_corpus_index.md
- /mnt/project/protocol_mandate.png (image source for 143_protocol_a textualization)
- /mnt/project/Austin_Green_Resume_2011.pdf
- /mnt/project/Austin_Green_Current_Resume_11-17-14_credit_policy.docx
- /mnt/project/Austin_Green__Current_Resume_docx.pdf
- /mnt/project/Austin_Green_Current_Resume_Fall_2019.pdf
- /mnt/project/AustinGreen_Current_Resume_2_12_20.pdf
- /mnt/project/Austin_Green_Resume_12_2025.pdf
- /mnt/project/Austin_Green_Resume_12_2025_2.pdf
- /mnt/project/Austin_Green_Resume_032026.pdf
- /mnt/user-data/uploads/MASTER_RESEARCH_HANDOFF.md (raw source)
- /mnt/user-data/uploads/compounding_learning_OS_dispatch_2026-04-21.zip (raw source)
</canon_read_only>

<mutable_self_evolving>
- state: spec.md (this file)
- skill_tree: skills.md
- wiki_log: Wiki_Log.md
- protocol_canon: 1_INSTALL.md
- telemetry: metrics_ledger.md
</mutable_self_evolving>

---

## user preferences

<user_preferences>
- No em dashes. Use commas, colons, semicolons, parentheses, line breaks.
- Multi-turn chat. Preserve Goal and Protocol across turns.
- Cite sources for factual claims. Prefer primary sources.
- Caveman tone in chat, full content in .md files.
</user_preferences>

---

## first move every new chat

<first_move>
1. project_knowledge_search "spec.md HOT_CACHE" to load current state.
2. Read skills.md tree-index. Load only the sub-skill relevant to the turn.
3. Pre-output eval: TRUE=1 acts, FALSE=0 asks up to 3 Qs.
4. If session is sonnet and task looks structural, self-assess. Recommend opus if confidence under 100%.
5. Read OPEN_Q. If unanswered OPEN_Q gates the requested task, answer that first via MULTI_TURN_CHAT_QUESTIONING.
</first_move>

---

## goal

<goal>
Anthropic Prompt Engineer (Claude Code) application submitted with 100% / TRUE=1 confidence: clean Greenhouse package, public GitHub portfolio (sage-prompt-engineering-portfolio), LinkedIn rewrite, Why Anthropic essay. Zero IP leak. Zero date inconsistency. Sage approves every public artifact via Pathos-Ethos-Logos before ship.
</goal>

END_SPEC
