# handoff_to_dispatch/OPEN_Q_BATCH_01.md
# From: Opus 4.7 chat session
# To: Sage (decision input)
# Date: 2026-04-21
# Status: ACTIVE, gates P0 application work

## the rules of this batch

- 3 load-bearing questions (max per turn per OS).
- Each gates at least 1 P0 task.
- Each provides PROVISIONAL_DEFAULT so Sage can answer with "default" if no preference.
- 4 LIKELY-OK confirms appended at the end. Sage can answer "all confirmed" in one line if no corrections needed.

## the 3 load-bearing questions

### OQ-01: FATExDAO date range

**Question**: What single date range should appear on every public artifact for FATExDAO?

GATES: T01 Anthropic PE resume, T02 Anthropic AR resume, T04 LinkedIn rewrite, T13 Green Paper public version.

CANONICAL_ENTRY_PRODUCED: canon/austin_resume_corpus_index.md row "Founder + CEO FATExDAO" date column.

CANDIDATES:
- A: 2020-2023 (matches Dec 2025 v1 resume + March 2026 resume)
- B: Oct 2021 to Mar 2025 (matches LinkedIn per MASTER_RESEARCH_HANDOFF v1)
- C: a different range Sage knows is correct

PROVISIONAL_DEFAULT: none, hard-block. Sage must choose.

REASONING_AID:
- Option A keeps continuity with most recent submitted resumes.
- Option B reflects the LinkedIn position which may include the post-launch wind-down period.
- The two are not necessarily contradictory: 2020-2023 could be "active build phase" and Oct 2021 to Mar 2025 could be "founding to formal exit". Sage should pick the framing that maps cleanly to the FATExDAO arc as Sage wants it represented for an Anthropic Prompt Engineer audience.

### OQ-02: sageXresearch start date

**Question**: What is the canonical start date for sageXresearch / SAGEx Research LLC?

GATES: T01 Anthropic PE resume, T02 Anthropic AR resume, T04 LinkedIn rewrite.

CANONICAL_ENTRY_PRODUCED: canon/austin_resume_corpus_index.md row "Founder + CEO SAGEx Research LLC" start date.

CANDIDATES:
- A: 2024 (matches March 2026 resume)
- B: Aug 2023 (matches LinkedIn per MASTER_RESEARCH_HANDOFF v1)
- C: a different date Sage knows is correct

PROVISIONAL_DEFAULT: none, hard-block. Sage must choose.

REASONING_AID:
- 2024 is when the LLC was likely formally registered.
- Aug 2023 is likely when Sage began branding research output as "sageXresearch" pre-LLC.
- Sage may want to pick the formal LLC date for resume (cleaner) and the branding-start date for personal narrative. If so, both are correct in different contexts; Sage picks per artifact.

### OQ-03: Ohr Sameach inclusion override

**Question**: Confirm in writing: include "Ohr Sameach Institutions, Jerusalem, Talmud and Torah intensive (April 2016 to early 2017)" in the EDUCATION section of resume variants and LinkedIn?

GATES: T01 Anthropic PE resume, T02 Anthropic AR resume, T04 LinkedIn rewrite, ip_scrub_pre_publish tier-2 clearance.

CANONICAL_ENTRY_PRODUCED: ip_scrub_pre_publish.md tier-2 clearance flip to PERMITTED + canon/austin_resume_corpus_index.md row addition + canon/MASTER_RESEARCH_HANDOFF_v2.md Part C row 7 status flip.

CANDIDATES:
- A: YES, include with the phrasing above.
- B: YES, include with different phrasing (Sage provides exact text).
- C: NO, leave out for now (would leave gap years 2015-2017 unexplained on resume).

PROVISIONAL_DEFAULT: none, requires explicit Sage written confirmation per IP scrub tier-2 rule.

REASONING_AID:
- Option A bridges the 2015-2017 gap cleanly and surfaces Sage's dialectical-reasoning training (which is non-trivially relevant to the Trinity Dialectic + Pathos-Ethos-Logos work that defines current technical output).
- Option B lets Sage frame more conservatively (e.g., "Independent Talmudic study, Jerusalem, 2016-17").
- Option C means recruiter sees a gap and may infer the wrong thing; Sage handles in essay if anywhere.

## the 4 LIKELY-OK confirmations (one-line answer accepted)

These were resolved by precedence ladder rung 4 (most-recent v032026 trace). Sage confirms or corrects.

| ID | Field | Provisional canonical | Confirm? |
|---|---|---|---|
| OQ-04 | Morgan Stanley end date | Jan 2015 | yes / no |
| OQ-05 | NYC DOE end date | June 2023 | yes / no |
| OQ-06 | Mercor / Micro1 start | Oct 2025 | yes / no |
| OQ-07 | Educational Enterprises span | 2002-2023 | yes / no |

If all 4 confirmed: write "all confirmed" and these flip to canonical.

## answer template (Sage paste-back)

```
OQ-01: [A | B | C: <range>]
OQ-02: [A | B | C: <date>]
OQ-03: [A | B: <exact text> | C]
OQ-04 through OQ-07: [all confirmed | corrections: ...]
PEL_for_resume_variant_writer_to_proceed: [PEL=1 | PEL=0 with reason]
```

## what happens after Sage answers

1. Opus updates canon/austin_resume_corpus_index.md with all 7 resolutions, bumps version comment.
2. Opus updates canon/MASTER_RESEARCH_HANDOFF_v2.md Part C and Part E with confirmed dates.
3. Opus invokes resume_variant_writer.md twice (PE variant, AR variant).
4. Each variant runs through pre_submit_gate v1.0 rules 1-3.
5. Each presents PEL packet (Architecture + Evidence + Intent) for Sage's PEL=1.
6. On PEL=1, files staged for Greenhouse submission and download.

END_OPEN_Q_BATCH_01
