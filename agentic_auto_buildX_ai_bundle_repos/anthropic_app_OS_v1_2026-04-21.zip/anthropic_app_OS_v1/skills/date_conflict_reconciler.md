# skills/date_conflict_reconciler.md
# Status: live
# Type: Sonnet-callable analytical reasoner
# Promotion grade: corpus-evidence (immediate, not from hard-fail), per spec.md INSIGHT 02

## purpose

Resolve cross-document date conflicts in Sage's biographical record using a deterministic precedence ladder. Return either a canonical answer (with trace) or escalate to Sage via socratic_question_generator.md when the ladder cannot resolve.

## input contract

The calling turn provides:

1. **field_in_conflict**: e.g., "FATExDAO start date", "Morgan Stanley end date".
2. **candidate_values**: list of (value, source_document, source_section, evidence_quote) tuples.
3. **escalation_threshold**: optional, default = 1 (any unresolved conflict escalates after one ladder pass).

## the precedence ladder

Rung 1: **Sage chat-confirmation in current session** (logged in spec.md). Authoritative if present.

Rung 2: **canon/MASTER_RESEARCH_HANDOFF_v2.md** explicit canonical statement. Authoritative if present and unambiguous.

Rung 3: **canon/austin_resume_corpus_index.md** canonical column. Authoritative if marked "canonical" or "LIKELY-OK with most-recent v032026 trace".

Rung 4: **most-recent resume version in corpus** (v032026 currently). Authoritative if rungs 1-3 silent and v032026 has the field.

Rung 5: **earlier corpus versions, conflict-free majority**. Authoritative if 4+ of 7 versions agree and v032026 is silent.

Rung 6: ESCALATE to Sage via socratic_question_generator.md. Do NOT silently pick.

## procedure

1. Walk the rungs in order. First rung that returns a value wins.
2. Construct canonical_entry = (field, value, rung_used, evidence_trace).
3. If rung 6 reached, return ESCALATE packet (the field, the candidate values, the reason ladder failed).
4. Append to spec.md: under INSIGHTS_LEDGER if a NEW pattern surfaced, under RULES if a precedence-ladder edge-case needs documenting.
5. If canonical_entry produced, also UPDATE canon/austin_resume_corpus_index.md (one of the rare canon-edits permitted, since it represents Sage's authoritative answer being recorded).

## output contract

```
DATE_CONFLICT_RECONCILER
field: <field_in_conflict>
candidates_evaluated: <count>
ladder_resolution: <rung_n> or ESCALATE
canonical_value: <value> or null
evidence_trace: <citation>
update_target_files: [canon/austin_resume_corpus_index.md, spec.md]
verdict_to_caller: TRUE=1 (canonical_value resolved) / FALSE=0 (escalated to Sage)
```

## current open conflicts (mirrored from corpus_index conflict surface)

| ID | Field | Status | Recommended next action |
|---|---|---|---|
| OQ-01 | FATExDAO date range | UNRESOLVED, rung-6 escalation | Sage answer required |
| OQ-02 | sageXresearch start | UNRESOLVED, rung-6 escalation | Sage answer required |
| OQ-04 | Morgan Stanley end date | rung-4 resolved (Jan 2015) | Sage confirm-or-correct |
| OQ-05 | NYC DOE end date | rung-4 resolved (June 2023) | Sage confirm-or-correct |
| OQ-06 | Mercor / Micro1 start | rung-4 resolved (Oct 2025) | Sage confirm-or-correct |
| OQ-07 | Educational Enterprises span | rung-4 resolved (2002-2023) | Sage confirm-or-correct |

END_DATE_CONFLICT_RECONCILER
