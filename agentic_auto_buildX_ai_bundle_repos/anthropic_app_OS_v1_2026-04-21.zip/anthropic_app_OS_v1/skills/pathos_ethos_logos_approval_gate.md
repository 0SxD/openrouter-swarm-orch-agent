# skills/pathos_ethos_logos_approval_gate.md
# Status: live
# Derivation: 143_Protocol_a Section 5 + Sage's user statement this session
# Type: human-in-the-loop checkpoint (Sage runs the verdict, not Claude)

## purpose

Sage's mandatory approval point before any public-facing artifact ships. Composes the Trinity Dialectic from 143_Protocol_a Section 5 with the dispatch_v2 OS's TRUE=1/FALSE=0 turn-ending invariant.

## when to invoke

Any artifact with at least one of:
- Public attribution (Sage, Austin Bennett Green, 0SxD, sageXresearch).
- External recipient (recruiter, employer, public site, sent message).
- Permanent or hard-to-revoke effect (GitHub commit on default branch, Greenhouse submission, LinkedIn About update).

Internal exploratory drafts, scratch artifacts, and Wiki_Log entries do NOT require PEL.

## what Claude packages (the Architecture + Evidence + Intent triplet)

Per 143_Protocol_a Section 5 Confidence Execution Loop:

### Architecture
The structural shape of the artifact: sections, ordering, length, format, tone register. One paragraph or a short bullet list. Claude states what design choices were made and why each serves the artifact's purpose.

### Evidence
The trust source trace for every factual claim: cite canon entry or Sage chat-confirmation for each non-trivial assertion. List any fact that lacks a clean trace, even if Claude is confident.

### Intent
What outcome the artifact is built to produce, who the reader is, what action Claude expects the reader to take after reading. One paragraph.

## the verdict Sage returns

- **PEL=1 ship**: Claude proceeds to publish, send, or hand off.
- **PEL=0 revise**: Claude enters surgical-fix mode (minimum-edit revision, only the items Sage flagged). One-line reason from Sage required: which of (Pathos, Ethos, Logos) is in disagreement and why.
- **PEL=ASK**: Sage requests Claude to expand one of the three categories. Claude returns the expansion, then Sage re-issues PEL.

## what Claude does NOT do

- Claude does NOT self-issue PEL.
- Claude does NOT proceed to ship on Sage silence (no implicit PEL=1 from "ok" or no response). Explicit PEL=1 required.
- Claude does NOT skip this gate even if Sage requested speed. The gate is invariant.

## interaction with pre_submit_gate

PEL is rule 4 of pre_submit_gate v1.0. The full sequence at ship time:

1. Claude assembles artifact.
2. Claude runs pre_submit_gate rules 1, 2, 3 silently. If any FAIL, Claude does NOT present to Sage, fixes first.
3. Claude presents artifact + Architecture + Evidence + Intent triplet to Sage.
4. Sage returns PEL verdict.
5. On PEL=1, Claude proceeds. On PEL=0, surgical fix and re-present (back to step 3).

## handoff to the trinity_dialectic_evaluator

For especially consequential artifacts (Greenhouse submission, public paper publication, GitHub repo public release), Sage may ask Claude to run trinity_dialectic_evaluator.md AHEAD of presenting to Sage. The evaluator returns 9 sub-evaluations as a structured packet, which Sage then uses as input to PEL. This is optional and Sage-initiated.

END_PEL_GATE
