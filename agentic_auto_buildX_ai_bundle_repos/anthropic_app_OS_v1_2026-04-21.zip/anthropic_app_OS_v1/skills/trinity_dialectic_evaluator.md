# skills/trinity_dialectic_evaluator.md
# Status: live
# Derivation: 143_Protocol_a Section 5
# Type: structured 9-cell evaluation, returns packet to Sage for PEL input
# Note: exact axis labels in the source infographic are partially illegible. Working labels below preserve the 3x3 structure and "9 sub-evaluators" count which IS explicit in the source.

## the 3x3 matrix

The Trinity Dialectic decomposes evaluation along two axes. Each axis has 3 elements. Their product is 9 independent sub-evaluations.

### axis 1: paths (the 3 forms of reasoning)
- **Logos**: Analytical Path. Logic, proof, shortest demonstrably correct route. Evidence-driven.
- **Pathos**: Creative Drive. DMN, purpose, longest most-extraordinary route to goal. Vision-driven.
- **Ethos**: Golden Mean. Phronesis, practical wisdom, arbitration. Justifies action only when Logos and Pathos accord.

### axis 2: kinds (the 3 dimensions of evaluation)
Working labels (source infographic illegible on these):
- **Form** (Logical Forms): structural correctness. Does the artifact's structure match its intended function?
- **Kind** (Ethical Kinds): consequence assessment. What does shipping this artifact cause in the world?
- **State** (Internal States): coherence with Sage's current arc. Does this artifact represent who Sage is right now (not 3 years ago, not 3 years aspirationally)?

## the 9 sub-evaluations

| Cell | Question to evaluate |
|---|---|
| Logos x Form | Is the artifact's structure logically sound, free of contradictions, and atomically organized? |
| Logos x Kind | Are the artifact's claims supported by traceable evidence (canon citation or Sage confirmation)? |
| Logos x State | Does the artifact's reasoning chain match Sage's current technical / intellectual position (not stale)? |
| Pathos x Form | Does the artifact's structure serve its emotive / persuasive purpose (e.g., does the resume's ordering create the intended arc)? |
| Pathos x Kind | Will the artifact land with the intended reader as Sage hopes (recruiter, hiring manager, public reader)? |
| Pathos x State | Does the artifact express Sage's voice as Sage wants to be heard right now? |
| Ethos x Form | Is the artifact's structure within the bounds of Sage's professional and personal ethics (no overclaim, no fabrication)? |
| Ethos x Kind | Are the consequences of shipping this artifact net-positive across all stakeholders (Sage, employer, community)? |
| Ethos x State | Does shipping this artifact preserve Sage's integrity given their current commitments and identity? |

## evaluator output format

```
TRINITY_DIALECTIC_EVALUATOR
artifact: [name + version]
date: [ISO]

Logos x Form:    PASS / FAIL [+ one-line reason]
Logos x Kind:    PASS / FAIL [+ one-line reason]
Logos x State:   PASS / FAIL [+ one-line reason]
Pathos x Form:   PASS / FAIL [+ one-line reason]
Pathos x Kind:   PASS / FAIL [+ one-line reason]
Pathos x State:  PASS / FAIL [+ one-line reason]
Ethos x Form:    PASS / FAIL [+ one-line reason]
Ethos x Kind:    PASS / FAIL [+ one-line reason]
Ethos x State:   PASS / FAIL [+ one-line reason]

aggregate:
  Logos: 3 PASS / 0 FAIL  (or n PASS / 3-n FAIL)
  Pathos: 3 PASS / 0 FAIL
  Ethos: 3 PASS / 0 FAIL

verdict_to_Sage: 100% confidence (9 PASS) or below (with cell-by-cell repair list)
```

## promotion rule

Trinity Dialectic is invoked at Sage's request, NOT automatically. Default consequential-action gate is the simpler PEL gate. Trinity is reserved for Greenhouse submission, public paper publication, public repo release, and any artifact Sage specifically tags "run Trinity".

## the rule of three accord

Action justified ONLY when all three (Logos, Pathos, Ethos) score 3 PASS. ANY axis with at least one FAIL pauses ship and requires repair. This implements the source statement "Action is only justified when both [Logos and Pathos] are in accord and validated by 9 sub-evaluators."

END_TRINITY_DIALECTIC_EVALUATOR
