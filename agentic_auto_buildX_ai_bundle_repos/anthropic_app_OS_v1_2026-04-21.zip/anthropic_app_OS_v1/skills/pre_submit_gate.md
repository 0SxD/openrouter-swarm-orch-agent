# skills/pre_submit_gate.md
# Status: live, v1.0
# Derivation: composed from MASTER_RESEARCH_HANDOFF Section 4 + 143_Protocol_a Section 5 + user_preferences (repeated) + cross-resume conflict surface
# Promotion grade: bootstrap-seed (not from real failure). Each future hard-fail bumps this version.

## purpose

Final gate. All 4 rules must return TRUE before any artifact ships to a public surface (Greenhouse submission, GitHub push, LinkedIn update, public blog post, sent email to recruiter, sent message in any external channel under Sage's name).

## the 4 rules

### rule 1: IP scrub
Run skills/ip_scrub_pre_publish.md against the artifact text. PASS = no exclusion-list hit. ANY HIT = block.

Derivation: MASTER_RESEARCH_HANDOFF Section 4 (Personal identity, Trading IP, Private corpus, Personal documents, Scrub-before-push items).

### rule 2: date consistency
Every date in the artifact (years, ranges, "to Present", "since X") must trace to either:
(a) Sage's confirmation in current chat (logged in spec.md), OR
(b) canonical entry in canon/austin_resume_corpus_index.md.

Any date with no trace = block. Trace by inline citation comment in the draft (e.g., `<!-- date trace: corpus_index v032026 -->`).

Derivation: cross-resume conflict surface across 8 versions, 7 conflicts identified (3 P0, 4 likely-OK).

### rule 3: no em dashes
Mechanical scan for U+2014 (em dash) and U+2013 (en dash). Any hit blocks.

Replacement guidance:
- U+2014 to comma, semicolon, colon, parentheses, or line break
- U+2013 to "to" in date ranges (e.g., "2017-2019" OK as hyphen, "2017 to 2019" preferred prose form)

Derivation: user_preferences (repeated explicitly in project_instructions, in dispatch_v2 OS, and in the user's message this turn).

### rule 4: Pathos-Ethos-Logos verdict from Sage
For any public-facing artifact, Claude packages an Architecture + Evidence + Intent triplet (the Confidence Execution Loop output per 143_Protocol_a Section 5). Sage runs Pathos-Ethos-Logos and returns:
- PEL=1: ship
- PEL=0: revise (with one-line reason)
- PEL=ASK: Sage requests Sonnet sub-agent to expand one of the three categories

PEL=1 required to ship. Claude does NOT self-issue PEL.

Derivation: 143_Protocol_a Section 5 Confidence Execution Loop, plus user statement this session: "all activities we can that would be worth doing per my approval after pathos-ethos-logos with me".

## verdict format

Claude states the gate result inline before any ship action:
```
PRE_SUBMIT_GATE v1.0
- rule 1 IP scrub: PASS / FAIL [+ hits]
- rule 2 date consistency: PASS / FAIL [+ untrac'd dates]
- rule 3 no em dashes: PASS / FAIL [+ positions]
- rule 4 PEL verdict: PASS (PEL=1) / FAIL (PEL=0 or ASK)
VERDICT: TRUE=1 ship, FALSE=0 block.
```

## evolution rule

Each hard-fail (an artifact that shipped or was about to ship and turned out defective) produces a new rule. Bump version (v1.0 to v1.1, etc). Append to spec.md COMPACTION_LEDGER. Re-paste 1_INSTALL.md into Project settings (the gate is referenced there).

Speculative rules forbidden. Only real-failure-derived rules enter the gate.

END_PRE_SUBMIT_GATE
