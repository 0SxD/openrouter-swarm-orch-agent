# skills/socratic_question_generator.md
# Status: live
# Type: Sonnet-callable session-ops procedure
# Derivation: 143_Protocol_a Interaction Method (Socratic) + dispatch_v2 MULTI_TURN_CHAT_QUESTIONING

## purpose

Generate 1-3 load-bearing questions that close the smallest set of gaps required to reach 100% confidence on the active task. Append to spec.md OPEN_Q. Block the task on Sage's answers.

## input contract

1. **active_task**: the P0 or P1 task currently blocked.
2. **gaps_identified**: list of (gap_description, what_assumption_would_be_required) pairs.
3. **ladder_state**: list of which precedence rungs (canon, corpus, Sage chat) have been walked and exhausted.

## the 3 rules of question quality

1. **load-bearing**: each question must close a specific gap that would otherwise force an assumption. If Claude can answer the question by reading canon, it is NOT a question for Sage.

2. **answerable in one sentence**: questions that require Sage to write a paragraph are weak. Decompose. "What is the FATExDAO date range?" is strong. "Tell me about FATExDAO" is weak.

3. **gap-disclosing**: each question states which downstream task it gates and what canonical entry it produces. Sage should see the cost of leaving it unanswered.

## procedure

1. Take input gaps_identified.
2. For each gap, check if any canon entry or recent chat already answered it. If yes, REMOVE from gap list (Claude failed to look first).
3. Rank remaining gaps by gating-power: how many P0 tasks does each gap block? Most-gating first.
4. Take top 3 (max).
5. Format each as load-bearing question per the 3 rules.
6. Append to spec.md OPEN_Q with assigned ID (next sequential, e.g., OQ-08).
7. Present to Sage in chat with this format:

```
OPEN_Q BATCH <NN>

OQ-XX: <one-sentence question>
  GATES: <list of P0 tasks this blocks>
  CANONICAL_ENTRY_PRODUCED: <field that gets populated on answer>
  PROVISIONAL_DEFAULT: <what Claude would assume absent answer, OR "none, hard-block">
```

8. Mark active_task as FALSE=0 BLOCKED until OPEN_Q answered.

## escalation handling

If Sage's answer is itself ambiguous, do NOT iterate questions endlessly. After 1 round of clarification, if still unclear, escalate via:
- Pause active_task.
- Move OPEN_Q to OQ-DEFERRED status in spec.md.
- Recommend Sage consult adjacent canon (handoff_to_dispatch artifacts, prior chat history) and return.

## output contract

```
SOCRATIC_QUESTION_GENERATOR
gaps_in: <count>
gaps_already_in_canon: <count, removed>
gaps_remaining: <count>
OPEN_Q_appended: [OQ-XX, OQ-YY, ...]
active_task_status: FALSE=0 BLOCKED until [OQ-XX, OQ-YY] answered
verdict_to_caller: TRUE=1 questions ready / FALSE=0 if no genuine gaps remain (caller should retry without escalation)
```

## anti-pattern guard

Do NOT generate questions just because the OS has a "questions" affordance. If the active_task can be completed at 100% confidence with current canon + chat state, ZERO questions is the correct output. Pre-output eval rule: "TRUE=1 acts, FALSE=0 asks". Acting at TRUE=1 is the win condition, not asking.

END_SOCRATIC_QUESTION_GENERATOR
