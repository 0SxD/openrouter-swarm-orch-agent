# skills/resume_variant_writer.md
# Status: live
# Type: Sonnet-callable artifact producer
# Cost profile: opus_gate on first variant of new role-type; sonnet_exec on subsequent variants

## purpose

Produce a 1-page, ATS-safe resume variant tailored to a specific target role, sourced strictly from canon (canon/austin_resume_corpus_index.md and canon/MASTER_RESEARCH_HANDOFF_v2.md), with zero IP leak and zero em dashes.

## input contract

The calling turn must provide:

1. **target_role**: structured object with at minimum:
   - role_title (e.g., "Prompt Engineer, Claude Code")
   - employer (e.g., "Anthropic")
   - greenhouse_id (if applicable)
   - jd_text or jd_summary (3-5 bullets of what the role needs)
   - top_signals (which 3-5 of Sage's experiences map most directly)

2. **variant_slug**: snake_case identifier (e.g., "anthropic_prompt_engineer", "anthropic_applied_research").

3. **resolved_open_q_payload**: dictionary of canonical answers to gating OPEN_Q items. At minimum for current state: OQ-01 FATExDAO range, OQ-02 sageXresearch start, OQ-03 Ohr Sameach inclusion. If any required OQ is unresolved, this skill returns FALSE=0 and escalates via socratic_question_generator.md.

4. **format_constraints**:
   - max_pages: 1 (default) or 2 (Sage override)
   - layout: ATS-safe (no tables, no graphics, no columns, standard fonts)
   - file_format: docx and pdf parallel outputs

## output contract

1. **resume_<variant_slug>_v1.md**: source-of-truth markdown.
2. **resume_<variant_slug>_v1.docx**: ATS-safe Word file (use docx skill from /mnt/skills/public/docx/SKILL.md).
3. **resume_<variant_slug>_v1.pdf**: PDF rendition (use pdf skill).
4. **architecture_evidence_intent.md**: the PEL packet for Sage to evaluate.

## procedure

1. Load canon/MASTER_RESEARCH_HANDOFF_v2.md and canon/austin_resume_corpus_index.md.
2. From input contract, extract target_role signals.
3. Map Sage's experiences to JD signals: 4-column table (JD signal, Sage canonical entry, evidence trace, gap-or-match).
4. Draft sections in this order:
   a. Header: name (per public_name policy in domain_rules), contact (from corpus index), LinkedIn URL.
   b. Professional Summary: 2-3 sentences, voice = Sage (independent-convergence with frontier research, biomimicry-grounded, 20-year cross-domain synthesis). NO corporate speak.
   c. Core Skills (or Selected Capabilities): 3 lanes max, top signals only.
   d. Professional Experience: most-recent first. Each role: 2-4 bullets, action-verb led, quantified where canon supports.
   e. Education: chronological reverse, include Ohr Sameach IF OQ-03 = include.
   f. Certifications and Licenses.
5. Insert inline date-trace comments next to every date: `<!-- date trace: corpus_index_v032026 -->` or `<!-- date trace: Sage chat 2026-04-21 -->`.
6. Run pre_submit_gate v1.0 rules 1, 2, 3 (IP scrub, date consistency, em dash scan). Repair any FAIL.
7. Render docx and pdf. Verify ATS-safety (try copy-paste to plain text, confirm structure preserves).
8. Build PEL packet (Architecture + Evidence + Intent triplet).
9. Return all 4 outputs to calling turn.

## verification step

Calling turn presents PEL packet to Sage. Sage returns PEL=1 ship, PEL=0 revise (with reason), or PEL=ASK. On PEL=1, calling turn forwards files to download and to handoff_to_dispatch/ for Greenhouse upload sequence.

## known precedents

- Anthropic Prompt Engineer (Claude Code) variant: target. Greenhouse 5159669008. P0.
- Anthropic Applied Research variant: target, secondary. P0.
- Future variants (post-Anthropic, queued in TASK_QUEUE P1+): EdTech founder pitch, technical writer, AI ethics consultant.

## terminal verdict format

```
RESUME_VARIANT_WRITER
variant_slug: <slug>
target: <role_title> at <employer>
output_files: [resume_<slug>_v1.md, .docx, .pdf, architecture_evidence_intent.md]
pre_submit_gate v1.0:
  rule 1 IP scrub: PASS / FAIL
  rule 2 date consistency: PASS / FAIL
  rule 3 no em dashes: PASS / FAIL
  rule 4 PEL: PENDING (awaiting Sage)
verdict_to_caller: TRUE=1 ready for Sage PEL / FALSE=0 escalate to socratic_question_generator
```

END_RESUME_VARIANT_WRITER
