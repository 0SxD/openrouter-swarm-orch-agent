# skills/ip_scrub_pre_publish.md
# Status: live
# Type: Sonnet-callable safety check, runs as pre_submit_gate v1.0 rule 1
# Derivation: MASTER_RESEARCH_HANDOFF Section 4 in full

## purpose

Mechanically scan an artifact for any item on Sage's IP exclusion list. Block ship on any HIT.

## input contract

1. **artifact_text**: full text of the artifact about to ship (resume body, README, LinkedIn About, essay, sent-message body).
2. **artifact_type**: one of {resume, github_readme, linkedin_section, essay, email, social_post, paper_draft}.
3. **destination**: where it would publish to (e.g., "Greenhouse 5159669008", "github.com/0SxD/sage-prompt-engineering-portfolio README", "linkedin.com/in/austin-bennett-green About").

## the exclusion list (hard rules, ordered by severity)

### tier 1: NEVER PUBLISH (immediate hard block)

#### personal identity
- Machine hostnames: DESKTOP-8AMMKQP, any DESKTOP-* pattern.
- Internal usernames in commits or paths: austing143, sagexresearch (NOT the email; the username token).
- Windows paths: C:\, C:/, C:\Users\Austin*, C:\apps_ai\*.
- Internal lane codes: CCC0x, SS-xx, SS14, SS-anything pattern.
- API key patterns: sk-or-v1-*, sk-ant-*, anthropic_api_key=, openrouter_api_key=, any 40+ char hex string adjacent to "key".

#### trading and strategy IP
- Strategy names: Fibonacci (in trading context), Ichimoku (in trading context), DTMC Markov engine, xD_Arbitrage.
- File references: FxD_build_notes, quant_pipeline_architecture, Master Plan files (any file titled "Master Plan*").
- Live backtest data, performance percentages from real strategies.
- DeFi flash loan blueprint details.

#### private corpus
- NotebookLM real notebook UUIDs (UUID4 patterns).
- File references: notebooklm-contents (batch1, batch2), notebooklm-upload-roadmap.

#### personal documents
- Passport numbers, tax IDs, SSN, driver's license numbers.
- Selfies, photos.
- SAGEx, HUMANx, FATEx product suite operational details (the public-facing Green Paper framing of FATExDAO is OK; operational details are NOT).
- AGI_0s, bitBuddy concept implementation details (the persona name reference is OK in narrative; implementation is NOT).

#### scrub-before-push items
- FLAG-001 literal token (specific to lines 385/388/397 of Symbolic_Arch_Dialectic).
- EXIF data on PNGs (run exiftool, strip if present).
- .claude/ directory contents.
- Jupyter notebook cell outputs with local paths.

### tier 2: CONDITIONAL PUBLISH (require Sage explicit confirmation per artifact)

- Israel and Ohr Sameach (April 2016 to early 2017). Sage has indicated verbal yes to override; OQ-03 awaits written confirmation. UNTIL OQ-03 = include, this is BLOCK; AFTER OQ-03 = include, this is PASS.
- "Austin" (personal first name) in public artifacts. Public name policy is "Sage". Greenhouse forms are exception (legal name field).
- Phone numbers older than (917) 653-6519. Old numbers leak prior addresses.
- Old physical addresses (Naugatuck CT, Union City NJ, Hudson County NJ, North Bergen NJ).
- Specific employer-internal stakeholder names (CFOs, hiring managers, named clients) absent published authorization.

### tier 3: PASSIVE CAUTION (allow but flag for Sage awareness)

- "FATExDAO" as named project. Public framing OK; flag if Sage wants pseudonym in this artifact.
- "Mercor" / "Micro1" employer names if in active NDA period (current per MASTER_RESEARCH_HANDOFF describes as "Top AI RL Training Firm (NDA: Contract)" in v032026; flag for Sage to check NDA status).
- "Anthropic" naming in public artifacts before submission lands. Mention in cover letter or essay is fine; in a public LinkedIn About line ("currently applying to Anthropic") is flag-for-review.

## procedure

1. Tokenize artifact_text.
2. Run regex scan against each tier-1 pattern. Any HIT = HARD BLOCK with location list.
3. Run regex + context scan against tier-2 patterns. Any HIT = CONDITIONAL BLOCK; check session-state for matching Sage clearance (e.g., OQ-03 answer).
4. Run regex against tier-3 patterns. Any HIT = FLAG (does not block; surfaces to Sage in PEL packet).
5. EXIF scan on any image attachments (use exiftool).
6. Render verdict.

## output contract

```
IP_SCRUB_PRE_PUBLISH
artifact: <type> destined for <destination>
length: <chars>

tier_1_hits:
  - (none)
  OR
  - [pattern]: matched at position N, context: "...sentence fragment..."
  
tier_2_hits:
  - (none)
  OR
  - [pattern]: matched, requires Sage clearance per OQ-XX

tier_3_flags:
  - (none)
  OR
  - [pattern]: matched, FYI

EXIF_scan: PASS / FAIL (n images stripped)

verdict: PASS (all clear) / CONDITIONAL_BLOCK (tier 2, awaiting Sage) / HARD_BLOCK (tier 1)
```

## evolution rule

New tier-1 patterns added when Sage identifies a new exclusion. New tier-2 patterns added when Sage flags an item as conditional. Tier-3 patterns added when something is "probably fine but worth surfacing".

When a tier-2 hit is cleared by Sage, log the clearance in spec.md RULES and bump the conditional to "permitted-with-context".

END_IP_SCRUB
