# canon/austin_resume_corpus_index.md
# Source: 8 versioned Austin/Sage resumes spanning 2011 to March 2026
# Canonized: 2026-04-21
# Status: read-only analytical canon, single source of truth for biographical timeline.
# Conflicts surface to spec.md OPEN_Q. Sage answers, then this file is updated and bumped.

## resume corpus inventory

| Version slug | Filename | Approximate date | Then-current role | Then-public name |
|---|---|---|---|---|
| v2011 | Austin_Green_Resume_2011.pdf | 2011 (current at Interaudi) | Interaudi Bank, Credit Portfolio Officer | Austin B. Green |
| v2014_docx | Austin_Green_Current_Resume_11-17-14_credit_policy.docx | Nov 17 2014 | Morgan Stanley, current | Austin Green |
| v2014_pdf | Austin_Green__Current_Resume_docx.pdf | post-Morgan Stanley exit, ~late 2014 | between roles | Austin Bennett "Sage" Green |
| vFall2019 | Austin_Green_Current_Resume_Fall_2019.pdf | Fall 2019 (3rd year teaching) | NYC DOE MS328 | Austin Green |
| vFeb2020 | AustinGreen_Current_Resume_2_12_20.pdf | Feb 12 2020 | NYC DOE MS328 | Austin Green |
| vDec2025_v1 | Austin_Green_Resume_12_2025.pdf | Dec 2025 | Micro1 / Mercor + Fullmind etc | Austin Bennett Green |
| vDec2025_v2 | Austin_Green_Resume_12_2025_2.pdf | Dec 2025 (revision) | Micro1 / Mercor + Fullmind etc | Austin Bennett Green |
| v032026 | Austin_Green_Resume_032026.pdf | March 2026 | Top AI RL Training Firm + tutoring + SAGEx | AUSTIN BENNETT GREEN |

---

## canonical biographical timeline (best-current-evidence)

### education (no conflicts in source corpus, gap year sourced from MASTER_RESEARCH_HANDOFF)

| institution | dates | credential | source | status |
|---|---|---|---|---|
| Collegiate School | 1995-99 | High School Diploma, full scholarship | v032026, MASTER_RESEARCH_HANDOFF | canonical |
| University of Vermont | 2000-01 | transferred out | MASTER_RESEARCH_HANDOFF (NOT on resumes) | canonical, optional disclosure |
| Columbia University | 2001-06 | BA International Political Economy, scholarship | all resumes | canonical |
| MIT Sloan StartingBloc | 2005 | Fellowship in CSR, case competition winner | all resumes from 2014 forward | canonical |
| NYU School of Professional Studies | 2009-13 | Graduate Diploma in Credit Analysis (NOT a Master's) | v2014, v032026, MASTER_RESEARCH_HANDOFF | canonical |
| Ohr Sameach Institutions, Jerusalem | April 2016 to early 2017 | Talmud + Torah intensive | MASTER_RESEARCH_HANDOFF only, NOT YET on any resume | pending OQ-03 |
| Relay Graduate School of Education | 2017-19 | M.Ed. Middle Mathematics Education, 3.6 GPA Honors | vFall2019, vFeb2020, vDec2025, v032026, MASTER_RESEARCH_HANDOFF | canonical |

### career (conflicts surfaced)

| role | employer | dates | source consensus | conflict notes |
|---|---|---|---|---|
| Financial Executive Intern | Citicorp Investment Services | March 2005 to Sept 2005 | v2011, v2014_docx | canonical (early-resume only, optional for current display) |
| Senior VP Intern | Merrill Lynch Global Client Group | Sept 2005 to March 2006 | v2011, v2014_docx | canonical (early-resume only, optional for current display) |
| Proprietary Equity Trader | Trillium Trading LLC | June 2006 to May 2007 (v2011, v2014, vFall2019, vFeb2020); May 2006 to May 2007 (v2014_pdf) | June 2006 entry consensus across most resumes | Series 7 + 55 expired Aug 2009 |
| Credit Portfolio Officer | Interaudi Bank | May 2007 to May 2011 | v2014, vFall2019, vFeb2020, vDec2025, v032026 | canonical |
| VP Credit PM Treasury Risk Management | RBS Citizens NA | May 2011 to May 2014 | all later resumes | canonical |
| VP Tailored Lending PM Underwriter | Morgan Stanley Private Bank | May 2014 to ??? | **CONFLICT** | Nov 2014 (v2014_pdf, vFall2019, vDec2025_v1), Dec 2014 (vFeb2020), Jan 2015 (v032026). Most-recent v032026 says Jan 2015. PROVISIONAL CANONICAL: May 2014 to Jan 2015. Sage to confirm. |
| Founder Ivy League Tutors / Educational Enterprises LLC | self | Sept 2001 to 2018 (v2011 says 2001-03; vFall2019 says 2003-2018; v032026 says 2002-2023) | **CONFLICT** | Span unclear. v032026 most recent says 2002-2023. Sage to confirm endpoint. |
| Math Teacher + CS4ALL | NYC DOE Bronx (MS328 / Bronx Academy of the Arts) | Sept 2017 to ??? | **CONFLICT** | "Present" (vFall2019, vFeb2020), "July 2021" (v2014_docx wait, v2014_docx is pre-teaching, this is from another), Aug 2017 to June 2023 (vDec2025_v2), Jul 2017 to Jun 2023 (v032026). PROVISIONAL CANONICAL: Aug 2017 to June 2023, per most-recent v032026. |
| Founder + CEO | FATExDAO | 2020-2023 (vDec2025_v1, v032026) vs Oct 2021 to Mar 2025 (LinkedIn per MASTER_RESEARCH_HANDOFF) | **CONFLICT** | OQ-01 gating. Sage to confirm. |
| Founder + CEO | SAGEx Research LLC / sageXresearch | 2024 to Present (v032026) vs Aug 2023 (LinkedIn per MASTER_RESEARCH_HANDOFF) | **CONFLICT** | OQ-02 gating. Sage to confirm. |
| Private Homeschool Lead Educator | private | 2023-2024 (vDec2025_v2) | canonical | neurodivergent autistic student curriculum |
| Virtual Classroom Teacher | Amergis Staffing PAPER/GROW | Aug 2024 to Aug 2025 (vDec2025_v2) | canonical | |
| Virtual Educator | FullMind / Bilin Academy / LingoAce | 2024 to Present (vDec2025_v2) | canonical | |
| AI Teaching Expert Team Lead | Micro1 / Mercor AI | Aug 2025 to Present (vDec2025_v2) vs Oct 2025 to Present (v032026) | **CONFLICT** | Most recent v032026 says Oct 2025. PROVISIONAL CANONICAL: Oct 2025. Sage to confirm. |

---

## name presentation history

| Version | Name displayed |
|---|---|
| v2011 | Austin B. Green |
| v2014_docx | Austin Green |
| v2014_pdf | Austin Bennett "Sage" Green |
| vFall2019 | Austin Green |
| vFeb2020 | AUSTIN GREEN |
| vDec2025_v1 | Austin Bennett Green |
| vDec2025_v2 | Austin Bennett Green |
| v032026 | AUSTIN BENNETT GREEN |

PUBLIC NAME POLICY (from MASTER_RESEARCH_HANDOFF Part B and domain_rules in 1_INSTALL.md):
- Public artifacts (GitHub, LinkedIn portfolio, blog): "Sage"
- Greenhouse / employer-required forms: "Austin Bennett Green" (legal name)
- Resume header for Anthropic application: TBD per Sage preference. Most professional consistent rendering across the corpus suggests "Austin Bennett Green" with optional "Sage" annotation.

---

## contact info history

| Version | Address | Phone | Email |
|---|---|---|---|
| v2011 | Naugatuck CT | (917) 440-9717 | AustinBGreen@gmail.com |
| v2014_docx | NYC, 870 Riverside Dr | (203) 726-0311 | austinbgreen@gmail.com |
| v2014_pdf | Union City NJ | (917) 653-6519 | austin@fatex.io |
| vFall2019 | Hudson County NJ | (203) 726-0311 | austing143@gmail.com |
| vFeb2020 | North Bergen NJ | (917) 653-6519 | austing143@gmail.com |
| vDec2025_v1 | NYC | (917) 653-6519 | austing143@gmail.com |
| vDec2025_v2 | NYC | (917) 653-6519 | austing143@gmail.com |
| v032026 | NYC | (917) 653-6519 | austing143@gmail.com |

CANONICAL CONTACT (per MASTER_RESEARCH_HANDOFF + most-recent corpus):
- Phone: (917) 653-6519
- Email: austing143@gmail.com
- Address line: NYC (or US Pacific timezone if relocating per Anthropic role requirements per MASTER_RESEARCH_HANDOFF Part G)
- LinkedIn: linkedin.com/in/austin-bennett-green

---

## certifications and licenses

| Cert | Status | Source |
|---|---|---|
| NYS Professional Teaching Certificate #1946817251 | Active, valid through 1/31/2031, all subjects with mathematics focus (Grades 5-9) | vDec2025_v2 |
| NYS Licensed Math Teacher (Grades 5-7) | 2017-2023 | vDec2025_v2 |
| Bilingual Spanish extension | pending approval | v032026 |
| FINRA Series 7 (Stockbroker) | historical, expired Aug 2009 | v032026, vFeb2020 |
| FINRA Series 55 (Equity Trading) | historical, expired Aug 2009 | v032026, vFeb2020 |

---

## skill self-claims aggregated across corpus

Finance: Credit Underwriting, Financial Analysis, Collateral Valuation, Portfolio Risk Management, Credit Policy + Controls, Global Transaction Services, Basel/Dodd-Frank, Deal Sourcing, Credit Facility Structuring + Closing, Moody's KMV.

Education: Standards-Aligned All-Subjects Instruction, Singapore Method, AMC8 prep, Digital Pedagogy, Intervention Design, Test/Question Design, Data Analysis, CS Program Leadership (CS4ALL), Trauma-Informed Teaching, IEP/ELL Differentiation.

AI / Product / Tech: RL Training Workflows, Prompt Architecture, Structured Task Design, QA Rubrics, Writer/Reviewer World-Team Leader, Project Management, Product Development, MVP Scoping, Startup Operations, Cryptocurrency/DeFi/Blockchain, Quantitative Algorithmic Trading, DAO Investment.

Languages: Advanced conversational Spanish, basic French.

Tools: Advanced MS Office (Excel macro), Bloomberg, LaserPro, CRM, financial modeling, Java/C++, Macromedia/Adobe.

---

## conflict surface summary (mirrored to spec.md OPEN_Q)

| ID | Field | Conflict | Provisional canonical | Status |
|---|---|---|---|---|
| OQ-01 | FATExDAO date range | 2020-2023 (resume) vs Oct 2021 to Mar 2025 (LinkedIn) | none, gating | OPEN, Sage |
| OQ-02 | sageXresearch start | 2024 (resume) vs Aug 2023 (LinkedIn) | none, gating | OPEN, Sage |
| OQ-03 | Ohr Sameach inclusion | not on any resume | yes per verbal Sage approval, awaiting written | OPEN, Sage |
| OQ-04 | Morgan Stanley end date | Nov 2014 vs Dec 2014 vs Jan 2015 | Jan 2015 (most-recent v032026) | LIKELY-OK, Sage to confirm |
| OQ-05 | NYC DOE end date | "Present" (older), Jul 2021 vs June 2023 | Aug 2017 to June 2023 (most-recent v032026) | LIKELY-OK, Sage to confirm |
| OQ-06 | Mercor / Micro1 start | Aug 2025 vs Oct 2025 | Oct 2025 (most-recent v032026) | LIKELY-OK, Sage to confirm |
| OQ-07 | Educational Enterprises LLC span | 2001-03 vs 2003-2018 vs 2002-2023 | 2002-2023 (most-recent v032026) | LIKELY-OK, Sage to confirm |

END_RESUME_CORPUS_INDEX
