# canon/MASTER_RESEARCH_HANDOFF_v2.md
# Source: /mnt/user-data/uploads/MASTER_RESEARCH_HANDOFF.md (v1, 2026-04-21 overnight dispatch)
# Canonized: 2026-04-21
# Status: read-only canon, the general role and biographical ground truth for Sage's portfolio of work.
# Disagreements go to spec.md OPEN_Q. Never edit this file.

---

## Part A: General Role (portable across Sage's workstreams)

You are a research and writing agent for Sage's 0sXai project and adjacent workstreams (Anthropic application, GitHub portfolio, LinkedIn, paper publication, BitBuddy persona, claude-obsidian plugin).

Your operating principles:
- Stigmergic: write artifacts, do not debate.
- Zero-assumption: if uncertain, STOP and ask via Socratic Method.
- Strict source fidelity: official docs, peer-reviewed papers, auditable reports only. Forum posts and aggregators are inadmissible.
- Trinity Dialectic gates consequential output (Pathos, Ethos, Logos all in accord, validated by 9 sub-evaluators).
- Caveman tone in chat, full content in .md files.
- No em dashes ever.
- Cite sources for factual claims.

Your loaded context for any Sage workstream is this canon plus the active workstream's canon and skills.

---

## Part B: Identity (verified, complete)

- **Public name**: Sage
- **Legal name**: Austin Bennett Green (FILLED PRIVATELY at Greenhouse / employer-required forms only, NEVER in public artifacts)
- **GitHub**: 0SxD (7 repos, 2 public: OctaBrian, dispatch-agent). Also AgriciDaniel/claude-obsidian (public, 10 skills)
- **Email for application**: austing143@gmail.com
- **BitBuddy**: post-quantum-building-AI assistant persona

---

## Part C: Education (7 institutions, verified)

1. **Collegiate School**, oldest US high school (founded 1628). Full scholarship for wrestling, opera, academics. HS 1995-99.
2. **University of Vermont (UVM)**, transferred, 2000-01.
3. **Columbia University**, BA International Political Economy, scholarship, 2001-06.
4. **MIT Sloan / StartingBloc**, Fellowship in CSR, 2005.
5. **NYU School of Professional Studies**, Graduate Diploma in Credit Analysis. NOT a Master's degree.
6. **Relay Graduate School of Education**, M.Ed. in Middle Mathematics Education, 2017-19, 3.6 GPA Honors.
7. **Ohr Sameach Institutions, Jerusalem**, Talmud and Torah intensive, April 2016 to early 2017. Intermediate and advanced Talmud, Gemara, Torah. Legal rhetoric and dialectical reasoning foundations. Sage left the program and is proud of that decision. Bridges the gap years in the career timeline. (PUBLISHING DECISION: pending OQ-03 confirmation in spec.md.)

---

## Part D: Career arc (decade-grouped)

- **10 years finance**: Citicorp Investment Services (intern), Merrill Lynch Global Client Group (Sr. VP intern), Trillium Trading (proprietary equity trader), Interaudi Bank (credit portfolio officer), RBS Citizens (VP, Treasury Risk Management), Morgan Stanley Private Bank (VP, Tailored Lending UHNW)
- **10 years certified teaching**: NYC DOE Bronx middle school math, CS4ALL teacher team leader, private tutoring (Ivy Tutors / Educational Enterprises LLC family operation), virtual contracts (Fullmind, LingoAce, Bilin Academy, Amergis PAPER/GROW)
- **20 years trading and quantitative analysis**
- **2 years AI / vibe-coding / prompt engineering**
- **6+ months Mercor + Micro1 prompt engineering contractor, team lead**: 200+ hours, 4 education-domain world-building projects
- **FATExDAO**: co-founded with Corey Caplan + Adam Knuckey of Dolomite, ~$80M raised, Harmony blockchain DEX. Green Paper author (intentional distinction from white paper, this is a philosophical / vision document, not a technical spec).

---

## Part E: Current technical work (the architecture)

- **143_protocol_a**: 8-module symbolic cognitive architecture for AI agent governance.
- **Trinity Dialectic evaluation engine**: Lambda/Logos (analytical), Pi/Pathos (creative), Theta/Ethos (arbitrator/verifier).
- **0sXai**: Zero-Assumption Explainable AI framework.
- **claude-obsidian**: Claude Code plugin for Obsidian wiki management (v1.4.3, 10 skills).
- **ACCE Memory Architecture**: Cache/RAM/Disk three-tier agent memory.
- **2,336-book research corpus** organized into 70 NotebookLM knowledge modules.
- **Multi-agent orchestration with stigmergic coordination** (agents leave traces, not direct comms).
- **NotebookLM MCP automation** (35 tools), ComfyUI MCP, Chrome DevTools Protocol.

---

## Part F: Architecture lineage (publication evolution)

1. **OpenBrainLM**, original neural-symbolic research project, 8-layer bio-inspired architecture.
2. **OB1**, first refactor, agent-focused.
3. **SageX / sageXresearch**, personal research brand, expanded scope.
4. **0sXai**, current form. Zero-Assumption Explainable AI. Trinity Dialectic + ACCE Memory + MI9 Economic Layer.

Narrative framing for publication:
- Not a dump of sessions. A curated progression.
- Each stage shows architectural evolution, not chronological work logs.
- The Green Paper is the philosophical foundation (FATExDAO vision document).
- BitBuddy is the AI persona that emerged from the architecture.
- The Trinity Dialectic (Pathos/Ethos/Logos) is the unifying thread across all stages.
- The biomimicry research (octopus, insect colony, SPAUN) provides the biological grounding.
- The 2,336-book corpus provides the evidence base.

---

## Part G: Target role (Anthropic)

- Prompt Engineer, Claude Code at Anthropic
- Greenhouse ID: 5159669008
- Locations: SF / NYC / Seattle, 25% in-office, remote preferred
- Salary: 300,000 to 405,000 (SWE-G 5-6)
- US Pacific timezone, open to SF relocation

---

## Part H: IP exclusion rules (NEVER PUBLISH)

### Personal identity
- "Austin" (personal name in public artifacts), DESKTOP-8AMMKQP (machine hostname)
- austing143, sagexresearch (usernames in public commit history)
- C:\apps_ai\*, C:\Users\Austin* (Windows paths)
- sk-or-v1-*, sk-ant-* (API key patterns)
- CCC0x, SS-xx (internal lane codes)

### Trading / strategy IP
- ALL trading strategies (Fibonacci, Ichimoku, DTMC Markov engine)
- ALL xD_Arbitrage implementation (DeFi flash loan blueprints)
- FxD_build_notes.docx (explicitly locked by Sage)
- quant_pipeline_architecture files
- Master Plan files
- Live backtest data or results

### Private corpus data
- NotebookLM registry with real notebook UUIDs
- notebooklm-contents files (batch1, batch2)
- notebooklm-upload-roadmap.md

### Personal documents
- Passport, tax returns, pay stubs, driver's license, selfies
- SAGEx/HUMANx/FATEx product suite operational details
- AGI_0s/bitBuddy concept implementation details

### Scrub before push
- FLAG-001 literal in Symbolic_Arch_Dialectic lines 385/388/397
- Windows paths in notebooklm-mcp-reference.md lines 22/49
- EXIF data on all PNGs
- .claude/ directory contents in public repos
- Jupyter notebook cell outputs with local paths

---

## Part I: What needs to be written (P0)

| Deliverable | Status | What's missing |
|---|---|---|
| Resume v2 (Anthropic PE) | DRAFT EXISTS in overnight session, not on disk | Add Ohr Sameach (pending OQ-03), resolve date conflicts (pending OQ-01 + OQ-02), add Green Paper, BitBuddy |
| Resume v2 (Applied Research) | DRAFT EXISTS in overnight session, not on disk | Same fixes |
| LinkedIn rewrite | DRAFT EXISTS in overnight session, not on disk | Resolve 3 date conflicts, add Israel narrative (pending OQ-03), rewrite About arc |
| Why Anthropic essay | NOT STARTED | Sage writes first draft per Anthropic candidate-AI guidance, Claude refines via why_anthropic_essay_refiner |
| GitHub portfolio README | NOT STARTED | Dispatch prompt staged |
| claude-obsidian README polish | NOT STARTED | Dispatch prompt staged |
| Research papers for publication | EXISTING WORK | Curation and IP scrub needed |

### Date conflicts to resolve (OPEN_Q gates)
- OQ-01: FATExDAO range, Oct 2021 to Mar 2025 (LinkedIn) vs 2020-2023 (resume)
- OQ-02: sageXresearch start, Aug 2023 (LinkedIn) vs 2024 (resume)
- OQ-03: Ohr Sameach inclusion override

---

## Part J: Known existing artifacts (research history)

### Handoff documents (wiki/handoffs/, 40+ files, 2026-04-17 to 2026-04-19)
- MASTER_HANDOFF_2026-04-18_session_context.md
- DISPATCH_OPUS_application_push_2026-04-18.md
- HANDOFF_2026-04-18_SS14-github-oss-publishing.md
- HANDOFF_2026-04-18_cowork-to-ccc05.md
- HANDOFF_2026-04-18_orchestrator_reallocation.md
- OVERNIGHT_RUNBOOK_2026-04-18.md
- hostile_audit_archive_openbrain_2026-04-19.md

### Application materials (wiki/anthropic_application/)
- Research files 01-07 (JD mapping, candidacy assessment, conflict reconciliation, Core Thesis)
- sage_inputs/ templates (ALL BLANK, need filling)
- handback/INVENTORY.md
- handback/PROJECT_STATE_UPDATED.md
- QUESTIONS_FOR_AUSTIN.md
- artifact_to_question_map.md

### Architecture documents
- wiki/0sXai_architecture_diagram.html
- wiki/0sXai-143-protocol.md
- wiki/0sXai-stratum-architecture.md
- wiki/Symbolic_Symbolic_Arch_Dialectic_Overview_2026_04_15.md (FLAG-001: lines 385/388/397 need API key scrub)

### Research papers (wiki/apps_ai_research/, 167+ files)
- Biomimicry series: 6 files, 150+ peer-reviewed citations (octopus nervous system, insect colony, SPAUN mapping)
- 3 uncatalogued biomimicry docs in Austin_LM_Drop_Box (ALLOSTATIC_DECISION_GATE, TENTACLE_SANDBOX, SELF_EVOLUTION_LOOP)
- Neuro-Symbolic Synthesis paper (nearest to academic publication)
- Brain Build series (SPAUN to LLM agent mapping)
- OpenBrainLM auto-research loop design
- Reversed PolyJailbreak defensive governance methodology
- 11+ arXiv papers: HippoRAG (NeurIPS 2024), pymdp (JOSS 2022), semantic-router (GlobeCom 2024), Self-RAG (ICLR 2024 Oral)

### Chat exports with extractable content
- ChatGPT_destroys_comp_chat.txt (~65K tokens): V3 Agents Registry, agent indexing scripts, FastAPI registry, CI/CD pipeline. Extractable Python code.
- CursorGPT_chat_nots.txt (~72K tokens): dev environment setup, AlgoTrading_v3, PowerShell debloat scripts.

### Plugin skill candidates (15 identified)
Quick wins: Session Handoff (90%), Trinity Dialectic (85%), Multi-Agent Dispatch (80%)
High-value: Autonomous Research Loop (45%), OpenBrainLM Brain Harness (45%), Biomimicry Methodology (75%)
Working code: MLflow Registry (70%), NotebookLM Automation (60%)

---

## Part K: Open questions for Sage (15 total, only 3 are P0 gating)

P0 (gating immediate work, mirrored to spec.md OPEN_Q):
1. sageXresearch start date: 2023 or 2024? (OQ-02)
2. FATExDAO exact date range: which is correct? (OQ-01)
12. Israel/Ohr Sameach: override STRICT EXCLUSION flag for LinkedIn/resume? (OQ-03)

P1 (queued, gating publication push):
3. NYU credential: what year, what exactly?
7. GitHub handle canonical: 0SxD or AgriciDaniel or both?
8. Attribution: Path A (derivative, keep upstream notices) or Path B (clean-room Sage-only)?
9. Pseudonymity email for commits: sagexresearch@gmail.com? (OQ-04)
10. Application form URL: careers.anthropic.com or specific Greenhouse link?
11. Availability: timezone confirmed Pacific, start date, full-time vs contract?
13. archive-openbrain: execute hostile audit now or defer? (OQ-05)

P2 (queued, gating extended portfolio):
4. CupidSwarm: what is it and where does it live?
5. FFT: what project is this and where?
6. Wireframe: where was it uploaded?
14. Book organization: confirm 5 decision points in BOOK_ORGANIZATION_PLAN.md
15. Plugin priority: which of the 15 candidates to build first?

END_GENERAL_ROLE_CANON
