# skills.md | Anthropic Application -- Austin B. Green Resume | skill tree
# POINTERS ONLY. NO INLINE CONTENT. Load 1 sub-skill per turn max.
# Bootstrapped: 2026-04-21 (v1.0)

## read_protocol (mandatory)
1. Read THIS file first to discover available sub-skills.
2. Load only the sub-skill relevant to the current move. Do NOT preload.
3. Max 1 sub-skill per turn unless user explicitly requests more.
4. If sub-skill is STATUS: pending, note in spec.md OPEN_Q, do not invent content.
5. After task closes, promote new patterns via insight_promotion rule (2+ tasks OR 1 hard-fail).

## status legend
- live: file exists in skills/, content ready, Sonnet-callable.
- pending_draft: registered but not yet written. Do not hallucinate.
- pending_extraction: content lives in canon, needs distillation to its own .md.
- analysis_ready: inputs staged, awaiting processing.

## tree

### core (gates and arbitration)
| slug | summary | path | status |
|---|---|---|---|
| pre_submit_gate | 4-rule gate, all TRUE before any public-facing artifact ships | skills/pre_submit_gate.md | live |
| pathos_ethos_logos_approval_gate | Sage's mandatory PEL verdict before public release | skills/pathos_ethos_logos_approval_gate.md | live |
| trinity_dialectic_evaluator | Logos / Pathos / Ethos 3x3 matrix, 9 sub-evaluators | skills/trinity_dialectic_evaluator.md | live |

### writing (Sonnet-callable artifact producers)
| slug | summary | path | status |
|---|---|---|---|
| resume_variant_writer | Produce 1-page ATS-safe resume variant from canon, no em dashes | skills/resume_variant_writer.md | live |
| why_anthropic_essay_refiner | Refine Sage's first draft, preserve voice, show independent convergence | skills/why_anthropic_essay_refiner.md | pending_draft |
| linkedin_section_rewriter | Rewrite LinkedIn About + Experience sections per canon, no date conflicts | skills/linkedin_section_rewriter.md | pending_draft |
| github_readme_writer | Produce portfolio README per Section 5 publication evolution map | skills/github_readme_writer.md | pending_draft |

### analysis (Sonnet-callable reasoners)
| slug | summary | path | status |
|---|---|---|---|
| date_conflict_reconciler | Reconcile cross-document date conflicts, return canonical entry or escalate to Sage | skills/date_conflict_reconciler.md | live |
| corpus_truth_extractor | Extract single canonical truth from N versioned source documents | skills/corpus_truth_extractor.md | pending_draft |

### ops (publication and submission procedures)
| slug | summary | path | status |
|---|---|---|---|
| ip_scrub_pre_publish | Enforce MASTER_RESEARCH_HANDOFF Section 4 IP exclusions before any push | skills/ip_scrub_pre_publish.md | live |
| greenhouse_submission_packager | Assemble Greenhouse 5159669008 package, verify each field | skills/greenhouse_submission_packager.md | pending_draft |
| github_pre_push_audit | gitleaks scan + IP scrub on diff before any push | skills/github_pre_push_audit.md | pending_draft |

### session_ops (chat-management procedures)
| slug | summary | path | status |
|---|---|---|---|
| socratic_question_generator | Generate 1-3 load-bearing questions from open ambiguity | skills/socratic_question_generator.md | live |
| handoff_writer | At 75% context, write HANDOFF + CUTPASTE + ANALYSIS bundle | skills/handoff_writer.md | pending_draft |

## registry rules
- New sub-skill = new row here + new <snake_case>.md file in skills/.
- Row fields: slug, summary (under 12 words), path, status.
- Slug = snake_case, matches filename without .md.
- No inline content in this file.
- Status transitions: pending_draft to live (on file write).
- Deprecate: move obsolete row to archive section at bottom.

## Sonnet sub-agent invocation contract

When dispatching to a Sonnet sub-agent, the calling Opus turn must:
1. Name the sub-skill loaded (one of the slugs above with status=live).
2. State input contract: what canon files, what Sage answers, what runtime state required.
3. State output contract: what artifact returns, what gates it must clear.
4. Set verification step: which gate (pre_submit_gate? PEL? both?) the output passes through before ship.
5. State terminal verdict format: TRUE=1 returns artifact, FALSE=0 returns OPEN_Q escalation.

## archive
- (none)

END_SKILLS
