# metrics_ledger.md | silent telemetry | zero canon weight
# Project: Anthropic Application -- Austin B. Green Resume
# Append-only. Purpose: trend output_tokens per task + sonnet:opus ratio.

## legend

- turn_ts: ISO timestamp.
- task_id: T01, T02, ... from TASK_QUEUE in spec.md.
- turn_number: 1-indexed within the task's chat.
- model: opus | sonnet | haiku.
- input_tokens_est: chars(input) / 4.
- output_tokens_est: chars(Claude output) / 4.
- out_in_ratio: output / input.
- outcome: TRUE1 | FALSE0 | PENDING | ITER-N | APPROVED | SENTBACK.
- tier_recommend: opus_gate | sonnet_exec.
- notes: free-text key signals.

## success-eval rule
Rolling avg last 3 completed tasks' output_tokens vs prior 3.
Trending down + approval stable-or-rising = TRUE=1 compounding.
Flat-or-rising = FALSE=0, audit non-reducing skill or wiki bloat.
Sonnet:Opus target ratio >= 3:1.

---

## rows

| turn_ts | task_id | turn_number | model | input_tokens_est | output_tokens_est | out_in_ratio | outcome | tier_recommend | notes |
|---|---|---|---|---|---|---|---|---|---|
| 2026-04-21 | bootstrap | 1 | opus_4.7 | ~25000 | ~14000 | 0.56 | TRUE1 | opus_gate | structural bootstrap, OS adoption, MASTER_RESEARCH_HANDOFF ingestion, 19 files created |

END_LEDGER
