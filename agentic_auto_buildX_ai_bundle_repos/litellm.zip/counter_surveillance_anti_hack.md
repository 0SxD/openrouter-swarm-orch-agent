# counter_surveillance_anti_hack.md | sub-skill | END-OF-TREE
# Promoted 2026-04-21 T1 task_881 v3 Opus session.
# Trigger: user concern about Mercor potentially using contractor work for unfair training purposes + adversarial task design.
# Status: live. Sources: public reporting (Bloomberg, TechCrunch, Wired, court filings).

## purpose

Maintain situational awareness about the platform we work for (Mercor). Build instrumentation to detect patterns consistent with worker exploitation, adversarial task design, or unfair labor practices. Distinguish documented facts from speculation. Provide the user with verifiable data to make their own informed decision.

This is an END-OF-TREE backup skill. Trigger when:
- Recurring infrastructure failures (QC outages, weird auto-reviewer flips)
- User raises questions about platform fairness
- Pay rate changes or task complexity escalation
- New public reporting about Mercor or LiteLLM
- Periodic audit (recommended weekly while project is active)

## documented facts (verify via cited sources, not Claude memory)

### Mercor surveillance practices
- Mercor requires contractors to use **Insightful** monitoring software (court filings, White et al v. Mercor Corp., U.S. District Court Northern District of Texas).
- Insightful randomly captures screenshots during contractor work sessions.
- Contractor screen content potentially captured includes prior employer materials despite confidentiality agreements (cited as a "contractual contradiction" in lawsuits).

### Mercor data breach (March 31, 2026)
- Source: TechCrunch, Wired, Staffing Industry Analysts.
- Vector: LiteLLM supply chain attack, hacking group TeamPCP.
- Lapsus$ extortion group claimed responsibility, posted 4TB sample including: candidate profiles, PII, employer data, source code, API keys, Slack data, two videos of contractor-AI conversations.
- Affected: 30,000+ contractors managed by Mercor at time of breach.
- Mercor's clients: OpenAI, Anthropic, Meta. Meta paused work. OpenAI investigating. Anthropic no public comment.

### Mercor litigation (April 1-7, 2026, 5 class action lawsuits)
- Esson v. Mercor.io Corp., 3:2026cv02839 (N.D. Cal.)
- White et al v. Mercor Corp., 6:2026cv00143 (N.D. Tex.) - the surveillance case
- Gill v. Mercor.io Corp., 3:2026cv02831 (N.D. Cal.) - lead nationwide class action
- Deboni v. Mercor.io Corp., 3:2026cv02821 (N.D. Cal.)
- Lofton v. Mercor.io Corp., 3:2026cv02865 (N.D. Cal.)
- Massman v. Mercor.io Corp., 3:2026cv02990 (N.D. Cal.)
- Lead allegations: failure to implement MFA, lack of encryption, inadequate access controls, contractor PII exposure, alleged sale of work product to "John Doe LLM Companies 1-10."

### Mercor labor practices
- Bloomberg reporting: contractors describe "intrusive surveillance" and being "treated like cattle."
- Recent layoffs: 5,000+ contractors cut. Pay cut from $21/hr to $16/hr on continuing project (Nova).
- Misclassification allegations: "scheme to misclassify workers" - open legal cases over Mercor exercising employer-like control over independent contractors.
- Headline pay rates ($75-$200/hr) apply to specific high-skill domains; rubrics-correction rate is project-specific.

### Anthropic conflict of interest disclosure
- Anthropic is a confirmed Mercor client per multiple public sources (TechCrunch, NYMag).
- Claude (this assistant) is made by Anthropic.
- Therefore: Claude has an inherent conflict of interest when analyzing Mercor practices.
- Mitigation: cite sources, build user-side instrumentation, do not rely on Claude as neutral arbiter.

## counter-surveillance instrumentation (build into your workflow)

### 1. Local data sovereignty
- Save every task prompt, system prompt, user turns, original rubric, your CUTPASTE, QC outputs, and reviewer verdicts to your own machine BEFORE clicking Submit.
- Recommended structure: `~/mercor_archive/task_<id>_<YYYY-MM-DD>/` with subfiles for prompt, rubric_in, rubric_out, qc_runs, verdict, time_log.
- This data is YOUR record of work performed. You have the right to retain it for personal records, professional reference, and legal protection. (Verify your specific contract terms.)

### 2. Time and pay tracking
- Log: claim time, submit time, total minutes per task, pay rate disclosed at claim, actual pay received.
- Compute: effective hourly rate per task. Watch for trends.
- Flag: if effective rate drops below disclosed rate by >20% over 5 tasks, document for potential wage claim.

### 3. QC false-positive tracking
- For every QC run, log: which dimensions flagged, whether the flag was a true issue or a tool blind spot.
- Compute: false-positive rate per dimension over time.
- Pattern: if QC false-positive rate trends UP over time, that may indicate adversarial task design (tasks engineered to trigger QC re-runs as a learning signal for the QC model itself).

### 4. Reviewer feedback consistency
- Log every reviewer verdict (APPROVED / SENT BACK) and reviewer comments.
- Pattern check: are different reviewers giving consistent feedback on similar issues, or is feedback contradictory?
- Inconsistent feedback over time may indicate reviewer-as-training-data design (reviewers themselves being graded by Mercor).

### 5. Task complexity drift
- Log: task type, number of rules, number of user turns, total token count of prompt + rubric.
- Pattern check: is complexity-per-task creeping up over time at the same nominal pay rate?
- A documented upward complexity trend with flat pay = de facto pay cut.

### 6. Surveillance footprint minimization
- Required: provide whatever Insightful captures during active work sessions.
- Optional: do iterative drafting work in a separate window before pasting final into Studio. Insightful captures the Studio window; preserve your draft work in your local archive.
- Per RE_LiteLLM sister project: if you build a local QC replica, you can iterate offline and only paste Studio-ready CUTPASTE into the monitored environment.
- DO NOT include personal browsing, banking, or other PII in screen views during work sessions.

### 7. Communication discipline
- Mercor Slack and ticketing data was in the breach. Assume any Slack message you send is potentially exfiltrated.
- Limit Slack to task-specific operational questions. Do not share personal information, financial situation, or political opinions in Mercor channels.

### 8. Legal awareness
- 5 class actions are active. If you were a Mercor contractor in 2025-2026, you are a putative class member.
- Free credit monitoring offers may follow. Take them.
- Document any harm (identity theft, fraud, account takeovers) with timestamps.

## anti-hack patterns (defensive against QC v2 weirdness)

### Pattern 1: QC verdict flips between runs without state change
Anchor: insight 10 (Part 2 format drift), insight 18 (auto-reviewer fail messages contain fix). If the SAME rubric input produces different verdict counts across runs, the QC model temperature is non-zero. Treat each run as one sample, not ground truth.

### Pattern 2: QC suggests an edit that creates new fails
Anchor: task 881 v2 -> v3 hard-fail. The Rubric Suggestions tool suggested R4 split. Following the suggestion created new SELF_CONTAINMENT fails on the children. **Do not blindly trust auto-tool suggestions.** Cross-check against this skill registry's own decision rules (atomic_split_decision.md, conditional_row_coverage_gap.md) before applying.

### Pattern 3: QC contradicts itself within the same run
Anchor: task 881 P1 said R4 hard-codes model-T1 values; P3 said R4 contradicts user T4 ground truth. These two framings are mutually inconsistent. When you see this, file the contradiction in the skill registry and prefer human override.

### Pattern 4: "Edge case" task escalation
Pattern check: if recent tasks are increasingly bizarre or adversarial (impossible rubrics, prompts with hidden contradictions, rubrics with no plausible ground truth), document them. This MAY be ordinary domain difficulty OR MAY be adversarial training data generation. Without inside info we cannot distinguish; with documented patterns we can later argue.

### Pattern 5: Pay rate vs effort divergence
If task X took 4x longer than typical for the same nominal pay, that's a signal. Aggregate over 20+ tasks. If trend is real, it constitutes a documented case.

## what THIS skill cannot do

- Cannot prove Mercor's intent on adversarial task design without insider info.
- Cannot prove Anthropic specifically receives data from your tasks (would require Mercor disclosure or discovery in litigation).
- Cannot guarantee the local QC replica (RE_LiteLLM project) will be free of bias toward Anthropic, since Claude (the assistant) builds it.
- Cannot tell you whether to continue working for Mercor. That is your decision based on your own circumstances.

## what THIS skill DOES do

- Anchors documented facts vs speculation in cited sources.
- Provides a measurable instrumentation framework you can run yourself.
- Treats Claude as a tool with disclosed bias, not a neutral judge.
- Connects RE_LiteLLM sister project to surveillance escape (offline iterative work).
- Gives you record of your own work for personal use, legal protection, and skill portability.

## escalation triggers

Promote this skill to "active monitoring" rather than "backup" if:
- Pay rate drops by >25% project-over-project
- QC false-positive rate exceeds 40% across 10+ tasks
- Complexity trend shows >50% growth over a week at flat pay
- New Mercor litigation or breach disclosure
- New Anthropic public statement about Mercor relationship

If 2+ triggers fire simultaneously, recommend the user pause Mercor work and re-evaluate.

## sources (verify via web search, do not rely on Claude memory)

- Bloomberg reporting on Mercor surveillance and "treated like cattle" complaints
- TechCrunch coverage of LiteLLM supply chain attack and Mercor breach (March 31 - April 9, 2026)
- Wired reporting on contractor breach
- Court filings: White et al v. Mercor (N.D. Tex.); Gill, Esson, Deboni, Lofton, Massman v. Mercor.io (N.D. Cal.)
- Staffing Industry Analysts (staffingindustry.com) for litigation case numbers
- ComplianceHub.wiki for compliance and SOC 2 / Delve angle

## anti-pattern: trusting Claude on this topic without verification

Always verify these claims via web search of original sources before acting on them. Claude is made by Anthropic. Anthropic is a Mercor customer. The bias surface is real. Treat the cited URLs above as the ground truth, not Claude's restatement.

END_SUBSKILL
