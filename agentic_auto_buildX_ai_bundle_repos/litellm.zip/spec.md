# spec.md | CANONICAL HANDOFF & COM. STREAM

<zero_bloat_protocol>
Assume each turn is terminal. Do not retain chat history.
Maintain 3-tier memory architecture: HOT_CACHE, GRAPH_LINKS, COMPACTION_LEDGER.
Main chat output: cave-man syntax only.
Block skill bloat. Compress all semantic reasoning before writing to disk.
</zero_bloat_protocol>

---

## HOT_CACHE
<!-- max 500 words -->

STATUS: task_881 v3 final fix = R4 abstract phrasing only (R11 already removed by user). User raised serious surveillance and exploitation concerns about Mercor. Web search confirmed: Mercor uses Insightful screen surveillance, March 31 2026 LiteLLM-vector breach exposed 4TB contractor data, 5 active class action lawsuits, contractor pay cut $21->$16/hr, Anthropic IS confirmed Mercor client (creating Claude/Anthropic conflict of interest in this project). New skill counter_surveillance_anti_hack.md promoted as END-OF-TREE backup. RE_LiteLLM sister project re-prioritized as surveillance escape via offline QC.
SESSION_TYPE: task_881 v3 final + Mercor platform audit + counter-surveillance skill build.
ACTIVE_TASK: 881 (apply R4 abstract-phrasing fix, no other changes).
NEXT_ACTION: user pastes ONLY R4 text replacement (FIX 2 from v3 file), runs QC, submits. Then claims next task, or pauses to re-evaluate per counter_surveillance_anti_hack escalation triggers.

ACTIVE_VARS:
- task_881_v3_final: R4 text REPLACE only. R11 already gone. R4 new text per auto-reviewer's own recommendation: "Does the response correct the user's Turn 4 step-order recitation by stating that step 2 and step 3 are reversed from the original 5-step plan in the earlier response?"
- mercor_audit_facts: Insightful surveillance, LiteLLM breach (4TB, 30k contractors), 5 class actions (Esson/White/Gill/Deboni/Lofton/Massman), pay cuts, misclassification allegations, Anthropic confirmed client.
- anthropic_conflict_disclosed: Claude is Anthropic; Anthropic is Mercor client. User notified. Mitigation: cite sources, build instrumentation, treat Claude as input not arbiter.
- session_correction: my prior message misread the chronology - user did NOT split R4 unilaterally; Rubric Suggestions tool suggested split, user followed (rational), that triggered fails. Apology delivered.
- new_skill_counter_surveillance: live, end-of-tree backup, escalates to active monitoring if any 2 of 5 triggers fire.

CONFIDENCE: TRUE=1 for v3 R4 fix.

---

## GRAPH_LINKS

- canon_exemplar_881_v3: outputs://Rubric_Correction_Task_881_Health_Meds_2026-04-21_CUTPASTE_v3_HARD_FIX.md (apply only FIX 2)
- new_subskill_counter_surveillance: outputs://counter_surveillance_anti_hack.md
- subskill_atomic_v2: outputs://atomic_split_decision.md
- new_project_dispatch: outputs://PROJECT_DISPATCH_RE_LiteLLM.md
- new_project_bootstrap: outputs://bootstrap_RE_LiteLLM.md
- new_project_questions: outputs://questions_to_setup_RE_LiteLLM.md
- new_project_intro: outputs://intro_context_RE_LiteLLM.md
- canon: project://Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf
- canon_wiki: project://Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md
- subskill_conditional: project://conditional_row_coverage_gap.md
- subskill_qc_reverse: project://qc_v2_reverse_graph.md
- subskill_studio_verify: project://studio_edit_verification.md
- subskill_dedup_forms: project://justify_templates_9forms.md

---

## COMPACTION_LEDGER

[2026-04-21 T1 task_881 v3 final] Mercor public-record audit performed. Anthropic conflict disclosed to user. counter_surveillance_anti_hack.md promoted as end-of-tree skill. RE_LiteLLM project context updated.

---

## TASK_QUEUE

- task_881: v3 R4 abstract-phrasing fix awaiting user paste + re-QC + submit
- task_720, task_883: awaiting reviewer verdicts
- task_884+: claim only after counter_surveillance_anti_hack escalation check
- new_project_RE_LiteLLM: bundle ready, surveillance-escape priority elevated

---

## INSIGHTS_LEDGER

[insight 1-20: prior versions]

[insight 21 task_881 v3 Opus] **Mercor public-record audit confirms user concerns are documented, not paranoia.** Bloomberg-reported worker complaints, Insightful screen surveillance via court filings, March 31 2026 LiteLLM-vector breach exposed 4TB including contractor work videos, 5 active class action lawsuits in CA and TX courts, recent pay cuts ($21->$16/hr) and 5,000 contractor layoffs. Anthropic confirmed Mercor client per TechCrunch and NYMag. Implication: any "neutral analysis" by Claude (an Anthropic system) of Mercor practices carries inherent bias. Mitigation: source-cited disclosure, user-side instrumentation via counter_surveillance_anti_hack.md, RE_LiteLLM sister project for offline QC iteration.

[insight 22 task_881 v3 Opus] **Skill registry must include end-of-tree platform-audit backup.** When working through any third-party platform (Mercor here, possibly others later), the skill tree should include an end-of-tree counter_surveillance / anti_hack skill that wakes up on platform-related concerns. This skill should: cite documented facts only, disclose Claude's conflicts of interest, provide instrumentation framework not opinions, escalate to active monitoring on documented triggers. Anchor: counter_surveillance_anti_hack.md.

[insight 23 task_881 v3 Opus] **Auto-reviewer suggestion can be a trap.** Following Rubric Suggestions tool's "split into atomic" suggestion on R4 created new SELF_CONTAINMENT fails because each child hard-coded a model-T1 value. Pattern: auto-reviewer evaluates structural atomicity in isolation, does not re-check downstream consequences. Mitigation: cross-validate any auto-tool suggestion against atomic_split_decision.md (paired-step bundling exception) before applying.

---

## OPEN_Q

[task_881] User to apply R4 abstract-phrasing fix and confirm green re-QC.
[mercor_audit] User decision pending: continue tasking pace, scale back, or pause to re-evaluate per surveillance findings.
[new_project_RE_LiteLLM] User to drop bundle into fresh Claude Project + answer 5 setup questions.
[task_720, task_883] Reviewer verdicts pending.
[anthropic_relationship] User may want to query Anthropic directly about their Mercor data sourcing (no internal Claude access to that info).

---

## RULES

### protocol (project_instructions v2.1)
- SP > UT always. Conflict = "CONFLICTED PROMPTS" in Writer Comments.
- Actions: Keep | Modify | Discard | Add. One-sentence justify each.
- QC v2 Parts 1+2+3 pre-submit. Human override on false positives.
- Zero data leak: quotes under 15 words, 1 distinct quote string per row.
- Bundling exception: single-goal bundles OK; independently-failable items split.

### split-decision rules (T1 task_881 v3)
- Paired structural assignments KEEP BUNDLED (step pairs, glucose pairs, date+time, closed enumerations).
- DO NOT split if any child would hard-code a model-generated value.
- DO NOT split if any 2 children would cite the same SP quote.
- Auto-reviewer "should X" / "should reference Y" phrasing in fail messages = literal recommended fix.

### counter-surveillance rules (NEW T1 task_881 v3)
- Save every task to local archive before Submit (PII-clean copy).
- Track effective hourly rate per task. Flag >20% drop over 5 tasks.
- Track QC false-positive rate per dimension. Flag if trending up.
- Treat Claude analysis of Mercor as conflicted. Cite primary sources for any factual claim about Mercor.
- Do iterative work outside the surveilled Studio window when possible. Paste only Studio-ready output.
- Periodic audit (weekly) of counter_surveillance_anti_hack.md escalation triggers.

### CUTPASTE annotation rules (T1 task_881 v3)
- State expected final row count after paste.
- Annotate paired-bundled rows with "DO NOT split this row" warning.
- Every Modify row carries explicit FIND/REPLACE blocks.

---

## file registry

<canon_read_only>
- onboarding: Rubrics_Correction___Project_Onboarding_copy_2026_04_21.pdf
- wiki: Master_Wiki_Specification__Rubrics_Correction_Project_v2_0_4_21_2026.md
- protocol_blueprint: protocol_mandate.png
- justify_templates: Mastering_Rubric_Justification_and_Review_Score_Card
- exemplar_614, exemplar_720, exemplar_881_v3
</canon_read_only>

<mutable_self_evolving>
- state: spec.md (this file)
- skill_tree: skills.md (registry of subskills)
- wiki_log: Rubric_Correction_Wiki_Log.md
- wiki_index: Rubric_Correction_Wiki_Index.md
- protocol_canon: project_instructions.md
- telemetry: metrics_ledger.md
</mutable_self_evolving>

<sister_projects_spawned>
- RE_LiteLLM: 4-file bundle in outputs/. Surveillance escape priority elevated post-audit.
</sister_projects_spawned>

<end_of_tree_backup_skills>
- counter_surveillance_anti_hack.md (NEW T1 task_881 v3, end-of-tree, status live)
</end_of_tree_backup_skills>

---

## user preferences

<user_preferences>
- No emdashes. Hyphens, commas, line breaks only.
- Remember Protocol and Goal.
- Sonnet/Opus split: Sonnet for intake + first CUTPASTE, Opus for second-look + hard-fail recovery + sensitive analysis.
- Sister projects spawn on recurring infra issues.
- Treat Claude as conflicted on Mercor topics; cite sources; build instrumentation.
</user_preferences>

---

## first move every new chat

<first_move>
1. project_knowledge_search "spec.md HOT_CACHE" to load current state.
2. Read skills.md tree-index. Load only relevant sub-skill.
3. Pre-output eval: TRUE=1 acts, FALSE=0 asks up to 3 Qs.
4. If user mentions Mercor practices, surveillance, pay, breach, or fairness: load counter_surveillance_anti_hack.md immediately.
</first_move>

---

## goal

<goal>
100% / TRUE=1 approve-first-try. Zero reviewer edits. 1,000 tasks by EOD Wednesday 2026-04-22 (user reconsiders this target post-audit if appropriate). Stretch: replace Mercor QC dependency with local replica via RE_LiteLLM. End-of-tree: counter_surveillance_anti_hack as periodic platform audit.
</goal>

END_SPEC
