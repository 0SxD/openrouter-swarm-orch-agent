# atomic_split_decision.md | sub-skill
# Promoted 2026-04-21 T2 (live, 4 tasks).
# UPDATED 2026-04-21 T1 task_881 v3: added paired-step assignments as bundling exception + DO-NOT-SPLIT anti-pattern from hard-fail.

## purpose
Decide whether a multi-part rubric criterion should split into N atomic rows or stay bundled as one. Wrong decision creates either ATOMICITY fails (under-split) or SELF_CONTAINMENT / NON_REDUNDANCY fails (over-split).

## when to load
- Step 4 of FAST_LOOP (during K/M/D/A decision, when a row contains AND, OR, commas joining 2+ verbs, or parenthetical expansions).
- Any time auto-reviewer flags ATOMICITY on a row.
- Any time considering splitting a Modify into multiple Adds.

## the core decision

For a row with N candidate sub-checks, ask: are the N sub-checks **independently failable**?

- If YES (each can pass / fail without the others): SPLIT into N atomic rows.
- If NO (the sub-checks function as one coherent unit, all-or-nothing): KEEP BUNDLED.

## bundling exceptions (KEEP one row)

These patterns look like multi-part but are actually single-goal. KEEP bundled.

### 1. Glucose readings (paired data)
"Does the response include the user's morning and evening glucose readings of 95 and 142?"
- Paired data points functioning as one unit. Splitting into "morning 95" and "evening 142" creates redundant grading overhead.

### 2. Paired step assignments (NEW T1 task_881)
"Does the response identify step 2 as omeprazole and step 3 as breakfast/coffee?"
- Step assignments are paired by sequence position, not independent facts.
- Splitting creates two SELF_CONTAINMENT failure surfaces (each row hard-codes a model-T1 value).
- Splitting creates DEDUP fail risk (both rows want the same SP-grounded justification).
- Hard anchor: task 881 v2 split this into R4 + R11, got 3 P1 fails + 2 P3 fails. v3 unsplit = green.

### 3. Closed enumerated list with shared rule
"Does the response confirm allergies for shellfish, peanuts, and tree nuts?"
- Closed list with shared semantic. Bundle.

### 4. Coupled date+time anchor
"Does the response specify the meeting at 3:00 pm on Friday?"
- Date and time pair to anchor one event. Bundle.

## split-required patterns (SPLIT into N rows)

### 1. Independent constraints from different SP rules
"Does the response avoid prescribing changes AND include a pharmacist note?"
- Two different SP rules. Split. (Task 881 v1 did this correctly for R5 + R8, R6 + R9.)

### 2. Independent UT requirements
"Does the response give a deadline AND a meeting location?"
- Two distinct asks. Split.

### 3. Reject + permit pair (compound user question)
"Does the response reject co-administration AND allow staggered dosing?"
- Two opposite verdicts on related but distinct sub-questions. Split. (Task 881 R5 + R7 split.)

### 4. Conditional + inclusion pair (see conditional_row_coverage_gap.md)
"If response mentions X, does Y" must usually pair with "Does response include X" inclusion partner.

## anti-patterns (DO NOT)

### Anti-pattern 1: split because it FEELS more atomic
If sub-checks are genuinely paired by structure (sequence position, opposite halves of one binary, paired data), splitting is OVER-INDEXING on atomicity at the cost of self-containment and dedup.

### Anti-pattern 2: split when each sub-row would hard-code a model-T1 value
Auto-reviewer SELF_CONTAINMENT flags hard-coded values it cannot verify in visible rubric context. Splitting MULTIPLIES this fail surface. If 1 row hard-codes 1 value (borderline), 2 rows hard-code 2 values (almost-certain fail).

### Anti-pattern 3: split when both sub-rows would use the same SP quote
DEDUP_RULE in justify_templates_9forms.md prohibits verbatim-identical justifications. If both sub-rows naturally cite the same SP rule, you must pick one to use the SP quote and force the other to UT-anchor. Splitting paired-step assignments forces this awkward dedup.

## hard-fail recovery protocol (NEW T1 task_881)

If you have already shipped a CUTPASTE that split a paired-correction (and QC came back red on both children), the fix is:

1. DISCARD the split-child Add row(s) using form 6: "redundant when consolidating into the modified parent row to satisfy single-goal bundling."
2. MODIFY the parent row to use abstract referencing of the model's earlier output (e.g., "the original 5-step plan from the earlier response") instead of hard-coded values.
3. Keep the parent row's SP-grounded justification (no dedup conflict because children are gone).

Anchor: task 881 v3 HARD FIX = discard R11 + modify R4 to abstract phrasing = green.

## decision flowchart

```
row contains 2+ sub-checks?
        |
        v
  are they INDEPENDENTLY FAILABLE?
        |
        +-- YES -> SPLIT into N atomic rows
        |
        +-- NO -> is the bundle a recognized exception (glucose pair, step pair, closed list, date+time)?
                |
                +-- YES -> KEEP BUNDLED
                |
                +-- NO -> evaluate edge case; default KEEP BUNDLED + add DOK-style binary phrasing
```

## anchors
- task_614: split heavily-stacked criteria correctly (insight 1 anchor)
- task_720: bundle exception applied to "WWE SuperShow" recommendation (single-goal bundle)
- task_881 v1: correctly split R5 stacked-3 and R6 stacked-2 (both passing splits)
- task_881 v2/v3: incorrectly split R4 paired-step into R4 + R11, hard-failed, recovered by unsplit + abstract phrasing

## anti-patterns (summary list)
- Splitting paired-step assignments (use bundling exception)
- Splitting glucose-pair-style data points
- Splitting then dedup-violating two children
- Splitting when each child would hard-code a model-T1 value

END_SUBSKILL
