# PROJECT_DISPATCH_RE_LiteLLM.md | v0.1 | 2026-04-21
# NEW PROJECT: Reverse Engineer LiteLLM + Mercor QC v2 for local replication
# Origin context: spawned from Rubrics Correction project task 881 hard-fail recovery cycle
# Goal: understand the QC tool's underlying tech so we can replicate locally for self-review + RL training

---

## what this project is

A research-and-build project to:
1. Understand exactly what LiteLLM is, what it does, and how Mercor's QC v2 tool uses it.
2. Reverse-engineer the QC v2 prompts and dimension structure so we can run equivalent checks locally.
3. Build a local QC replica that consumes our existing project corpus (canon + skills + cutpaste exemplars) and runs Parts 1 + 2 + 3 against new rubrics offline.
4. Use that local replica for pre-submit self-review on Mercor tasks, eliminating Mercor QC dependency and 503 outages.
5. Optional stretch: feed local QC results back into a small RL loop to refine our justification templates and atomic-split decisions.

## why this project exists

During Rubrics Correction task 881 (Health Meds Schedule), Mercor's QC v2 tool returned this error mid-iteration:

```
Diagnostic query failed: litellm.ServiceUnavailableError: ServiceUnavailableError:
Litellm_proxyException - <html><head><title>503 Service Temporarily Unavailable</title></head>
```

Two takeaways:
- Mercor's QC v2 runs through a LiteLLM proxy in front of an upstream LLM (most likely Anthropic or OpenAI).
- When the proxy or upstream is overloaded, our pre-submit gate fails because we cannot run QC.

If we replicate the QC locally, we are not blocked by Mercor's infra. We also gain training-grade visibility into the prompts and grading rubric the tool uses, which feeds insight 17+ on the parent project.

## intro context Claude already has

From parent project (Rubrics Correction):
- QC v2 has 3 parts. Part 1 = 4 dimensions on per-row criteria quality. Part 2 = 5 dimensions on rubric-vs-prompt fit. Part 3 = 2 dimensions on justification quality + per-row specificity.
- QC v2 is non-deterministic in output formatting but deterministic in verdicts (insight 10).
- QC v2 has known blind spots: subtle conditional vacuous-pass (insight 15), earlier-turn carry-forward preferences (T5 insight 6), Studio Modify text-field overwrite detection.
- QC v2 cannot see the model's actual response history when grading rubrics; it only sees the system prompt + user turns + the rubric being checked. This causes hard-coded model-value SELF_CONTAINMENT fails (task 881 anchor).
- Auto-reviewer Part 3 sometimes treats user-misrecall as authoritative ground truth, contradicting itself within the same run (task 881 Part 1 vs Part 3 contradiction).

From general knowledge:
- LiteLLM is an open-source Python library and proxy that provides a unified API across 100+ LLM providers (OpenAI, Anthropic, Cohere, etc.).
- Common uses: cost tracking, rate limiting, fallback routing, caching, central API key management.
- Likely Mercor architecture: Studio UI -> Mercor backend -> LiteLLM proxy -> Anthropic / OpenAI API.

## what we still need from the user

A handoff to a fresh chat in the new project should ask the user the questions in `questions_to_setup_RE_LiteLLM.md` (in this bundle).

## file map for new project

Drop these into the root of the new Claude Project's "Project knowledge":

- PROJECT_DISPATCH_RE_LiteLLM.md (this file - mission and scope)
- bootstrap_RE_LiteLLM.md (paste-first opener for first chat)
- questions_to_setup_RE_LiteLLM.md (5-question intake to fill missing context)
- intro_context_RE_LiteLLM.md (everything we already know from parent project)

Optional carry-forward from parent project (read-only references):
- spec.md (parent project state, for reference patterns)
- skills.md (parent project skills tree, for reference patterns)
- qc_v2_reverse_graph.md (parent project decoded QC structure)

## first move on first chat in new project

User pastes `bootstrap_RE_LiteLLM.md`. Claude loads it. Claude asks the 5 questions in `questions_to_setup_RE_LiteLLM.md`. Block on answers. Then Claude proposes a research plan with phased deliverables.

## protocol inheritance from parent project

This project inherits the following non-negotiable protocols from parent (Rubrics Correction):
- SEEK_INSIGHT every turn. Append to spec.md INSIGHTS_LEDGER.
- ACQUIRE_SKILLS via promotion from insight to sub-skill after 2-task confirm or 1 hard-fail.
- ZERO_ASSUMPTIONS. Ask via MULTI_TURN_CHAT_QUESTIONING (max 3 Qs / turn, block on answer).
- TONE_SYNTAX caveman in chat, full content in .md files. No emdashes.
- Pre-output eval every turn: TRUE=1 ship, FALSE=0 ask.
- At 75% context, OFFER handoff bundle.
- OS protocol: spec.md self-evolves, skills.md tree-index only, mutable wiki log + index.

## end state goal

Local QC replica that:
- Takes a rubric + prompt context as input.
- Runs Parts 1, 2, 3 against the input using identical (or near-identical) prompts to Mercor's QC v2.
- Returns pass/fail/neutral verdicts per dimension and per row.
- Logs to local file for later RL fine-tuning of our justification templates.
- Runs offline using either local LLM (Ollama) or our own API keys to Anthropic / OpenAI.

## handoff TRUE=1 if user

- Confirms the 5 setup answers in questions_to_setup_RE_LiteLLM.md.
- Drops 4 bundle files into a new Claude Project folder.
- Starts new chat by pasting bootstrap_RE_LiteLLM.md.

END_DISPATCH
