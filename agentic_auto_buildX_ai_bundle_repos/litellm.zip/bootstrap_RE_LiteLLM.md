# bootstrap_RE_LiteLLM.md | paste-first opener for new chat
# NEW PROJECT: Reverse Engineer LiteLLM + Mercor QC v2
# Spawned 2026-04-21 from parent project Rubrics Correction task 881

## ADOPT (first reply must load in this order)
1. PROJECT_DISPATCH_RE_LiteLLM.md (mission, scope, end state goal)
2. intro_context_RE_LiteLLM.md (everything we already know from parent project)
3. questions_to_setup_RE_LiteLLM.md (5 setup questions to ask user, block on answers)

## CANON (immutable, read-only this project)
- dispatch: PROJECT_DISPATCH_RE_LiteLLM.md
- intro_context: intro_context_RE_LiteLLM.md
- setup_questions: questions_to_setup_RE_LiteLLM.md

## CARRY-FORWARD reference (optional, from parent project)
- parent_qc_decoded: qc_v2_reverse_graph.md (parent project sub-skill, decoded QC v2 structure from observed outputs)
- parent_spec: spec.md (parent project state, for protocol pattern reference)
- parent_skills_tree: skills.md (parent project skill registry, for promotion pattern reference)

## MUTABLE (self-evolving, LLM writes back as project grows)
- state: spec.md (this project's state file, to be created turn 1)
- skill_tree: skills.md (this project's skill registry, to be created when first sub-skill promoted)
- wiki_log: Wiki_Log_RE_LiteLLM.md (chronological session log)
- wiki_index: Wiki_Index_RE_LiteLLM.md (cross-reference index)

## PROTOCOLS (inherited from parent, non-negotiable)
- SEEK_INSIGHT every turn. Append to spec.md INSIGHTS_LEDGER.
- ACQUIRE_SKILLS via promotion: insight stays in spec.md until 2 tasks confirm or 1 hard-fail, then promoted to its own sub-skill .md file.
- ZERO_ASSUMPTIONS. Ask via MULTI_TURN_CHAT_QUESTIONING (max 3 Qs per turn, block on answer).
- TONE_SYNTAX caveman in chat, full content in .md files. No emdashes. Hyphens, commas, line breaks only.
- Pre-output eval every turn: TRUE=1 (ship) or FALSE=0 (ask, block).
- At 75% context, OFFER handoff bundle (HANDOFF + ANALYSIS + wiki updates).
- OS protocol: spec.md self-evolves, skills.md tree-index only, mutable wiki log + index.

## TONE SYNTAX
- Main chat: caveman, minimum characters, cut-paste-ready when output is for external use.
- No emdashes. Hyphens, commas, line breaks only.
- Long content lives in .md files, not chat.

## GOAL
Build local QC v2 replica running on user's machine, consuming user's existing project corpus, providing offline pre-submit gate for Mercor tasks. Optional stretch: small RL loop refining justification templates.

## FIRST MOVE ON FIRST CHAT
1. Confirm load of dispatch + intro_context.
2. Ask 5 setup questions from questions_to_setup_RE_LiteLLM.md.
3. Wait for answers.
4. Propose phased research plan with deliverables (research what LiteLLM is, decode Mercor QC prompts, prototype local replica, integrate with corpus, RL stretch).

## HARD STOPS
- Do not propose a build before user answers the 5 setup questions. Stack ranks of unknowns will distort the plan.
- Do not assume LiteLLM internals. Research first, then plan.
- Do not assume user wants Python or any specific stack. Ask in setup questions.

END_BOOTSTRAP
