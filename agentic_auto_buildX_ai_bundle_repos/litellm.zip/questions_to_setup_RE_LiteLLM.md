# questions_to_setup_RE_LiteLLM.md
# Block-on-answer setup questionnaire for Reverse Engineer LiteLLM project
# Use on first chat turn. Do not propose a research plan until all 5 are answered.

## why these questions

Each question removes a pivotal unknown that would otherwise force assumptions. The plan proposed afterward depends on each answer in concrete ways:
- Q1 sets the tech stack and tool surface.
- Q2 sets the deployment target and budget envelope.
- Q3 sets the scope of replication (do we copy or improve on Mercor QC).
- Q4 sets corpus access and what data the local QC will consume.
- Q5 sets stretch goals and ambition (just QC vs full RL loop).

## the 5 questions

### Q1 - tech stack and dev environment
Which language and runtime does the user want the local QC to run in?
Options:
- Python (matches LiteLLM source language, easiest to fork or extend)
- Node.js / TypeScript (better if existing automation is JS-based)
- Both (Python for QC core, JS for any UI layer)
- Other (specify)

Also: does the user have a preferred LLM client library already in use (Anthropic SDK, OpenAI SDK, Ollama, vLLM, LM Studio, etc.)?

### Q2 - deployment target and budget
Where should the local QC run?
Options:
- Local machine only (laptop / desktop), CPU + maybe one GPU
- Local machine + cloud LLM API calls (Anthropic / OpenAI keys, paid per token)
- Self-hosted local model (Ollama, vLLM, LM Studio) with no per-token cost
- Hybrid: local model for cheap rough pass, cloud model for final judgment

What is the monthly budget cap for cloud LLM calls if any?

### Q3 - scope of replication
What is the user's intent for the local QC?
Options:
- Pure replica: identical prompts, identical dimensions, identical outputs to Mercor QC v2 (forensic faithfulness)
- Functional replica: same dimensions and verdicts, but prompts can be cleaner or more aggressive
- Improved replica: take Mercor's structure but fix known blind spots (subtle conditionals, hard-coded model values, earlier-turn carry-forward, ENGAGEMENT_QUALITY confusion)
- All three in stages: replica first, improved second, RL refinement third

### Q4 - corpus and canon access
What data does the user want the local QC to consume?
Specifically:
- The full Rubrics Correction project canon (onboarding PDF, master wiki, justify templates, all task exemplars 614 / 720 / 881 / 883)?
- The mutable self-evolving files (spec.md, skills.md, wiki log, wiki index, sub-skills)?
- Future Mercor tasks as they come in (read-only intake)?
- User's own QC outputs from past Studio runs (training data for the local replica)?

Also: where is this corpus stored locally? File path, GitHub repo, or somewhere we need to ingest from?

### Q5 - RL stretch ambition
Does the user want to extend beyond replica into a small RL loop that refines our justification templates and atomic-split decisions over time?
Options:
- No, replica only is enough for now
- Yes, simple in-context loop: log every Mercor reviewer verdict, feed into next CUTPASTE generation as few-shot examples
- Yes, parameter-efficient fine-tune: collect 50+ approved task exemplars, run LoRA on a small open model
- Yes, full RL: PPO / DPO setup with reward signal from Mercor reviewer verdicts (most ambitious)

## handoff to research plan

Once all 5 are answered, propose a phased plan something like:

**Phase 1 - LiteLLM research (1-2 sessions)**
- Read LiteLLM docs and source. Map the proxy architecture, supported providers, prompt-passthrough behavior, error model.
- Confirm the "litellm.ServiceUnavailableError" failure mode and what triggers 503.
- Document findings in `LiteLLM_research_notes.md`.

**Phase 2 - Mercor QC prompt extraction (1-2 sessions)**
- From observed QC outputs (parent project has 4+ tasks worth of Part 1 + 2 + 3 outputs), reverse-infer the system prompts driving each Part.
- Cross-check insight 10 (format drift, deterministic verdicts) against observed outputs.
- Produce `Mercor_QC_inferred_prompts.md` with best-guess Part 1 + 2 + 3 system prompts.

**Phase 3 - Local replica prototype (2-3 sessions)**
- Build minimum viable local QC consuming user's corpus and stack-of-choice.
- Validate by re-grading at least 3 known-green CUTPASTE files (614, 720, 881) and confirming green verdicts match.

**Phase 4 - Improvements layer (1-2 sessions)**
- Add fixes for QC v2 blind spots: explicit conditional vacuous-pass detector, model-T1-aware SELF_CONTAINMENT, earlier-turn preferences scan, justification dedup pre-check.

**Phase 5 - Optional RL stretch (open)**
- Per Q5 answer, define the loop scope.

## ZERO_ASSUMPTIONS reminder

Do not skip any of Q1-Q5. Each gates a real decision. If user gives partial answers, ask follow-ups in next turn (max 3 per turn). Block on full answers before proposing the plan.

END_QUESTIONS
